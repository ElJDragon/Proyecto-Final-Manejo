<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReclamosEstructura extends Model
{
protected $table='TRECLAMOSESTRUCTURA';
    protected $fillable = [
        'CODIGO',
        'IDENTIFICACION',
        'NOMBRE',
        'FECHA',
        'CCANAL',
        'CLOCALIDAD',
        'CCONCEPTO',
        'CESTATUS',
        'FECHA_RESPUESTA',
        'CRESOLUCION',
        'MONTO',
        'INTERES',
        'TOTAL_RESTITUIDO'
    ];
protected $primaryKey ='CODIGO';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;
}
