<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tiposcontrol extends Model
{
protected $table='TTIPOSCONTROL';
    protected $fillable = [
        'ID_CONTROL',
        'NOMBRE',
        'OBSERVACION'
    ];
protected $primaryKey ='ID_CONTROL';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;

/*
          public function fdepartamentos()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Departamentos', 'COD_DEPARTAMENTO');
   }*/
}
