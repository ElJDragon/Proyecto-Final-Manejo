<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Periodos extends Model
{
protected $table='TPERIODOAUDITORIA';
    protected $fillable = [
        'ID_PERIODO',
        'NOMBRE',
        'ENERO',
        'FEBRERO',
        'MARZO',
        'ABRIL',
        'MAYO',
        'JUNIO',
        'JULIO',
        'AGOSTO',
        'SEPTIEMBRE',
        'OCTUBRE',
        'NOVIEMBRE',
        'DICIEMBRE',
        'OBSERVACION'
    ];
protected $primaryKey ='ID_PERIODO';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;

/*
          public function fdepartamentos()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Departamentos', 'COD_DEPARTAMENTO');
   }*/
}
