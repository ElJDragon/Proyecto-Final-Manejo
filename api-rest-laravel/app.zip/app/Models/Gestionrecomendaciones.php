<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gestionrecomendaciones extends Model
{
protected $table='TGESTIONRECOMENDACIONES';
    protected $fillable = [
        'ID_GESTION',
        'NUMERO_RECOMENDACION',
        'RECOMENDACION'
            ];
protected $primaryKey ='ID_GESTION';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;


           public function gestionrecomendaciones()
   {//una a muchos
       return $this->hasMany('App\Models\Gestionauditoria');

   }

}
