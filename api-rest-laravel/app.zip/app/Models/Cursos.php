<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cursos extends Model
{
protected $table='TCURSOS';
    protected $fillable = [
        'CODIGOCURSO',
        'NOMBRE',
        'ESTAACTIVO',
        'ETAPA',
        'MODULOS',
        'COD_DEPARTAMENTO'
    ];
protected $primaryKey ='CODIGOCURSO';
 public $keyType = 'string';
   public $incrementing = true; 
   public $timestamps = false;


       public function fmodulos()
   {//una a muchos
       return $this->hasMany('App\Models\Modulos');
   }


          public function fdepartamentos()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Departamentos', 'COD_DEPARTAMENTO');
   }

}
