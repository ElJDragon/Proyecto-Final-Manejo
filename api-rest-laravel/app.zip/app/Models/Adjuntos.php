<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Adjuntos extends Model
{
protected $table='TCURSOSADJUNTO';
    protected $fillable = [
        'CODIGO',
        'CODIGOCURSO',
        'CODIGOMODULO',
        'SUBMODULO',
        'INTRODUCCION',
        'ADJUNTO',
        'TITULO',
        'EXTENSION'
    ];
protected $primaryKey ='CODIGO';
 public $keyType = 'string';
   public $incrementing = true; 
   public $timestamps = false;



          public function fcursos()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Cursos', 'CODIGOCURSO');
   }
        public function fsubmodulos()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Submodulos', 'SUBMODULO');
   }


}
