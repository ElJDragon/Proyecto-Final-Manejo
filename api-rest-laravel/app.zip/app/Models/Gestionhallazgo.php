<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gestionhallazgo extends Model
{
protected $table='TGESTIONHALLAZGOS';
    protected $fillable = [
        'ID_GESTION',
        'NUMERO_HALLAZGO',
        'HALLAZGO',
        'RIESGO'
            ];
protected $primaryKey ='ID_GESTION';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;

             public function gestionhallazgo()
   {//una a muchos
       return $this->hasMany('App\Models\Gestionauditoria');

   }





}
