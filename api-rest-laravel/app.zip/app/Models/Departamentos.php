<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Departamentos extends Model
{
protected $table='TDEPARTAMENTOS';
    protected $fillable = [
        'COD_DEPARTAMENTO',
        'NOMBRE'
    ];
protected $primaryKey ='COD_DEPARTAMENTO';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;



       public function fresponsables()
   {//una a muchos
       return $this->hasMany('App\Models\Responsables');
   }

}



