<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Detalleeva extends Model
{

protected $table='TDETALLEEVA';
    protected $fillable = [
        'CODIGO',
        'CODIGOEVA',
        'PREGUNTA',
        'RESPUESTA',
        'ESCORRECTA'
    ];
protected $primaryKey ='CODIGO';
public $keyType = 'string';
public $incrementing = false; 
public $timestamps = false;


          public function fevaluacion()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Evaluaciones', 'CODIGOEVA');
   }
             public function fpregunta()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Preguntas', 'PREGUNTA');
   }
                public function frespuestas()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Respuestas', 'RESPUESTA');
   }
}
