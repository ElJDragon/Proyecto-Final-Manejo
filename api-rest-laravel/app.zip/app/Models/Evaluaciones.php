<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Evaluaciones extends Model
{
protected $table='TEVALUACIONES';
    protected $fillable = [
        'CODIGO',
        'CODIGOCURSO',
        'CODIGOMODULO',
        'USUARIO',
        'CALIFICACION',
        'ACTIVA'
    ];
protected $primaryKey ='CODIGO';
public $keyType = 'string';
public $incrementing = false; 
public $timestamps = false;


          public function fcurso()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Cursos', 'CODIGOCURSO');
   }
             public function fmodulo()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Modulos', 'CODIGOMODULO');
   }
                public function fusuario()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\User', 'USUARIO');
   }

}
