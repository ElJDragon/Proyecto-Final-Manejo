<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Preguntas extends Model
{
protected $table='TPREGUNTAS';
    protected $fillable = [
        'CODIGO',
        'CODIGOCURSO',
        'CODIGOMODULO',
        'PREGUNTA',
        'ESTAACTIVA'
    ];
protected $primaryKey ='CODIGO';
public $keyType = 'string';
public $incrementing = true; 
public $timestamps = false;


       public function fresponsables()
   {//una a muchos
       return $this->hasMany('App\Models\Cantones');
   }

}
