<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Estadocursos extends Model
{
protected $table='TESTADOCURSOS';
    protected $fillable = [
        'CODIGO',
        'NOMBRE'
    ];
protected $primaryKey ='CODIGO';
 public $keyType = 'string';
   public $incrementing = true; 
   public $timestamps = false;


       public function fasignacion()
   {//una a muchos
       return $this->hasMany('App\Models\Cursoasignacion');
   }

}
