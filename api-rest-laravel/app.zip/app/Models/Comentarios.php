<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Comentarios extends Model
{
  protected $table='TCOMENTARIOS';
    protected $fillable = [
        'ID_GESTION',
        'NUMERO_COMENTARIO',
        'ARCHIVO_ENTREGA',
        'OBSERVACION',
        'PORCENTAJE',
        'FECHA'
    ];
protected $primaryKey ='ID_GESTION';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;


          public function comentarios()
   {//una a muchos
       return $this->hasMany('App\Models\Gestionauditoria');

   }
}
