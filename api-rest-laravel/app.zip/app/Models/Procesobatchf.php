<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Procesobatchf extends Model
{
protected $table='TPROCESOBATCH';
    protected $fillable = [
        'CODIGO',
        'ID_GESTIONORIGEN',
        'ID_GESTIONRENOVADA',
        'F_BATCH',
        'ENVIOEMAIL',
        'ENVIOSMS',
        'ESTADO_ORIGEN',
        'ESTADO_DESTINO',
        'USUARIO'
    ];
protected $primaryKey ='CODIGO';
 public $keyType = 'string';
   public $incrementing = true; 
   public $timestamps = false;


}
