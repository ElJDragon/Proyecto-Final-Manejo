<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gestionasignacion extends Model
{
protected $table='TESTRATEGIASASIGNACION';
    protected $fillable = [
        'ID_GESTION',
        'NUMERO_ASIGNACION',
        'ID_PERIODO',
        'DIA',
        'FASIGNACION',
        'CUSUARIO_AUDITORIA',
        'CUSUARIO_ASIGNACION',
        'CUSUARIO_CORESPONSABLE',
        'ARCHIVO_ASIGNACION',
        'ARCHIVO_ENTREGA',
        'DETALLE_ASIGNACION',
        'DETALLE_ENTREGA',
        'CUSUARIO_CORESPONSABLE2',
        'CUSUARIO_CORESPONSABLE3',
        'FCONTABLE',
        'RENOVADA',
        'ID_ANTERIOR'
    ];
protected $primaryKey ='ID_GESTION';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;

             public function gestionasignacion()
   {//una a muchos
       return $this->hasMany('App\Models\Gestionauditoria');

   }

  
   
}
