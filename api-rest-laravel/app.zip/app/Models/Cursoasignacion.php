<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cursoasignacion extends Model
{
protected $table='TCURSOSUSUARIO';
    protected $fillable = [
        'CODIGO',
        'USUARIO',
        'CURSO',
        'ESTADO',
        'MODULO'
    ];
protected $primaryKey ='CODIGO';
 public $keyType = 'string';
   public $incrementing = true; 
   public $timestamps = false;



          public function fcursos()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Cursos', 'CURSO');
   }
             public function festado()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Estadocursos', 'ESTADO');
   }
             public function fusuario()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\User', 'USUARIO');
   }

}
