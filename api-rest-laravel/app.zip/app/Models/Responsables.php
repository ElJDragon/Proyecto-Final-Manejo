<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Responsables extends Model
{
protected $table='TRESPONSABLES';
    protected $fillable = [
        'ID',
        'COD_DEPARTAMENTO',
        'NOMBRES',
        'APELLIDOS',
        'EMAIL',
        'TELEFONO',
        'USUARIO',
        'IDENTIFICACION'
    ];
protected $primaryKey ='ID';
 public $keyType = 'string';
   public $incrementing = true; 
   public $timestamps = false;


          public function fdepartamentos()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Departamentos', 'COD_DEPARTAMENTO');
   }


}


