<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gestionestrategias extends Model
{
protected $table='TGESTIONESTRATEGIAS';
    protected $fillable = [
        'ID_GESTION',
        'NUMERO_ESTRATEGIA',
        'ESTRATEGIA',
        'FINICIO',
        'FFIN',
        'FENVIO',
        'AREA_RESPONSABLE',
        'ENTREGABLE',
        'PORCENTAJE',
        'CESTATUSESTRATEGIA'
            ];
protected $primaryKey ='ID_GESTION';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;


           public function gestionestrategias()
   {//una a muchos
       return $this->hasMany('App\Models\Gestionauditoria');

   }

}
