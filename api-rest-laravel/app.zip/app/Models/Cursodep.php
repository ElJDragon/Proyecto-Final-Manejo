<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cursodep extends Model
{
protected $table='TCURSOSDEPARTAMENTO';
    protected $fillable = [
        'CODIGO',
        'CODIGOCURSO',
        'CODDEPARTAMENTO'
    ];
protected $primaryKey ='CODIGO';
public $keyType = 'string';
public $incrementing = false; 
public $timestamps = false;


          public function fdepartamento()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Departamentos', 'CODDEPARTAMENTO');
   }

          public function fcurso()
   { 
       //de muchos a uno
          return $this->belongsTo('App\Models\Cursos', 'CODIGOCURSO');
   }
}
