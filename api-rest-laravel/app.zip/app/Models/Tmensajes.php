<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tmensajes extends Model
{
    protected $table='TMENSAJES';
    protected $fillable = [
        'CODIGO',
        'IMAGEN',
        'DETALLE'
    ];
protected $primaryKey ='CODIGO';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;
}
