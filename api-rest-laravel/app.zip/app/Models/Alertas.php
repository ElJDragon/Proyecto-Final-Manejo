<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Alertas extends Model
{
protected $table='TALERTAS';
    protected $fillable = [
        'CODIGO',
        'ALERTA',
        'FECHAINICIO',
        'FECHAFIN',
        'ID_GESTION'
    ];
protected $primaryKey ='CODIGO';
 public $keyType = 'string';
   public $incrementing = true; 
   public $timestamps = false;
}
