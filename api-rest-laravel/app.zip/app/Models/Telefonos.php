<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Telefonos extends Model
{
   protected $table='TTELEFONOS';
    protected $fillable = [
        'NUMERO',
        'LOTE'
    ];
protected $primaryKey ='NUMERO';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;
}
