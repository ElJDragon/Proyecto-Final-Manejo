<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReclamosResolucion extends Model
{
protected $table='TRECLAMOSRESOLUCION';
    protected $fillable = [
        'CODIGO',
        'DETALLE'
    ];
protected $primaryKey ='CODIGO';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;
}
