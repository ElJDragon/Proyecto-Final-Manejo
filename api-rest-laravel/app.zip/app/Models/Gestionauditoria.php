<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gestionauditoria extends Model
{
protected $table='TGESTIONAUDITORIA';
    protected $fillable = [
        'ID_GESTION',
        'ID_CONTROL',
        'IDENTIFICACION',
        'RESPONSABLE',
        'RAZONSOCIAL',
        'INFORME',
        'FEMISION',
        'FENVIOINFORME',
        'FCORTE',
        'NUM_TRAMITE',
        'TIPOPLAN',
        'TIPOSEGUIMIENTO',
        'FLIMITE',
        'NOMBREEXAMEN',
        'SUB_INFORME',
        'SUB_HALLAZGO',
        'INDICADOR',
        'TIPOINDICADOR',
        'FCALCULO',
        'FLINEABASE',
        'LINEABASE',
        'PERIOCIODAD',
        'MESPLANIFICADO',
        'METAPLANIFICADA',
        'ESTADOAPROBACION',
        'FAPROBACION',
        'TIPOREESTRUCTURACION',
        'ESTADOCARGA',
        'FECHAACTUALIZACION',
        'METAEJECUTADA'
    ];
protected $primaryKey ='ID_GESTION';
 public $keyType = 'string';
   public $incrementing = false; 
   public $timestamps = false;






    public function fgestionasignacion()
   { 
       //de muchos a unoGestionhallazgo
          return $this->belongsTo('App\Models\Gestionasignacion', 'ID_GESTION');
   }


   public function fgestionhallazgo()
   { 
       //de muchos a unoGestionhallazgo
          return $this->belongsTo('App\Models\Gestionhallazgo', 'ID_GESTION');
   }

  public function fgestionestrategia()
   { 
       //de muchos a unoGestionhallazgo
          return $this->belongsTo('App\Models\Gestionestrategias', 'ID_GESTION');
   }

     public function fgestionrecomendacion()
   { 
       //de muchos a unoGestionhallazgo
          return $this->belongsTo('App\Models\Gestionrecomendaciones', 'ID_GESTION');
   }





 
}
