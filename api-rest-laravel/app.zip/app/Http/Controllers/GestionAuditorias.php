<?php

namespace App\Http\Controllers;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Gestionauditoria;
use App\Models\Gestionestrategias;
use App\Models\Gestionhallazgo;
use App\Models\Gestionrecomendaciones;
use App\Models\Gestionasignacion;
use App\Models\Responsables;
use App\Models\Alertas;
use App\Models\Periodos;
use App\Models\Parametros;

use App\Models\Estatus;

use App\Helpers\JwtAuth;

class GestionAuditorias extends Controller
{


//SACAR TODOS LOS OTROS PROCESOS SIN LAS CUMPLIDAS
    public function getGestionOtros($id){
        $integer =0; 
        $contador =0; 
        $estado='';
      $responsable='';

       $estatus='REC01';
$nocanceladas = Gestionestrategias::orderBy('ID_GESTION')->get();

 foreach($nocanceladas as $nocancelada)
                {
              $codigosgestion[$contador] = array(     
             'ID_GESTION'=>trim($nocancelada->ID_GESTION)
        );
         $contador++;    
                }

     $gestiones = Gestionauditoria::where(
                     [
                         ['ID_CONTROL',$id]
                     ])->whereIn('ID_GESTION',$codigosgestion)->whereNotIn('ID_CONTROL',[$estatus])->get();


    
 foreach($gestiones as $gestion)
                {

$nombreresponsable='';
$apellidoresponsable='';
$codigointerno='';
$detallerecomendacion='';



//TRAER LA RECOEMNDACION
     $recomendacioness = Gestionrecomendaciones::where(
                     [
                         ['ID_GESTION',$gestion->ID_GESTION]
                     ])->get();





 foreach($recomendacioness as $recomendacione)
                {
$detallerecomendacion=trim($recomendacione->RECOMENDACION);
                }


//ESTADO
$estatus = Estatus::where('CESTATUSESTRATEGIA',$gestion->fgestionestrategia->CESTATUSESTRATEGIA)->get();
 foreach($estatus as $estatu)
                {
$estado=trim($estatu->NOMBRE);
                }


//RESPONSABLE
$responsableids = Gestionasignacion::where('ID_GESTION',trim($gestion->ID_GESTION))->get();
 foreach($responsableids as $responsableid)
                {

                $codigointerno=$responsableid->NUMERO_ASIGNACION;
//TRAER EL NOMBRE DEL RESPONSABLE
     $responsables = Responsables::where(
                     [
                         ['ID',$responsableid->CUSUARIO_ASIGNACION]
                     ])->get();
 foreach($responsables as $responsable)
                {
                    $nombreresponsable=trim($responsable->NOMBRES);
                    $apellidoresponsable=trim($responsable->APELLIDOS);
                }
     $nombreresponsable=$nombreresponsable . " " . $apellidoresponsable;
                }



         $gestioness[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
              'INFORME'=>trim($gestion->INFORME),
              'INTERNO'=>trim($codigointerno),
              'RESPONSABLE'=>$nombreresponsable,
              'ESTRATEGIA'=>trim($gestion->fgestionestrategia->ESTRATEGIA),
              'RECOMENDACION'=>trim($detallerecomendacion),
              'FINICIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FINICIO)),
              'FFIN'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FFIN)),
              'PORCENTAJE'=>trim($gestion->fgestionestrategia->PORCENTAJE),
              'ESTADO'=>trim($estado),
              //TRAER EL PERIODO
             
             //'IDENTIFICACION'=>trim($gestion->fgestionhallazgo->HALLAZGO),

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$gestioness);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }

//SACAR TODOS LAS RECOMENDACIONES SIN LAS CUMPLIDAS
    public function getGestionRecomendaciones($id){
        $integer =0; 
        $contador =0; 
        $estado='';
      $responsable='';

       $estatus='005';
$nocanceladas = Gestionestrategias::whereNotIn('CESTATUSESTRATEGIA',[$estatus])->orderBy('ID_GESTION')->get();

 foreach($nocanceladas as $nocancelada)
                {
              $codigosgestion[$contador] = array(     
             'ID_GESTION'=>trim($nocancelada->ID_GESTION)
        );
         $contador++;    
                }

     $gestiones = Gestionauditoria::where(
                     [
                         ['ID_CONTROL',$id]
                     ])->whereIn('ID_GESTION',$codigosgestion)->get();


    
 foreach($gestiones as $gestion)
                {

$nombreresponsable='';
$apellidoresponsable='';
$codigointerno='';

//ESTADO
$estatus = Estatus::where('CESTATUSESTRATEGIA',$gestion->fgestionestrategia->CESTATUSESTRATEGIA)->get();
 foreach($estatus as $estatu)
                {
$estado=trim($estatu->NOMBRE);
                }


//RESPONSABLE
$responsableids = Gestionasignacion::where('ID_GESTION',trim($gestion->ID_GESTION))->get();
 foreach($responsableids as $responsableid)
                {

                $codigointerno=$responsableid->NUMERO_ASIGNACION;
//TRAER EL NOMBRE DEL RESPONSABLE
     $responsables = Responsables::where(
                     [
                         ['ID',$responsableid->CUSUARIO_ASIGNACION]
                     ])->get();
 foreach($responsables as $responsable)
                {
                    $nombreresponsable=trim($responsable->NOMBRES);
                    $apellidoresponsable=trim($responsable->APELLIDOS);
                }
     $nombreresponsable=$nombreresponsable . " " . $apellidoresponsable;
                }



         $gestioness[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
              'INFORME'=>trim($gestion->INFORME),
              'INTERNO'=>trim($codigointerno),
              'RESPONSABLE'=>$nombreresponsable,
              'ESTRATEGIA'=>trim($gestion->fgestionestrategia->ESTRATEGIA),
              'FINICIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FINICIO)),
              'FFIN'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FFIN)),
              'PORCENTAJE'=>trim($gestion->fgestionestrategia->PORCENTAJE),
              'ESTADO'=>trim($estado),
              //TRAER EL PERIODO
             
             //'IDENTIFICACION'=>trim($gestion->fgestionhallazgo->HALLAZGO),

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$gestioness);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }


////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
//SACAR TODOS LAS RECOMENDACIONES SOLO LAS CUMPLIDAS
    public function getGestionCumplidas($id){
        $integer =0; 
        $contador =0; 
        $estado='';
      $responsable='';

       $estatus='005';
$nocanceladas = Gestionestrategias::whereIn('CESTATUSESTRATEGIA',[$estatus])->orderBy('ID_GESTION')->get();

 foreach($nocanceladas as $nocancelada)
                {
              $codigosgestion[$contador] = array(     
             'ID_GESTION'=>trim($nocancelada->ID_GESTION)
        );
         $contador++;    
                }

     $gestiones = Gestionauditoria::where(
                     [
                         ['ID_CONTROL',$id]
                     ])->whereIn('ID_GESTION',$codigosgestion)->get();


    
 foreach($gestiones as $gestion)
                {

$nombreresponsable='';
$apellidoresponsable='';
$codigointerno='';

//ESTADO
$estatus = Estatus::where('CESTATUSESTRATEGIA',$gestion->fgestionestrategia->CESTATUSESTRATEGIA)->get();
 foreach($estatus as $estatu)
                {
$estado=trim($estatu->NOMBRE);
                }


//RESPONSABLE
$responsableids = Gestionasignacion::where('ID_GESTION',trim($gestion->ID_GESTION))->get();
 foreach($responsableids as $responsableid)
                {

                $codigointerno=$responsableid->NUMERO_ASIGNACION;
//TRAER EL NOMBRE DEL RESPONSABLE
     $responsables = Responsables::where(
                     [
                         ['ID',$responsableid->CUSUARIO_ASIGNACION]
                     ])->get();
 foreach($responsables as $responsable)
                {
                    $nombreresponsable=trim($responsable->NOMBRES);
                    $apellidoresponsable=trim($responsable->APELLIDOS);
                }
     $nombreresponsable=$nombreresponsable . " " . $apellidoresponsable;
                }



         $gestioness[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
              'INFORME'=>trim($gestion->INFORME),
              'INTERNO'=>trim($codigointerno),
              'RESPONSABLE'=>$nombreresponsable,
              'ESTRATEGIA'=>trim($gestion->fgestionestrategia->ESTRATEGIA),
              'FINICIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FINICIO)),
              'FFIN'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FFIN)),
              'PORCENTAJE'=>trim($gestion->fgestionestrategia->PORCENTAJE),
              'ESTADO'=>trim($estado),
              //TRAER EL PERIODO
             
             //'IDENTIFICACION'=>trim($gestion->fgestionhallazgo->HALLAZGO),

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$gestioness);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }




//////////////////////////////////////////////
////////////////////////////////////////////////////
//SACAR LA RECOMENDACION A ASIGNAR
    public function getProcesoId($id){
        $integer =0; 
        $estado='';
        $control='';
        $detallerechazo='';
      //  $gestiones= Gestionauditoria:: orderBy('ID_GESTION')->get();

                     $gestiones = Gestionauditoria::where('ID_GESTION',$id)->orderBy('ID_CONTROL')->get();
 foreach($gestiones as $gestion)
                {
$estatus = Estatus::where('CESTATUSESTRATEGIA',$gestion->fgestionestrategia->CESTATUSESTRATEGIA)->get();

 foreach($estatus as $estatu)
                {
$estado=trim($estatu->NOMBRE);
                }


$rechazos = Gestionasignacion::where('ID_GESTION',$id)->get();
 foreach($rechazos as $rechazo)
                {
$detallerechazo=trim($rechazo->DETALLE_ENTREGA);
                }





         $gestioness[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
              'INFORME'=>trim($gestion->INFORME),
              'HALLAZGO'=>trim($gestion->fgestionhallazgo->HALLAZGO),
              'RECOMENDACION'=>trim($gestion->fgestionrecomendacion->RECOMENDACION),  
              'ESTRATEGIA'=>trim($gestion->fgestionestrategia->ESTRATEGIA),
              'ENTREGABLE'=>trim($gestion->fgestionestrategia->ENTREGABLE),
              'RECHAZO'=>trim($detallerechazo),

              'FENVIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FENVIO)),
              'FINICIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FINICIO)),
              'FFIN'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FFIN)),

              
              'PORCENTAJE'=>trim($gestion->fgestionestrategia->PORCENTAJE),
              



              'ESTADO'=>trim($estado),
              'TIPOCONTROL'=>trim($gestion->ID_CONTROL),
              
              //TRAER EL PERIODO
             
             //'IDENTIFICACION'=>trim($gestion->fgestionhallazgo->HALLAZGO),

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$gestioness);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }




///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
public function subirLoteRecomendaciones(Request $request){
         //ACTUALIZAR EL USUARIO
             //recoger los datos por post

        $json =$request->input('json',null);
         $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array





         if(!empty($params_array))
         {


  foreach ($params_array as $key => $value) {


       $gestionauditorias = Gestionauditoria::select('ID_GESTION')->where('ID_GESTION','=',$value['N°'])->get();

$existe='';
foreach($gestionauditorias as $gestionauditoria)
                {
$existe=trim($gestionauditoria->ID_GESTION);
}
         if(!$existe)
         {


        //Crear el Responsable
    $gestion=new Gestionauditoria();
    if (array_key_exists('N°', $value)) {
    $gestion->ID_GESTION= strtoupper($value['N°']);
        }

    $gestion->ID_CONTROL= 'REC01';
    if (array_key_exists('RUC', $value)) {
    $gestion->IDENTIFICACION= strtoupper($value['RUC']);}
    if (array_key_exists('RESPONSABLE DE EMISIÓN', $value)) {
    $gestion->RESPONSABLE= strtoupper($value['RESPONSABLE DE EMISIÓN']);}
    if (array_key_exists('RAZÓN SOCIAL', $value)) {
    $gestion->RAZONSOCIAL= strtoupper($value['RAZÓN SOCIAL']);}
    if (array_key_exists('N° DE INFORME', $value)) {
    $gestion->INFORME= $value['N° DE INFORME'];}

if (array_key_exists('FECHA DE EMISIÓN', $value)) {
if($value['FECHA DE EMISIÓN']!=''){
    $gestion->FEMISION= date("d/m/Y", ((($value['FECHA DE EMISIÓN'])- 25569) * 86400) );
}else
{
    $gestion->FEMISION= null;
}}

if (array_key_exists('FECHA ENVÍO INFORME', $value)) {
if($value['FECHA ENVÍO INFORME']!=''){
$gestion->FENVIOINFORME= date("d/m/Y", ((($value['FECHA ENVÍO INFORME'])- 25569) * 86400) );
}else
{
    $gestion->FENVIOINFORME= null;
}}


if (array_key_exists('FECHA CORTE INFORMACIÓN', $value)) {
if($value['FECHA CORTE INFORMACIÓN']!=''){
$gestion->FCORTE= date("d/m/Y", ((($value['FECHA CORTE INFORMACIÓN'])- 25569) * 86400));
}else
{
    $gestion->FCORTE= null;
}}
if (array_key_exists('NÚMERO DE TRÁMITE', $value)) {
    $gestion->NUM_TRAMITE= $value['NÚMERO DE TRÁMITE'];}
    if (array_key_exists('TIPO DE PLAN', $value)) {
    $gestion->TIPOPLAN= $value['TIPO DE PLAN'];}
    if (array_key_exists('TIPO DE SEGUIMIENTO', $value)) {
    $gestion->TIPOSEGUIMIENTO= $value['TIPO DE SEGUIMIENTO'];}

if (array_key_exists('FECHA LÍMITE DE CARGA ESTRATÉGIAS', $value)) {
if($value['FECHA LÍMITE DE CARGA ESTRATÉGIAS']!=''){
$gestion->FLIMITE= date("d/m/Y", ((($value['FECHA LÍMITE DE CARGA ESTRATÉGIAS'])- 25569) * 86400) );
}else
{
    $gestion->FLIMITE= null;
}}

if (array_key_exists('NOMBRE DEL EXAMEN', $value)) {
if($value['NOMBRE DEL EXAMEN']!=''){
$gestion->NOMBREEXAMEN= $value['NOMBRE DEL EXAMEN'];
}else{$gestion->NOMBREEXAMEN= null;}}
if (array_key_exists('SUBCOMPONENTE INFORME', $value)) {
    $gestion->SUB_INFORME= $value['SUBCOMPONENTE INFORME'];}
    if (array_key_exists('SUBCOMPONENTE HALLAZGO', $value)) {
    $gestion->SUB_HALLAZGO= $value['SUBCOMPONENTE HALLAZGO'];}
    if (array_key_exists('NOMBRE DEL INDICADOR', $value)) {
    $gestion->INDICADOR= $value['NOMBRE DEL INDICADOR'];}
    if (array_key_exists('TIPO DEL INDICADOR', $value)) {
    $gestion->TIPOINDICADOR= $value['TIPO DEL INDICADOR'];}
    if (array_key_exists('FÓRMULA DE CÁLCULO', $value)) {
    $gestion->FCALCULO= $value['FÓRMULA DE CÁLCULO'];}

if (array_key_exists('FECHA DE LÍNEA BASE', $value)) {
if($value['FECHA DE LÍNEA BASE']!=''){
    $gestion->FLINEABASE= date("d/m/Y", ((($value['FECHA DE LÍNEA BASE'])- 25569) * 86400) );
}else
{$gestion->FLINEABASE= null;}}

if (array_key_exists('LÍNEA BASE', $value)) {
    $gestion->LINEABASE= $value['LÍNEA BASE'];}
    if (array_key_exists('PERIODICIDAD', $value)) {
    $gestion->PERIOCIODAD= $value['PERIODICIDAD'];}
    if (array_key_exists('MES PLANIFICADO', $value)) {
    $gestion->MESPLANIFICADO= $value['MES PLANIFICADO'];}
    if (array_key_exists('META PLANIFICADA', $value)) {
    $gestion->METAPLANIFICADA= $value['META PLANIFICADA'];}
    if (array_key_exists('META EJECUTADA', $value)) {
    $gestion->METAEJECUTADA= $value['META EJECUTADA'];}
    if (array_key_exists('ESTADO DE APROBACIÓN', $value)) {
    $gestion->ESTADOAPROBACION= $value['ESTADO DE APROBACIÓN'];}

if (array_key_exists('FECHA DE RESOLUCIÓN', $value)) {
if($value['FECHA DE RESOLUCIÓN']!=''){
$gestion->FAPROBACION= date("d/m/Y", ((($value['FECHA DE RESOLUCIÓN'])- 25569) * 86400) );
}else
{$gestion->FAPROBACION= null;}}

if (array_key_exists('TIPO DE REESTRUCTURACIÓN', $value)) {
    $gestion->TIPOREESTRUCTURACION= $value['TIPO DE REESTRUCTURACIÓN'];}
    if (array_key_exists('ESTADO DE CARGA', $value)) {
    $gestion->ESTADOCARGA= $value['ESTADO DE CARGA'];}


if (array_key_exists('FECHA ACTUALIZACIÓN', $value)) {
if($value['FECHA ACTUALIZACIÓN']!=''){
 $gestion->FECHAACTUALIZACION= date("d/m/Y", ((($value['FECHA ACTUALIZACIÓN'])- 25569) * 86400) );
}else{$gestion->FECHAACTUALIZACION= null;}}


    $gestion->save();



$estrategia=new Gestionestrategias();
if (array_key_exists('N°', $value)) {
$estrategia->ID_GESTION= strtoupper($value['N°']);}
if (array_key_exists('N° ESTRATEGIA', $value)) {
$estrategia->NUMERO_ESTRATEGIA= strtoupper($value['N° ESTRATEGIA']);}
if (array_key_exists('ESTRATEGIA', $value)) {
$estrategia->ESTRATEGIA= strtoupper($value['ESTRATEGIA']);}

if (array_key_exists('FECHA INICIO', $value)) {
if($value['FECHA INICIO']!=''){
 $estrategia->FINICIO= date("d/m/Y", ((($value['FECHA INICIO'])- 25569) * 86400) );
}else
{$estrategia->FINICIO= null;}}

if (array_key_exists('FECHA FIN', $value)) {
if($value['FECHA FIN']!=''){
 $estrategia->FFIN= date("d/m/Y", ((($value['FECHA FIN'])- 25569) * 86400) );
}else{$estrategia->FFIN= null;}}

if (array_key_exists('FECHA ENVÍO DE LA ESTRATEGIA', $value)) {
if($value['FECHA ENVÍO DE LA ESTRATEGIA']!=''){
 $estrategia->FENVIO= date("d/m/Y", ((($value['FECHA ENVÍO DE LA ESTRATEGIA'])- 25569) * 86400) );
}else{$estrategia->FENVIO= null;}}

if (array_key_exists('RESPONSABLE DE LA ESTRATEGIA', $value)) {
$estrategia->AREA_RESPONSABLE= strtoupper($value['RESPONSABLE DE LA ESTRATEGIA']);}
if (array_key_exists('ENTREGABLE', $value)) {
$estrategia->ENTREGABLE= strtoupper($value['ENTREGABLE']);}
if (array_key_exists('PORCENTAJE AVANCE', $value)) {
$estrategia->PORCENTAJE= strtoupper($value['PORCENTAJE AVANCE']);}

$estatus='';
if (array_key_exists('ESTADO DE CUMPLIMIENTO', $value)) {
if(strtoupper($value['ESTADO DE CUMPLIMIENTO'])=='CUMPLIDO')
{
    $estatus='005';
}
if(strtoupper($value['ESTADO DE CUMPLIMIENTO'])=='RECIBIDO')
{
    $estatus='005';
}
if(strtoupper($value['ESTADO DE CUMPLIMIENTO'])=='NO INICIADA')
{
    $estatus='001';
}
if(strtoupper($value['ESTADO DE CUMPLIMIENTO'])=='INCUMPLIDO')
{
    $estatus='003';
}
if(strtoupper($value['ESTADO DE CUMPLIMIENTO'])=='EN PROCESO')
{
    $estatus='002';
}
if(strtoupper($value['ESTADO DE CUMPLIMIENTO'])=='APROBADO')
{
    $estatus='004';
}
if(strtoupper($value['ESTADO DE CUMPLIMIENTO'])=='RECHAZADO ')
{
    $estatus='006';
}}
$estrategia->CESTATUSESTRATEGIA= $estatus;
    $estrategia->save();





$hallazgo=new Gestionhallazgo();
if (array_key_exists('N°', $value)) {
$hallazgo->ID_GESTION= strtoupper($value['N°']);}
if (array_key_exists('N° HALLAZGOS', $value)) {
$hallazgo->NUMERO_HALLAZGO= strtoupper($value['N° HALLAZGOS']);}
if (array_key_exists('DESCRIPCIÓN', $value)) {
$hallazgo->HALLAZGO= strtoupper($value['DESCRIPCIÓN']);}
if (array_key_exists('RIESGO', $value)) {
$hallazgo->RIESGO= strtoupper($value['RIESGO']);}
$hallazgo->save();


$recomendaciones=new Gestionrecomendaciones();
if (array_key_exists('N°', $value)) {
$recomendaciones->ID_GESTION= strtoupper($value['N°']);}
if (array_key_exists('N° RECOMENDACIÓ', $value)) {
$recomendaciones->NUMERO_RECOMENDACION= strtoupper($value['N° RECOMENDACIÓ']);}
if (array_key_exists('RECOMENDACIÓN', $value)) {
$recomendaciones->RECOMENDACION= strtoupper($value['RECOMENDACIÓN']);}
$recomendaciones->save();


}

////////////////////////////////////////INSERTAR ALERTAS
else

{

    $estatusbase='';
    $estatusbasenombre='';
    $diasalerta=0;
    //obtener dias de alerta
    $dias = Parametros::All();

 foreach($dias as $dia)
                {
$diasalerta=$dia->ALERTA;
                }
    //obtener dias de alerta


$compararse = Gestionestrategias::where(
                     [
                         ['ID_GESTION',$gestionauditoria->ID_GESTION]
                     ])->get();

 foreach($compararse as $comparar)
                {
$estatusbase=$comparar->CESTATUSESTRATEGIA;
                }
$compararsenom = Estatus::where(
                     [
                         ['CESTATUSESTRATEGIA',$estatusbase]
                     ])->get();

 foreach($compararsenom as $compararnom)
                {
$estatusbasenombre=$compararnom->NOMBRE;
                }

//COMMPARAR CON EL ESTATUS DE LOTE
                if($estatusbasenombre!=strtoupper($value['ESTADO DE CUMPLIMIENTO']))
                {
//SI ES DIFERENTE INSERTAR EN LAS ALERTAS
        //Crear el Responsable
    $fechaActual = date("d-m-Y");
$mod_date = strtotime($fechaActual. '+' . $diasalerta . 'days');
$fehafin=date("d-m-Y",$mod_date);



    $alertas=new Alertas();
    $alertas->ALERTA= ('EL SISTEMA DE CONTROL DE RECOMENDACIONES A ENCONTRADO DIFERENCIAS DE ESTADO EN LA RECOMENDACIÓN CON CÓDIGO: ' . $gestionauditoria->ID_GESTION . ' EN LA SEPS: ' . strtoupper($value['ESTADO DE CUMPLIMIENTO']) . ' EN EN EL SISTEMA: '. $estatusbasenombre);
    $alertas->FECHAINICIO=$fechaActual;
    $alertas->FECHAFIN=$fehafin;
    $alertas->ID_GESTION=$gestionauditoria->ID_GESTION;
    $alertas->save();

                }


}
////////////////////////////////////////INERTAR ALERTAS


}

         //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El archivo no se ha cargado correctamente');
         }
         return response()->json($data,$data['code']);
     } 





///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//sacar toos los Responsables de la bdd
    public function getAllEstatus(){
        $integer =0;
        $estatus= Estatus::orderBy('CESTATUSESTRATEGIA')->get();
 foreach($estatus as $estatu)
                {
         $estatuss[$integer] = array(     
             'CESTATUSESTRATEGIA'=>trim($estatu->CESTATUSESTRATEGIA),
              'NOMBRE'=>trim($estatu->NOMBRE)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'estatus'=>$estatuss);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }



///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//sacar toos los Responsables de la bdd
    public function getAllPeriodos(){
        $integer =0;
        $periodos= Periodos::orderBy('ID_PERIODO')->get();
 foreach($periodos as $periodo)
                {
         $periodoss[$integer] = array(     
             'ID_PERIODO'=>trim($periodo->ID_PERIODO),
              'NOMBRE'=>trim($periodo->NOMBRE),
              'ENERO'=>trim($periodo->ENERO),
              'FEBRERO'=>trim($periodo->FEBRERO),
              'MARZO'=>trim($periodo->MARZO),
              'ABRIL'=>trim($periodo->ABRIL),
              'MAYO'=>trim($periodo->MAYO),
              'JUNIO'=>trim($periodo->JUNIO),
              'JULIO'=>trim($periodo->JULIO),
              'AGOSTO'=>trim($periodo->AGOSTO),
              'SEPTIEMBRE'=>trim($periodo->SEPTIEMBRE),
              'OCTUBRE'=>trim($periodo->OCTUBRE),
              'NOVIEMBRE'=>trim($periodo->NOVIEMBRE),
              'DICIEMBRE'=>trim($periodo->DICIEMBRE)



              
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'periodos'=>$periodoss);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }




///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//sacar toos los Responsables de la bdd con filtros
    public function getAllFiltro($nombres){
        $parametronombre=strtoupper($nombres);
        $integer =0;
        $contador =0;



    $responsables = Responsables::where(
                     [
                         ['NOMBRES','like','%'.$parametronombre.'%']
                     ])->orWhere('APELLIDOS','like','%'.$parametronombre.'%')->orderBy('ID')->get();


 foreach($responsables as $responsable)
                {
         $responsabless[$integer] = array(     
             'ID'=>trim($responsable->ID),
              'NOMBRES'=>trim($responsable->NOMBRES),
              'APELLIDOS'=>trim($responsable->APELLIDOS),
              'EMAIL'=>trim($responsable->EMAIL)
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'responsanbles'=>$responsabless);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);
                            }



///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS RESPONSABLES
    public function nuevoAsignacion(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        


     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'ID_GESTION'=>'required',//Comprobar si el usuario existe con unique
        'NUMERO_ASIGNACION'=>'required',
        'ID_PERIODO'=>'required',
        'CUSUARIO_AUDITORIA'=>'required',
        'CUSUARIO_ASIGNACION'=>'required',
        'ARCHIVO_ASIGNACION'=>'required',
        'DETALLE_ASIGNACION'=>'required'
    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'La asignacion no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
             


        //TRAER EL RESPONSALE DEL USUARIO
     $responsablesss = Responsables::where(
                     [
                         ['USUARIO',$params_array['CUSUARIO_AUDITORIA']]
                     ])->get();


 foreach($responsablesss as $responsabless)
                {
                    $nombreauditoria=$responsabless->ID;
                }




        //Crear el Responsable
    $asignacion=new Gestionasignacion();
    $asignacion->ID_GESTION= strtoupper($params_array['ID_GESTION']);
    $asignacion->NUMERO_ASIGNACION=strtoupper($params_array['NUMERO_ASIGNACION']);
    $asignacion->ID_PERIODO= strtoupper($params_array['ID_PERIODO']);

if (array_key_exists('DIA', $params_array)) {
    $asignacion->DIA= $params_array['DIA'];
}

if (array_key_exists('FASIGNACION', $params_array)) {

if($params_array['FASIGNACION']=='')
{
$asignacion->FASIGNACION=null;
}else
{
    $asignacion->FASIGNACION= $params_array['FASIGNACION'];
}
}


    $asignacion->CUSUARIO_AUDITORIA= $nombreauditoria;
    $asignacion->CUSUARIO_ASIGNACION= $params_array['CUSUARIO_ASIGNACION'];

    if (array_key_exists('CUSUARIO_CORESPONSABLE', $params_array)) {
$asignacion->CUSUARIO_CORESPONSABLE2= $params_array['CUSUARIO_CORESPONSABLE'];
}

    
    $asignacion->ARCHIVO_ASIGNACION= $params_array['ARCHIVO_ASIGNACION'];
    $asignacion->DETALLE_ASIGNACION= $params_array['DETALLE_ASIGNACION'];

if (array_key_exists('CUSUARIO_CORESPONSABLE2', $params_array)) {
$asignacion->CUSUARIO_CORESPONSABLE2= $params_array['CUSUARIO_CORESPONSABLE2'];
}
if (array_key_exists('CUSUARIO_CORESPONSABLE3', $params_array)) {
$asignacion->CUSUARIO_CORESPONSABLE3= $params_array['CUSUARIO_CORESPONSABLE3'];
}
   $asignacion->FCONTABLE= $params_array['FCONTABLE'];
   $asignacion->RENOVADA= $params_array['RENOVADA'];
   $asignacion->ID_ANTERIOR= $params_array['ID_ANTERIOR'];

    
//Guardar el Usuario
  $asignacion->save();
    
//CAMBIAR EL ESTADO A EN PROCESO

  $porcentaje_update =  Gestionestrategias::where('ID_GESTION',$params_array['ID_GESTION'])->update(['CESTATUSESTRATEGIA'=>'002']);

  //enviar la respuesta
          $data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'La asignación se ha creado correctamente'
        );
    }
        }else
        {
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }

        return response()->json($data,$data['code']);
    }



///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//sacar toos los Responsables de la bdd con filtros
    public function getAsignacionesP($id){
        $integer =0;
        $contador =0;
        $nombreperiodo ='';
        $nombreresponsable ='';
        $apellidoresponsable ='';

        $nombrecoresponsable1 ='';
        $apellidocoresponsable1 ='';

        $nombrecoresponsable2 ='';
        $apellidocoresponsable2 ='';

        $nombrecoresponsable3 ='';
        $apellidocoresponsable3 ='';


     $asignacioncods = Gestionasignacion::where(
                     [
                         ['ID_GESTION',$id]
                     ])->get();


 foreach($asignacioncods as $asignacioncod)
                {

//TRAER PERIODOS
     $periodos = Periodos::where(
                     [
                         ['ID_PERIODO',$asignacioncod->ID_PERIODO]
                     ])->get();
 foreach($periodos as $periodo)
                {
                    $nombreperiodo=trim($periodo->NOMBRE);
                }
//TRAER EL NOMBRE DEL RESPONSABLE
     $responsables = Responsables::where(
                     [
                         ['ID',$asignacioncod->CUSUARIO_ASIGNACION]
                     ])->get();
 foreach($responsables as $responsable)
                {
                    $nombreresponsable=trim($responsable->NOMBRES);
                    $apellidoresponsable=trim($responsable->APELLIDOS);
                }
     $nombreresponsable=$nombreresponsable . " " . $apellidoresponsable;


//TRAER EL NOMBRE DEL CORESPONSABLE
     $coresponsables = Responsables::where(
                     [
                         ['ID',$asignacioncod->CUSUARIO_CORESPONSABLE]
                     ])->get();
 foreach($coresponsables as $coresponsable)
                {
                    $nombrecoresponsable1=trim($coresponsable->NOMBRES);
                    $apellidocoresponsable1=trim($coresponsable->APELLIDOS);
                }
     $nombrecoresponsable1=$nombrecoresponsable1 . " " . $apellidocoresponsable1;


//TRAER EL NOMBRE DEL CORESPONSABLE2 si existe
     if($asignacioncod->CUSUARIO_CORESPONSABLE2!='')
     {
     $coresponsables2 = Responsables::where(
                     [
                         ['ID',$asignacioncod->CUSUARIO_CORESPONSABLE2]
                     ])->get();
 foreach($coresponsables2 as $coresponsable2)
                {
                    $nombrecoresponsable2=trim($coresponsable2->NOMBRES);
                    $apellidocoresponsable2=trim($coresponsable2->APELLIDOS);
                }
     $nombrecoresponsable2=$nombrecoresponsable2 . " " . $apellidocoresponsable2;
    }




//TRAER EL NOMBRE DEL CORESPONSABLE3 SI EXISTE
     if($asignacioncod->CUSUARIO_CORESPONSABLE3!='')
     {
     $coresponsables3 = Responsables::where(
                     [
                         ['ID',$asignacioncod->CUSUARIO_CORESPONSABLE3]
                     ])->get();
 foreach($coresponsables3 as $coresponsable3)
                {
                    $nombrecoresponsable3=trim($coresponsable3->NOMBRES);
                    $apellidocoresponsable3=trim($coresponsable3->APELLIDOS);
                }
     $nombrecoresponsable3=$nombrecoresponsable3 . " " . $apellidocoresponsable3;
    }


//TRAER TIPOCONTROL
     $tiposcontroless = Gestionauditoria::where(
                     [
                        ['ID_GESTION',$id]
                     ])->get();
 foreach($tiposcontroless as $tiposcontroles)
                {
                    $tipo=trim($tiposcontroles->ID_CONTROL);
                }


//PORCENTAGE
     $porcentagesss = Gestionestrategias::where(
                     [
                        ['ID_GESTION',$id]
                     ])->get();
 foreach($porcentagesss as $porcentagess)
                {
                    $porcentajebase=trim($porcentagess->PORCENTAJE);
                    $estatus=trim($porcentagess->CESTATUSESTRATEGIA);
                }



         $asignacioncodss[$integer] = array(   


             'ID_PERIODO'=>trim($asignacioncod->ID_PERIODO),
             'NOMBREPERIODO'=>$nombreperiodo,
             'INTERNO'=>trim($asignacioncod->NUMERO_ASIGNACION),
              'DIA'=>trim($asignacioncod->DIA),
              'FASIGNACION'=>trim($asignacioncod->FASIGNACION),
              'CUSUARIO_ASIGNACION'=>trim($asignacioncod->CUSUARIO_ASIGNACION),
              'NOMBRES_RESPONSABLE'=>trim($nombreresponsable),
              'CUSUARIO_CORESPONSABLE'=>trim($asignacioncod->CUSUARIO_CORESPONSABLE),
              'NOMBRES_CORESPONSABLE'=>trim($nombrecoresponsable1),
              'CUSUARIO_CORESPONSABLE2'=>trim($asignacioncod->CUSUARIO_CORESPONSABLE2),
              'NOMBRES_CORESPONSABLE2'=>trim($nombrecoresponsable2),
              'CUSUARIO_CORESPONSABLE3'=>trim($asignacioncod->CUSUARIO_CORESPONSABLE3),
              'NOMBRES_CORESPONSABLE3'=>trim($nombrecoresponsable3),
              'DETALLE_ASIGNACION'=>trim($asignacioncod->DETALLE_ASIGNACION),
              'DETALLE_ENTREGA'=>trim($asignacioncod->DETALLE_ENTREGA),
              'PORCENTAGE'=>trim($porcentajebase),
              'TIPOCONTROL'=>$tipo,
              'ESTATUS'=>$estatus
              

        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'asignaciones'=>$asignacioncodss);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);
                            }

/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//////////////////SCAR RECOMENDACIONES CON PARAMETROS//////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
                            //SACAR TODOS LAS RECOMENDACIONES 
    public function getRecomendacionesParam($tipocontrol,$codigo,$informe,$codinterno,$cedula,$estatus,$condicion1,$finicio1,$ffin1,$condicion2,$finicio2,$ffin2,$canceladas){
        $parametrotipocontrol=strtoupper($tipocontrol);
        $parametrocodigo=strtoupper($codigo);
        $parametroinforme=strtoupper($informe);
        $parametrointerno=strtoupper($codinterno);
        $parametrocedula=strtoupper($cedula);
        $parametroestatus=strtoupper($estatus);
        $contador=0;
        $contadorfi=0;
        $contadorff=0;
        $contador1=0;
        $integer =0; 
        $estado='';
        $responsable='';



//////////////////////////////////////////////////////////     
////////////////////////////////////////estado///////////
//////////////////////////////////////////////////////////
               $estatus='005';
if($canceladas=='NOR')
{
$nocanceladas = Gestionestrategias::whereNotIn('CESTATUSESTRATEGIA',[$estatus])->orderBy('ID_GESTION')->get();
}
if($canceladas=='CAN')
{
$nocanceladas = Gestionestrategias::whereIn('CESTATUSESTRATEGIA',[$estatus])->orderBy('ID_GESTION')->get();
}
 foreach($nocanceladas as $nocancelada)
                {
              $codigosgestionc[$contador] = array(     
             'ID_GESTION'=>trim($nocancelada->ID_GESTION)
        );
         $contador++;    
                }
//////////////////////////////////////////////////////////     
////////////////////////////////////////estado///////////
//////////////////////////////////////////////////////////


 //////////////////////////////////////////////////////////     
////////////////////////////////////////FINICIO///////////
//////////////////////////////////////////////////////////
$codigosfechainicio[]='';

if($condicion1==1)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','=',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==2)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','>',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==3)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','<',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==4)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','>=',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==5)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','<=',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==6)
{


$fechas=Gestionestrategias::whereBetween('FINICIO',[$finicio1, $ffin1])->orderBy('ID_GESTION')->get();
}
if($condicion1>0)
{
 foreach($fechas as $fecha)
                {
              $codigosfechainicio[$contadorfi] = array(     
             'ID_GESTION'=>trim($fecha->ID_GESTION)
        );
         $contadorfi++;    
                }


if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{

$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}

}

//////////////////////////////////////////////////////////     
////////////////////////////////////////FINICIO///////////
//////////////////////////////////////////////////////////



 //////////////////////////////////////////////////////////     
////////////////////////////////////////FFIN///////////
//////////////////////////////////////////////////////////

$codigosfechafin[]='';

if($condicion2==7)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','=',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==8)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','>',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==9)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','<',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==10)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','>=',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==11)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','<=',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==12)
{

$fechaFs=Gestionestrategias::whereBetween('FFIN',[$finicio2, $ffin2])->orderBy('ID_GESTION')->get();
}

if($condicion2>0)
{
 foreach($fechaFs as $fechaF)
                {
              $codigosfechafin[$contadorff] = array(     
             'ID_GESTION'=>trim($fechaF->ID_GESTION)
        );
         $contadorff++;    
                }


if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{

$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}

}

//////////////////////////////////////////////////////////     
////////////////////////////////////////FFIN///////////
//////////////////////////////////////////////////////////



if($codigosfechafin[0]=='' && $codigosfechainicio[0]!='')
{
$codigosfechafin=$codigosfechainicio;
}
if($codigosfechafin[0]!='' && $codigosfechainicio[0]=='')
{
$codigosfechainicio=$codigosfechafin;
}

//////////////////////////////////////////////////////////     
////////////////////////////////////////ESTATUS///////////
//////////////////////////////////////////////////////////
//SOLO ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

                if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
}
//SOLO CODIGO Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

                          if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INFORME Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

               if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

// CODIGO INFORME INTERNO Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      //['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }

if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INFORME INTERNO CEDULA Y ESTATUS ese
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }

 
if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();

                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INFORME INTERNO CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INTERNO CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();

                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INTERNO Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      //['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INTERNO CEDULA Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

// AQUI ESTOY TRABAJANDO
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus!=0)
{
$contador=0;
$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      //['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

// CODIGO CEDULA Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula], 
                      //['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INFORME CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula], 
                      //['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INFORME INTERNO Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                     // ['CUSUARIO_ASIGNACION',$parametrocedula], 
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
//SOLO INFORME Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
//SOLO INTERNO Y ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      //['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
//SOLO CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus!=0)
{
    $estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }


    $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
 //////////////////////////////////////////////////////////     
////////////////////////////////////////ESTATUS//////////////////
//////////////////////////////////////////////////////////









//////////////////////////////////////////////////////////
//SOLO CEDULA
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//CODIGO Y CEDULA
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0  && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}



//////////////////////////////////////////////////////////
//INFORME Y CEDULA
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//CODIGO INFORME Y CEDULA
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//INTERNO Y CEDULA
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//CODIGO INTERNO Y CEDULA
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
  if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

//////////////////////////////////////////////////////////
//INFORME INTERNO Y CEDULA
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                       // ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                       // ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

//////////////////////////////////////////////////////////
//CODIGO INFORME INTERNO Y CEDULA
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}



//////////////////////////////////////////////////////////
//SOLO INTERNO
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

//SOLO EL CODIGO
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{
if($condicion1>0 || $condicion2>6)
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
       }
}

//SOLO EL INFORME
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
       }
}

//CODIGO E INFORME
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{
if($condicion1>0 || $condicion2>6)
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
       }
}



//////////////////////////////////////////////////////////
//CODIGO E INTERNO
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
}



//////////////////////////////////////////////////////////
//INFORME E INTERNO
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}



//////////////////////////////////////////////////////////
//CODIGO INFORME E INTERNO
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


 foreach($gestiones as $gestion)
                {

$nombreresponsable='';
$apellidoresponsable='';
$codigointerno='';

//ESTADO
$estatus = Estatus::where('CESTATUSESTRATEGIA',$gestion->fgestionestrategia->CESTATUSESTRATEGIA)->get();
 foreach($estatus as $estatu)
                {
$estado=trim($estatu->NOMBRE);
                }


//RESPONSABLE
$responsableids = Gestionasignacion::where('ID_GESTION',trim($gestion->ID_GESTION))->get();
 foreach($responsableids as $responsableid)
                {
$codigointerno=$responsableid->NUMERO_ASIGNACION;
//TRAER EL NOMBRE DEL RESPONSABLE
     $responsables = Responsables::where(
                     [
                         ['ID',$responsableid->CUSUARIO_ASIGNACION]
                     ])->get();
 foreach($responsables as $responsable)
                {
                    $nombreresponsable=trim($responsable->NOMBRES);
                    $apellidoresponsable=trim($responsable->APELLIDOS);
                }
     $nombreresponsable=$nombreresponsable . " " . $apellidoresponsable;
                }



//consultr recomendaciones


//TRAER LA RECOEMNDACION
$detallerecomendacion='';
     $recomendacioness = Gestionrecomendaciones::where(
                     [
                         ['ID_GESTION',$gestion->ID_GESTION]
                     ])->get();
 foreach($recomendacioness as $recomendacione)
                {
$detallerecomendacion=trim($recomendacione->RECOMENDACION);
                }





         $gestioness[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
              'INFORME'=>trim($gestion->INFORME),
              'INTERNO'=>trim($codigointerno),
              'RESPONSABLE'=>$nombreresponsable,
              'ESTRATEGIA'=>trim($gestion->fgestionestrategia->ESTRATEGIA),
              'RECOMENDACION'=>trim($detallerecomendacion),
              'FINICIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FINICIO)),
              'FFIN'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FFIN)),
              'PORCENTAJE'=>trim($gestion->fgestionestrategia->PORCENTAJE),
              'ESTADO'=>trim($estado),
              //TRAER EL PERIODO
             
             //'IDENTIFICACION'=>trim($gestion->fgestionhallazgo->HALLAZGO),

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$gestioness);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }


//////////////////////////////////////////////
////////////////////////////////////////////////////
//SACAR TODA LA INFORMACION PARA EL REPORTE
    public function getReporte($id){
        $integer =0; 
        $estado='';
        $control='';
      //  $gestiones= Gestionauditoria:: orderBy('ID_GESTION')->get();

                     $gestiones = Gestionauditoria::where('ID_CONTROL',$id)->orderBy('ID_GESTION')->get();



 foreach($gestiones as $gestion)
                {



//ESTATUS
$estatus = Estatus::where('CESTATUSESTRATEGIA',$gestion->fgestionestrategia->CESTATUSESTRATEGIA)->get();

 foreach($estatus as $estatu)
                {
$estado=trim($estatu->NOMBRE);
                }

//RESPONSABLE
                $nombreresponsable='';
                $apellidoresponsable='';
                $nombreresponsable='';
                $codigointerno='';
$responsableids = Gestionasignacion::where('ID_GESTION',trim($gestion->ID_GESTION))->get();
 foreach($responsableids as $responsableid)
                {

                $codigointerno=$responsableid->NUMERO_ASIGNACION;
//TRAER EL NOMBRE DEL RESPONSABLE
     $responsables = Responsables::where(
                     [
                         ['ID',$responsableid->CUSUARIO_ASIGNACION]
                     ])->get();
 foreach($responsables as $responsable)
                {
                    $nombreresponsable=trim($responsable->NOMBRES);
                    $apellidoresponsable=trim($responsable->APELLIDOS);
                }
     $nombreresponsable=$nombreresponsable . " " . $apellidoresponsable;
                }


//CORESPONSABLE
                $nombrerescoponsable='';
                $apellidocoresponsable='';
                $nombrecoresponsable='';
$coresponsableids = Gestionasignacion::where('ID_GESTION',trim($gestion->ID_GESTION))->get();
 foreach($coresponsableids as $coresponsableid)
                {
//TRAER EL NOMBRE DEL RESPONSABLE
     $coresponsables = Responsables::where(
                     [
                         ['ID',$coresponsableid->CUSUARIO_CORESPONSABLE]
                     ])->get();
 foreach($coresponsables as $coresponsable)
                {
                    $nombrerescoponsable=trim($coresponsable->NOMBRES);
                    $apellidocoresponsable=trim($coresponsable->APELLIDOS);
                }
     $nombrecoresponsable=$nombrerescoponsable . " " . $apellidocoresponsable;
                }


         $gestioness[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
              'INFORME'=>trim($gestion->INFORME),
              'HALLAZGO'=>trim($gestion->fgestionhallazgo->HALLAZGO),
              'RECOMENDACION'=>trim($gestion->fgestionrecomendacion->RECOMENDACION),  
              'ESTRATEGIA'=>trim($gestion->fgestionestrategia->ESTRATEGIA),
              'FENVIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FENVIO)),
              'FINICIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FINICIO)),
              'FFIN'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FFIN)),
              'PORCENTAJE'=>trim($gestion->fgestionestrategia->PORCENTAJE),
              'ESTADO'=>trim($estado),
              'TIPOCONTROL'=>trim($gestion->ID_CONTROL),
              'RESPONSABLE'=>trim($nombreresponsable),
              'CORESPONSABLE'=>trim($nombrecoresponsable),
              'INTERNO'=>($codigointerno),
              
              //TRAER EL PERIODO
             
             //'IDENTIFICACION'=>trim($gestion->fgestionhallazgo->HALLAZGO),

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'reportes'=>$gestioness);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }


}
