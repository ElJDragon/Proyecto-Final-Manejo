<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Responsables;
use App\Models\Departamentos;
use App\Models\Alertas;
use App\Models\Direccion;
use App\Models\Tiposcontrol;
use App\Models\Secuenciales;
use App\Models\Cursodep;
use App\Helpers\JwtAuth;

class ResponsablesController extends Controller
{

//DESCOMANTAR AL FINAL
 //   public function __construct() {
 //       $this->middleware('Api.auth',['except'=>['index','oneRegister']]);
 //   }

///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//eliminar un responsable
 public function eliminar($id,Request $request)
    {
     //comseguir el post
     $responsables= Responsables::find($id);
     
     if(!empty($responsables))
        {
     //borrarlo
     $responsables->delete();
     //devolver
     
     $data = array(
          'status'=>'success',
          'code'=>200, 
          'message'=>$responsables
        );
        }else
        {
            $data = array(
           'status'=>'success',
          'code'=>200, 
          'message'=>'No Existe el registro'
             );
        }
     return response()->json($data,$data['code']);
 }


///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//sacar toos los Responsables de la bdd
    public function getAll(){
        $integer =0;
        $responsables= Responsables::orderBy('ID')->get();
 foreach($responsables as $responsable)
                {
         $responsabless[$integer] = array(     
             'ID'=>trim($responsable->ID),
              'COD_DEPARTAMENTO'=>trim($responsable->COD_DEPARTAMENTO),
              'NOMBRES'=>trim($responsable->NOMBRES),
              'APELLIDOS'=>trim($responsable->APELLIDOS),
              'EMAIL'=>trim($responsable->EMAIL),
              'TELEFONO'=>trim($responsable->TELEFONO),
              'DEPARTAMENTO'=>trim($responsable->fdepartamentos->NOMBRE)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'responsanbles'=>$responsabless);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }


///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//sacar toos los Responsables de la bdd
    public function getAllControles(){
        $integer =0;
        $tiposcontroles= Tiposcontrol::orderBy('ID_CONTROL')->get();
 foreach($tiposcontroles as $tiposcontrole)
                {
         $tiposcontroless[$integer] = array(     
             'ID_CONTROL'=>trim($tiposcontrole->ID_CONTROL),
              'NOMBRE'=>trim($tiposcontrole->NOMBRE),
              'OBSERVACION'=>trim($tiposcontrole->OBSERVACION)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'controles'=>$tiposcontroless);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }



///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//CONSULTAR TODOS LOS DEPARTAMENTOS PARA LA LISTA DE VALORES

    public function getControlesP($nombres){
        $integer =0;
        $parametronombre=strtoupper($nombres);

             $tiposcontroles = Tiposcontrol::where(
                     [ 
                         ['NOMBRE','like','%'.$parametronombre.'%']
                     ])->orderBy('ID_CONTROL')->get();

 foreach($tiposcontroles as $tiposcontrole)
                {
         $tiposcontroless[$integer] = array(     
             'ID_CONTROL'=>trim($tiposcontrole->ID_CONTROL),
              'NOMBRE'=>trim($tiposcontrole->NOMBRE),
              'OBSERVACION'=>trim($tiposcontrole->OBSERVACION)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'controles'=>$tiposcontroless);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }


///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//sacar toos los Responsables de la bdd con filtros
    public function getAllFiltro($nombres,$apellidos,$departamento){
        $parametronombre=strtoupper($nombres);
        $parametroapellido=strtoupper($apellidos);
        $parametrodepa=strtoupper($departamento);
        $integer =0;
        $contador =0;
if($parametronombre!=0 && $parametroapellido==0 && $parametrodepa==0)
{
     $responsables = Responsables::where(
                     [ 
                         ['NOMBRES','like','%'.$parametronombre.'%']
                     ])->orderBy('ID')->get();
}
if($parametroapellido!=0 && $parametronombre==0 && $parametrodepa==0)
{
     $responsables = Responsables::where(
                     [ 
                         ['APELLIDOS','like','%'.$parametroapellido.'%']
                     ])->orderBy('ID')->get();
}
//solo departamemnto
if($parametroapellido==0 && $parametronombre==0 && $parametrodepa!=0)
{

     $departamentos = Departamentos::where(
                     [ 
                         ['NOMBRE','like','%'.$parametrodepa.'%']
                     ])->get();   
 foreach($departamentos as $departamento)
                {
              $codigosdep[$contador] = array(     
             'COD_DEPARTAMENTO'=>trim($departamento->COD_DEPARTAMENTO)
        );
         $contador++;
                }

$responsables = Responsables::whereIn('COD_DEPARTAMENTO',$codigosdep)->orderBy('ID')->get();

}


//COMBINADOS NOMBRES Y APELLIDOS
if($parametronombre!=0 && $parametroapellido!=0 && $parametrodepa==0)
{
    $responsables = Responsables::where(
                     [ 
                         ['NOMBRES','like','%'.$parametronombre.'%'],
                         ['APELLIDOS','like','%'.$parametroapellido.'%']
                     ])->orderBy('ID')->get();
}

//COMBINADOS NOMBRES Y DEPARTAMENTO
if($parametronombre!=0 && $parametroapellido==0 && $parametrodepa!=0)
{

     $departamentos = Departamentos::where(
                     [ 
                         ['NOMBRE','like','%'.$parametrodepa.'%']
                     ])->get();   
 foreach($departamentos as $departamento)
                {
              $codigosdep[$contador] = array(     
             'COD_DEPARTAMENTO'=>trim($departamento->COD_DEPARTAMENTO)
        );
         $contador++;
                }
    $responsables = Responsables::where(
                     [ 
                         ['NOMBRES','like','%'.$parametronombre.'%']
                         //['APELLIDOS','like','%'.$parametroapellido.'%']
                     ])->whereIn('COD_DEPARTAMENTO',$codigosdep)->orderBy('ID')->get();

}

//COMBINADOS APELLIDOS Y DEPARTAMENTO
if($parametronombre==0 && $parametroapellido!=0 && $parametrodepa!=0)
{

     $departamentos = Departamentos::where(
                     [ 
                         ['NOMBRE','like','%'.$parametrodepa.'%']
                     ])->get();   
 foreach($departamentos as $departamento)
                {
              $codigosdep[$contador] = array(     
             'COD_DEPARTAMENTO'=>trim($departamento->COD_DEPARTAMENTO)
        );
         $contador++;
                }
    $responsables = Responsables::where(
                     [ 
                         //['NOMBRES','like','%'.$parametronombre.'%']
                         ['APELLIDOS','like','%'.$parametroapellido.'%']
                     ])->whereIn('COD_DEPARTAMENTO',$codigosdep)->orderBy('ID')->get();

}

//COMBINADOS LAS 3
if($parametronombre!=0 && $parametroapellido!=0 && $parametrodepa!=0)
{

     $departamentos = Departamentos::where(
                     [ 
                         ['NOMBRE','like','%'.$parametrodepa.'%']
                     ])->get();   
 foreach($departamentos as $departamento)
                {
              $codigosdep[$contador] = array(     
             'COD_DEPARTAMENTO'=>trim($departamento->COD_DEPARTAMENTO)
        );
         $contador++;
                }
    $responsables = Responsables::where(
                     [ 
                         ['NOMBRES','like','%'.$parametronombre.'%'],
                         ['APELLIDOS','like','%'.$parametroapellido.'%']
                     ])->whereIn('COD_DEPARTAMENTO',$codigosdep)->orderBy('ID')->get();

}


 foreach($responsables as $responsable)
                {
         $responsabless[$integer] = array(     
             'ID'=>trim($responsable->ID),
              'COD_DEPARTAMENTO'=>trim($responsable->COD_DEPARTAMENTO),
              'NOMBRES'=>trim($responsable->NOMBRES),
              'APELLIDOS'=>trim($responsable->APELLIDOS),
              'EMAIL'=>trim($responsable->EMAIL),
              'TELEFONO'=>trim($responsable->TELEFONO),
              'DEPARTAMENTO'=>trim($responsable->fdepartamentos->NOMBRE)
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'responsanbles'=>$responsabless);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);
                            }

///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS RESPONSABLES
    public function nuevoResponsable(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        
     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'COD_DEPARTAMENTO'=>'required',//Comprobar si el usuario existe con unique
        'NOMBRES'=>'required',
        'APELLIDOS'=>'required',
        'EMAIL'=>'required|email',
        'TELEFONO'=>'required'
    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El Responsable no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
             
        //Crear el Responsable
    $responsable=new Responsables();
    $responsable->COD_DEPARTAMENTO= strtoupper($params_array['COD_DEPARTAMENTO']);
    $responsable->NOMBRES= strtoupper($params_array['NOMBRES']);
    $responsable->APELLIDOS= strtoupper($params_array['APELLIDOS']);
    $responsable->EMAIL= $params_array['EMAIL'];
    $responsable->TELEFONO= $params_array['TELEFONO'];
    
//Guardar el Usuario
  $responsable->save();
    
  //enviar la respuesta
          $data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'El responsable se ha creado correctamente'
        );
    }
        }else
        {
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }

        return response()->json($data,$data['code']);
    }




///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//CONSULTAR TODOS LOS DEPARTAMENTOS PARA LA LISTA DE VALORES

    public function getDepartamentos(){
        $integer =0;
        $departamentos= Departamentos::orderBy('COD_DEPARTAMENTO')->get();
 foreach($departamentos as $departamento)
                {
         $departamentoss[$integer] = array(     
             'COD_DEPARTAMENTO'=>trim($departamento->COD_DEPARTAMENTO),
              'NOMBRE'=>trim($departamento->NOMBRE)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'departamentos'=>$departamentoss);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }


///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//CONSULTAR TODOS LOS DEPARTAMENTOS PARA LA LISTA DE VALORES

    public function getDepartamentosP($nombres){
        $integer =0;
        $parametronombre=strtoupper($nombres);

             $departamentos = Departamentos::where(
                     [ 
                         ['NOMBRE','like','%'.$parametronombre.'%']
                     ])->orderBy('COD_DEPARTAMENTO')->get();

 foreach($departamentos as $departamento)
                {
         $departamentoss[$integer] = array(     
             'COD_DEPARTAMENTO'=>trim($departamento->COD_DEPARTAMENTO),
              'NOMBRE'=>trim($departamento->NOMBRE)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'departamentos'=>$departamentoss);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }



///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//CONSULTAR TODOS LOS DEPARTAMENTOS PARA LA LISTA DE VALORES

    public function getdepacursos($curso){
        $integer =0;
        $parametrocurso=strtoupper($curso);

        $departamentos= Departamentos::orderBy('COD_DEPARTAMENTO')->get();


 foreach($departamentos as $departamento)
                {
$esta=0;

       $asignado = Cursodep::where(
                     [ 
                         ['CODDEPARTAMENTO',trim($departamento->COD_DEPARTAMENTO)],
                          ['CODIGOCURSO',trim($parametrocurso)]
                     ])->get();

if ($asignado->count() > 0) {
$esta=1;
} else {
$esta=0;
}

         $departamentoss[$integer] = array(     
             'COD_DEPARTAMENTO'=>trim($departamento->COD_DEPARTAMENTO),
              'NOMBRE'=>trim($departamento->NOMBRE),
              'ESTA'=>$esta

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'departamentos'=>$departamentoss);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }
                            ///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//eliminar un departamentos
 public function eliminardepartamentos($id,Request $request)
    {
     //comseguir el post
     $departamentos= Departamentos::find($id);
     
     if(!empty($departamentos))
        {
     //borrarlo
     $departamentos->delete();
     //devolver
     
     $data = array(
          'status'=>'success',
          'code'=>200, 
          'message'=>$departamentos
        );
        }else
        {
            $data = array(
           'status'=>'success',
          'code'=>200, 
          'message'=>'No Existe el registro'
             );
        }
     return response()->json($data,$data['code']);
 }


                           ///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//eliminar un alertas
 public function eliminaralertas($id,Request $request)
    {
     //comseguir el post
     $departamentos= Alertas::find($id);
     
     if(!empty($departamentos))
        {
     //borrarlo
     $departamentos->delete();
     //devolver
     
     $data = array(
          'status'=>'success',
          'code'=>200, 
          'message'=>$departamentos
        );
        }else
        {
            $data = array(
           'status'=>'success',
          'code'=>200, 
          'message'=>'No Existe el registro'
             );
        }
     return response()->json($data,$data['code']);
 }

 ///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS DEPARTAMENTOS
    public function nuevoDepartamento(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        
     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'COD_DEPARTAMENTO'=>'required',//Comprobar si el usuario existe con unique
        'NOMBRE'=>'required'
    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El Departamento no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
             
        //Crear el Responsable
    $departamento=new Departamentos();
    $departamento->COD_DEPARTAMENTO= strtoupper($params_array['COD_DEPARTAMENTO']);
    $departamento->NOMBRE= strtoupper($params_array['NOMBRE']);

    
//Guardar el Usuario
  $departamento->save();
    
  //enviar la respuesta
          $data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'El departamento se ha creado correctamente'
        );
    }
        }else
        {
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }

        return response()->json($data,$data['code']);
    }

///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS CONTROL
    public function nuevoControl(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        
     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'ID_CONTROL'=>'required',//Comprobar si el usuario existe con unique
        'NOMBRE'=>'required'
    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El Tipo Control no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
             


        //Crear el Responsable
    $tipocontrol=new Tiposcontrol();
    $tipocontrol->ID_CONTROL= strtoupper($params_array['ID_CONTROL']);
    $tipocontrol->NOMBRE= strtoupper($params_array['NOMBRE']);
    $tipocontrol->OBSERVACION= strtoupper($params_array['OBSERVACION']);
    
//Guardar el Usuario
  $tipocontrol->save();
    

    //CREAR SECUENCIA
        $secuencia=new Secuenciales();
 $secuencia->CODIGO= strtoupper($params_array['ID_CONTROL']);
  $secuencia->NOMBRE= strtoupper($params_array['NOMBRE']);
   $secuencia->SECUENCIA= 0;
$secuencia->save();



  //enviar la respuesta
          $data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'El Control se ha creado correctamente'
        );
    }
        }else
        {
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }

        return response()->json($data,$data['code']);
    }


                            ///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//eliminar un controles
 public function eliminarcontroles($id,Request $request)
    {
     //comseguir el post
     $tiposcontrol= Tiposcontrol::find($id);
     
     if(!empty($tiposcontrol))
        {
     //borrarlo
     $tiposcontrol->delete();
     //devolver
     
     $data = array(
          'status'=>'success',
          'code'=>200, 
          'message'=>$tiposcontrol
        );
        }else
        {
            $data = array(
           'status'=>'success',
          'code'=>200, 
          'message'=>'No Existe el registro'
             );
        }
     return response()->json($data,$data['code']);
 }





///SISTEMA DE MONITOREO

///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS RESPONSABLES
    public function insertDireccion(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        
     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'ID'=>'required',//Comprobar si el usuario existe con 
        'CODIGO'=>'required'
    ]);

    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Campos requeridos no enviados',
          'error'=>$validate->errors()
        );
    }else
    {
$yaexiste = Direccion::where(
                     [ 
                         ['ID',$params_array['ID']]
                     ])->get(); 


if ($yaexiste->isEmpty()) {
    // INSERTAR
   $insertar=new Direccion();
    $insertar->ID= strtoupper($params_array['ID']);
    $insertar->CODIGO= strtoupper($params_array['CODIGO']);
    if ($insertar->save()) {
    $data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'Registro creado correctamente'
        );
} else {
    $data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'Error al crear registro'
        );
}
} else {
    // ACTUALIZAR
$actualizar = Direccion::where('ID', $params_array['ID']);
$updated = $actualizar->update(['CODIGO' => $params_array['CODIGO']]);

if ($updated > 0) {
$data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'Registro actualizado correctamente'
        );
} else {
    // No se actualizó ningún registro
    $data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'Error al actualizar registro'
        );
}
}

    }
        }else
        {
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }

        return response()->json($data,$data['code']);
    }

}