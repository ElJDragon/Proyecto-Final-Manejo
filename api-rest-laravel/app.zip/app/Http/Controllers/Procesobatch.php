<?php

namespace App\Http\Controllers;
use App\Http\Controllers\CorreoController;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Http\Response;
use App\Models\Gestionauditoria;
use App\Models\Gestionestrategias;
use App\Models\Gestionhallazgo;
use App\Models\Gestionrecomendaciones;
use App\Models\Gestionasignacion;
use App\Models\Responsables;
use App\Models\Departamentos;
use App\Models\Periodos;
use App\Models\Tiposcontrol;
use App\Models\Estatus;
use App\Models\Secuenciales;
use App\Models\Procesobatchf;
use App\Models\Parametros;
use App\Models\Comentarios;
use App\Helpers\JwtAuth;
use DateTime;

class Procesobatch extends Controller
{



//SACAR EL TOTAL POR TIPO D E CONTROL
    public function getUltimaFecha(){
     $integer=0;

$ultimafecha = Procesobatchf::max('F_BATCH');
$integer++;
         $agrupados[0] = array(     
             'FECHA'=>$ultimafecha
        );

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'parametros'=>$agrupados);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }


//////////////////////////////////////////////////
//SACAR EL TOTAL POR TIPO D E CONTROL
    public function getProcesados(){
     $integer=0;

     $ultimafecha = Procesobatchf::max('F_BATCH');

      $procesadoss = Procesobatchf::where('F_BATCH',$ultimafecha)->get();  

 foreach($procesadoss as $procesados)
                {

$estadoorigensss=Estatus::where('CESTATUSESTRATEGIA',$procesados->ESTADO_ORIGEN)->get();
$estadoorigens='';
 foreach($estadoorigensss as $estadoorigenss)
                {
                    $estadoorigens=$estadoorigenss->NOMBRE;
                }

$estadodestinosss=Estatus::where('CESTATUSESTRATEGIA',$procesados->ESTADO_DESTINO)->get();
$estadodestinos='';
 foreach($estadodestinosss as $estadodestinoss)
                {
                    $estadodestinos=$estadodestinoss->NOMBRE;
                }

         $agrupados[$integer] = array(     
             'CODIGO'=>trim($procesados->CODIGO),
'ID_ANTERIOR'=>trim($procesados->ID_GESTIONORIGEN),
'ID_GESTIONRENOVADA'=>trim($procesados->ID_GESTIONRENOVADA),
'ENVIOEMAIL'=>trim($procesados->ENVIOEMAIL),
'ENVIOSMS'=>trim($procesados->ENVIOSMS),
'ESTADO_ORIGEN'=>trim($estadoorigens),
'ESTADO_DESTINO'=>trim($estadodestinos)

        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'parametros'=>$agrupados);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }


//SACAR TODOS LAS RECOMENDACIONES SIN LAS CUMPLIDAS
    public function ProcesosBatch($fecha){

        $dia = date("d");
        $mes = date("m");
        $integer =0; 
        $contador =0; 
        $renovada =0; 
        $yaesta =0; 
        $estado='';
        $estatus='005';
       $productos=['CON01','CUM01'];


   $yaseprocesaron = Procesobatchf::where('F_BATCH',$fecha)->get();  

 foreach($yaseprocesaron as $yaseprocesaro)
                {
                    $yaesta++;
                }
//YA ESTA PROCESADO EL BATCH PARA ESTE DIA
if ($yaesta>0) {

    $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'YAESTA');
}
else
{


//TRAER TODAS MENOS RECOMENDACIONES
$norecomendaciones = GestionAuditoria::whereIn('ID_CONTROL',$productos)->get();
 foreach($norecomendaciones as $norecomendacione)
                {
            $sinrecomendaciones[$contador] = array(     
            'CODIGO'=>trim($norecomendacione->ID_GESTION));
            $contador++;
                }


//DETERMINAR EL MES EN EL QUE ESTAMOS
$mesletras='';
if($mes==1 || $mes==01)
{$mesletras='ENERO';}
if($mes==2 || $mes==02)
{$mesletras='FEBRERO';}
if($mes==3 || $mes==03)
{$mesletras='MARZO';}
if($mes==4 || $mes==04)
{$mesletras='ABRIL';}
if($mes==5 || $mes==05)
{$mesletras='MAYO';}
if($mes==6 || $mes==06)
{$mesletras='JUNIO';}
if($mes==7 || $mes==07)
{$mesletras='JULIO';}
if($mes==8 || $mes=='08')
{$mesletras='JULIO';}
if($mes==9 || $mes=='09')
{$mesletras='JULIO';}
if($mes==10)
{$mesletras='OCTUBRE';}
if($mes==11)
{$mesletras='NOVIEMBRE';}
if($mes==12)
{$mesletras='DICIEMBRE';}



///////////////////////////////
//TAER TODAS LAS ASIGNACIONES DE CN Y CI QUE EL CAMPO RENOVADO TENGAN EN 0
$asignaciones = Gestionasignacion::where('RENOVADA','0')->whereIn('ID_GESTION',$sinrecomendaciones)->get();
 foreach($asignaciones as $asignacione)
                {

//TRAER EL IPO DE CONTROL
   $tiposcontrolll = GestionAuditoria::where('ID_GESTION',$asignacione->ID_GESTION)->get();
    foreach($tiposcontrolll as $tiposcontroll)
                {
                    $tipocontrolactual=$tiposcontroll->ID_CONTROL;
                }
//TRAER EL IPO DE CONTROL


//POR CADA RESULTADO DE LA TABLA ASIGNACIÓN VOY COMPARANDO SI EN LA TABLA PERIODOS 
//TIENE MARCADA COMO MES A RENOVAR
$periodoss = Periodos::where([['ID_PERIODO',$asignacione->ID_PERIODO]
                     ])->distinct()->pluck($mesletras);




 foreach($periodoss as $periodos)
 {

if($periodos=='1')
{


//COMPARAR SI ESTAMOS EN EL DÍA ($día es el día QUE estamos)
    if($asignacione->DIA >= $dia)
    {



/////////////////////////////////////////////////////////////
////////ESTAMOS EN EL MES Y EL DÍA DE RENOVACION/////////////
/////////////////////////////////////////////////////////////

//PASO 1 INSERTAR EN LA TGESTIONAUDITORÍA
        //VERIFICAR QUE SIEMPRE DUPLIQUE EL CONTROL DE LA ULTIMA DE LA RAMA
        //CONSULTAR DE LA TSECUENCIASAUDITORIA

         /////////////////
        ////TRAER SECUENCIA Y ACTUALIZAR
        ////////////////
         $numsecuencia=0;
         $codsecuencia='';   



         $secuenciales = Secuenciales::where('CODIGO',$tipocontrolactual)->max('SECUENCIA');
        $numsecuencia=$secuenciales+1;

      $codsecuencia=trim($tipocontrolactual).$numsecuencia;    




      ////ACTUALIZAR LA SECUENCIA
      $usuario = Secuenciales::find($tipocontrolactual);
      $usuario->update(['SECUENCIA' => $numsecuencia]);    
        /////////////////
        ////TRAER SECUENCIA Y ACTUALIZAR
        ////////////////

$responsable='';
$insertarasignaciones = Gestionauditoria::where('ID_GESTION',$asignacione->ID_GESTION)->get();




 foreach($insertarasignaciones as $insertarasignacione)
 {

    $Gauditoria=new Gestionauditoria();
    $Gauditoria->ID_GESTION= $codsecuencia;
    $Gauditoria->ID_CONTROL= $insertarasignacione->ID_CONTROL;
    $Gauditoria->IDENTIFICACION= $insertarasignacione->IDENTIFICACION;
    $Gauditoria->RAZONSOCIAL= $insertarasignacione->RAZONSOCIAL;
    $Gauditoria->INFORME= $insertarasignacione->INFORME;
    $Gauditoria->FEMISION= $insertarasignacione->FEMISION;
    $Gauditoria->FENVIOINFORME= $insertarasignacione->FENVIOINFORME;
    $Gauditoria->FLIMITE= $insertarasignacione->FLIMITE;
    $Gauditoria->save();
}

$insertarestrategias = Gestionestrategias::where('ID_GESTION',$asignacione->ID_GESTION)->get();
 foreach($insertarestrategias as $insertarestrategia)
 {
    $Gestrategia=new Gestionestrategias();
    $Gestrategia->ID_GESTION= $codsecuencia;
    $Gestrategia->NUMERO_ESTRATEGIA= $insertarestrategia->NUMERO_ESTRATEGIA;
    $Gestrategia->ESTRATEGIA= $insertarestrategia->ESTRATEGIA;
    $Gestrategia->FINICIO= $insertarestrategia->FINICIO;
    //MODFICAR LA FFIN

 $mes = date("m");
 $fechaCarbon = new Carbon($insertarestrategia->FFIN);
if($mes=='12')
{
$mes='01';
$anio = $fechaCarbon->year+1;
$dia = $fechaCarbon->day;
}
else
{
    $mes=$mes+1;
    if($mes<10)
        {$mes='0'.$mes;}
$anio = $fechaCarbon->year;
$dia = $fechaCarbon->day;
}

$nuevafecha=$anio.'-'.$mes.'-'.$dia;

if($nuevafecha=='' || $nuevafecha == null)
    {    $Gestrategia->FFIN= $insertarestrategia->FFIN;}
else {    $Gestrategia->FFIN= $nuevafecha;}
    $Gestrategia->PORCENTAJE= '0';
    $Gestrategia->CESTATUSESTRATEGIA= '001';
    $Gestrategia->save();
}

$insertarhallazgos = Gestionhallazgo::where('ID_GESTION',$asignacione->ID_GESTION)->get();
 foreach($insertarhallazgos as $insertarhallazgo)
 {
    $Ghallazgo=new Gestionhallazgo();
    $Ghallazgo->ID_GESTION= $codsecuencia;
    $Ghallazgo->NUMERO_HALLAZGO= $insertarhallazgo->NUMERO_HALLAZGO;
    $Ghallazgo->HALLAZGO= $insertarhallazgo->HALLAZGO;
    $Ghallazgo->save();
}

$insertarrecomendaciones = Gestionrecomendaciones::where('ID_GESTION',$asignacione->ID_GESTION)->get();
 foreach($insertarrecomendaciones as $insertarrecomendacione)
 {
    $Grecomendaciones=new Gestionrecomendaciones();
    $Grecomendaciones->ID_GESTION= $codsecuencia;
    $Grecomendaciones->NUMERO_RECOMENDACION= $insertarrecomendacione->NUMERO_RECOMENDACION;
    $Grecomendaciones->RECOMENDACION= $insertarrecomendacione->RECOMENDACION;
    $Grecomendaciones->save();
}
$fechaActual = date("d-m-Y");
$insertarasignaciones = Gestionasignacion::where('ID_GESTION',$asignacione->ID_GESTION)->get();
 foreach($insertarasignaciones as $insertarasignacione)
 {
    $Gasignaciones=new Gestionasignacion();
    $Gasignaciones->ID_GESTION= $codsecuencia;
    $Gasignaciones->NUMERO_ASIGNACION= $insertarasignacione->NUMERO_ASIGNACION;
    $Gasignaciones->ID_PERIODO= $insertarasignacione->ID_PERIODO;
    $Gasignaciones->DIA= $insertarasignacione->DIA;
    $Gasignaciones->FASIGNACION= $insertarasignacione->FASIGNACION;
    $Gasignaciones->CUSUARIO_AUDITORIA= $insertarasignacione->CUSUARIO_AUDITORIA;
    $Gasignaciones->CUSUARIO_ASIGNACION= $insertarasignacione->CUSUARIO_ASIGNACION;
    $Gasignaciones->CUSUARIO_CORESPONSABLE= $insertarasignacione->CUSUARIO_CORESPONSABLE;
    $Gasignaciones->ARCHIVO_ASIGNACION= $insertarasignacione->ARCHIVO_ASIGNACION;
    $Gasignaciones->DETALLE_ASIGNACION= $insertarasignacione->DETALLE_ASIGNACION;
    $Gasignaciones->CUSUARIO_CORESPONSABLE2= $insertarasignacione->CUSUARIO_CORESPONSABLE2;
    $Gasignaciones->CUSUARIO_CORESPONSABLE3= $insertarasignacione->CUSUARIO_CORESPONSABLE3;
    $Gasignaciones->FCONTABLE= $fechaActual;
    $Gasignaciones->RENOVADA= '0';
    $Gasignaciones->ID_ANTERIOR= $asignacione->ID_GESTION;
    $Gasignaciones->save();

$responsable=$insertarasignacione->CUSUARIO_ASIGNACION;
}

$update_renovacion =  Gestionasignacion::where('ID_GESTION',$asignacione->ID_GESTION)->update(['RENOVADA'=>'1']);

$estadooriginal='';
$verificarestatus = Gestionestrategias::where('ID_GESTION',$asignacione->ID_GESTION)->get();
 foreach($verificarestatus as $verificarestatu)
 {
$estadooriginal=$verificarestatu->CESTATUSESTRATEGIA;
    if($verificarestatu->CESTATUSESTRATEGIA!='005')
$update_estatus =  Gestionestrategias::where('ID_GESTION',$asignacione->ID_GESTION)->update(['CESTATUSESTRATEGIA'=>'003']);
 }


//INSERTAR EN LA TABLA DE AUDITORIA
     $Gbatch=new Procesobatchf();
     $Gbatch->ID_GESTIONORIGEN= $asignacione->ID_GESTION;
    $Gbatch->ID_GESTIONRENOVADA= $codsecuencia;
    $Gbatch->F_BATCH= $fechaActual;
    $Gbatch->ESTADO_ORIGEN= $estadooriginal;
    if($estadooriginal=='005')
    {
    $Gbatch->ESTADO_DESTINO=$estadooriginal;
}else
{
    $Gbatch->ESTADO_DESTINO='003';
}
    $Gbatch->save();

/////////////////////////////////////////////////////////////
////////ESTAMOS EN EL MES Y EL DÍA DE RENOVACION/////////////
/////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////
////////MANDAR MENSAJE A LA PERSONA/////////////
/////////////////////////////////////////////////////////////
$traerinfos= Responsables::where('ID',$responsable)->get();
 foreach($traerinfos as $traerinfo)
 {

      $json = [
            'DESTINO' => $traerinfo->EMAIL,
            'ASUNTO' => 'ACTUALIZACION DE PROCESOS AUDITORIA',
            'TIPO' => 'MAIL02',
            'CAMPO' => 'ASIGNACION'
        ];
    $response = Http::post(route('enviar-correo'), ['json' => json_encode($json)]);

        // Obtener la respuesta
        $resultado = $response->json();
}

/////////////////////////////////////////////////////////////
////////MANDAR MENSAJE A LA PERSONA/////////////
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
////////MANDAR WHATSAPP/////////////
/////////////////////////////////////////////////////////////
$traerinfos= Responsables::where('ID',$responsable)->get();
 foreach($traerinfos as $traerinfo)
 {

      $json = [
            'DESTINO' => $traerinfo->TELEFONO,
            'ASUNTO' => 'ACTUALIZACION DE PROCESOS AUDITORIA',
            'TIPO' => 'MAIL02',
            'CAMPO' => 'ASIGNACION'
        ];
    $response = Http::post(route('enviar-whatsapp'), ['json' => json_encode($json)]);

        // Obtener la respuesta
        $resultado = $response->json();
}

/////////////////////////////////////////////////////////////
////////MANDAR WHATSAPP/////////////
/////////////////////////////////////////////////////////////



$integer++;



    }
}
 }
}




//////////////////////////////////////////
///////////CAMBIAR ESTADO A LAS VENCIDAS/////
//////////////////////////////////////////
//TRAER TODAS MENOS RECOMENDACIONES
       $estadoss=['001','002'];
       $con=0;
       $fechaActual2 = date("d-m-Y");

$asignacioness22 = Gestionestrategias::whereIn('CESTATUSESTRATEGIA',$estadoss)->where('FFIN','<',$fechaActual2)->get();

 foreach($asignacioness22 as $asignacioness2)
                {
                    $estadooriginal2=$asignacioness2->CESTATUSESTRATEGIA;
$porcentaje_update =  Gestionestrategias::where('ID_GESTION',$asignacioness2->ID_GESTION)->update(['CESTATUSESTRATEGIA'=>'003']);

//INSERTAR EN LA TABLA DE AUDITORIA
     $Gbatch=new Procesobatchf();
     $Gbatch->ID_GESTIONORIGEN= $asignacioness2->ID_GESTION;
    $Gbatch->ID_GESTIONRENOVADA= '';
    $Gbatch->F_BATCH= $fechaActual2;
    $Gbatch->ESTADO_ORIGEN= $estadooriginal2;
    $Gbatch->ESTADO_DESTINO='003';
    $Gbatch->save();


                }

//////////////////////////////////////////
///////////CAMBIAR ESTADO A LAS VENCIDAS//////
//////////////////////////////////////////



//////////////////////////////////////////
///////////MANDAR NOTIFICACIONES AUTOMATICAS/////
//////////////////////////////////////////


//DETERMINAR A QUIEN ENVIAR LA NOTIFICACION

//1.- TRAER LOS DÍAS DE NOTIFICACION

$cuantosdiass= Parametros::select('AVISO')->get();
 foreach($cuantosdiass as $cuantosdias)
 {

     $diasparametro=$cuantosdias->AVISO;
 }
///////////////////////////

 //2.- TRAER TODAS LOS PROCESOS CON FECHA FIN MAYOR A LA FECHA ACTUAL
 $fechaActual1 = date("d-m-Y");
$fechaActual = new DateTime("now");
$fechaActual->modify('+'.$diasparametro.' days');
$fechaActual3 = $fechaActual->format('d-m-Y');
$statusss=['002','003'];



$fechass = Gestionestrategias::whereBetween('FFIN', [$fechaActual1, $fechaActual3])->whereIn('CESTATUSESTRATEGIA',$statusss)->get();

 foreach($fechass as $fechas)
 {
    $tipop='';
//VER QUE TIPO DE PROCESO ES
if($fechas->ID_CONTROL=='REC01')
{
$tipop='MAIL01';
}else{$tipop='MAIL02';}

$asignacionesenviar= Gestionasignacion::where('ID_GESTION',$fechas->ID_GESTION)->get();
 foreach($asignacionesenviar as $asignacionesenvia)
 {
//ENVIAR NOTIFICACIONES
    $traerinfos= Responsables::where('ID',$asignacionesenvia->CUSUARIO_ASIGNACION)->get();
 foreach($traerinfos as $traerinfo)
 {

      $json = [
            'DESTINO' => $traerinfo->EMAIL,
            'ASUNTO' => 'NOTIFICACION AUTOMATICAS AUDITORIA',
            'TIPO' => $tipop,
            'CAMPO' => 'ASIGNACION'
        ];
    $response = Http::post(route('enviar-correo'), ['json' => json_encode($json)]);

        // Obtener la respuesta
        $resultado = $response->json();



///////////////////////////////////////////////////////
////WHATSAPP

      $json2 = [
            'DESTINO' => $traerinfo->TELEFONO,
            'ASUNTO' => 'NOTIFICACION AUTOMATICAS AUDITORIA',
            'TIPO' => $tipop,
            'CAMPO' => 'ASIGNACION'
        ];
    $response = Http::post(route('enviar-whatsapp'), ['json' => json_encode($json2)]);

        // Obtener la respuesta
        $resultado = $response->json();


        //INSERTAR EN LA TABLA DE AUDITORIA
     $Gbatch=new Procesobatchf();
     $Gbatch->ID_GESTIONORIGEN= $asignacionesenvia->ID_GESTION;
    $Gbatch->ID_GESTIONRENOVADA= '';
    $Gbatch->F_BATCH= $fechaActual1;
    $Gbatch->ENVIOEMAIL= 'SI';
    $Gbatch->ENVIOSMS='SI';
    $Gbatch->save();


}

 }
 }



$integer++;

                //////////////////////////////////////////
///////////MANDAR NOTIFICACIONES AUTOMATICAS/////
//////////////////////////////////////////



if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200,
          'message'=>'Batch Ejecutado Correctamente');
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


}



         return response()->json($data,$data['code']);

                            }




/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////CMBIAR DE ESTADO A CANCELADO
  public function updateCancelado($id,$tipo,$motivo){

if($tipo=='APROBAR')
{
             $estado_update =  Gestionestrategias::where('ID_GESTION',$id)->update(['CESTATUSESTRATEGIA'=>'005']);
}
else
{
               $estado_update =  Gestionestrategias::where('ID_GESTION',$id)->update(['CESTATUSESTRATEGIA'=>'006']);  
               $estado_update =  Gestionasignacion::where('ID_GESTION',$id)->update(['DETALLE_ENTREGA'=>$motivo]);
}
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200);

         return response()->json($data,$data['code']);
     }
    

}
