<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Gestionauditoria;
use App\Models\Gestionestrategias;
use App\Models\Gestionhallazgo;
use App\Models\Gestionrecomendaciones;
use App\Models\Gestionasignacion;
use App\Models\Responsables;
use App\Models\Departamentos;
use App\Models\Periodos;
use App\Models\Tiposcontrol;
use App\Models\Estatus;
use App\Models\Parametros;
use App\Models\Comentarios;
use App\Helpers\JwtAuth;

class Actualizaciones extends Controller
{


            public function updateResponsable($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
         if(!empty($params_array))
         {
 
  
             unset($params_array['USUARIO']);
             //actualizar el usuario en la bbd
             $limite_update =  Responsables::where('ID',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El limite no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }
  


            public function updateDepartamento($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
         if(!empty($params_array))
         {
             //actualizar el usuario en la bbd
             $limite_update =  Departamentos::where('COD_DEPARTAMENTO',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El departamento no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }
  

          public function updateControl($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
         if(!empty($params_array))
         {
             //actualizar el usuario en la bbd
             $limite_update =  Tiposcontrol::where('ID_CONTROL',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El departamento no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }


        public function updatePeriodo($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
         if(!empty($params_array))
         {
             //actualizar el usuario en la bbd
             $limite_update =  Periodos::where('ID_PERIODO',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El departamento no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }


//CON ESTE METODO SOLO VAMOS A GRABAR EL COMENTARIO EN LA TABLA TESTRATEGIAASIGNACION
public function updateAsignacion($id,$porcentaje,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////GUARDAR SOLO EL COMENTARIO//////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
         if(!empty($params_array))
         {

                     //QUITAR LO QUE NO QUIERO ACTUALIZAR 
         unset($params_array['ID_GESTION']);
         unset($params_array['NUMERO_ASIGNACION']);
         unset($params_array['ID_PERIODO']);         
         unset($params_array['DIA']);
         unset($params_array['FASIGNACION']);
         unset($params_array['CUSUARIO_AUDITORIA']);
         unset($params_array['CUSUARIO_ASIGNACION']);
         unset($params_array['CUSUARIO_CORESPONSABLE']);
         unset($params_array['ARCHIVO_ASIGNACION']);
         unset($params_array['ARCHIVO_ENTREGA']);
         unset($params_array['DETALLE_ASIGNACION']);
         unset($params_array['CUSUARIO_CORESPONSABLE2']);
         unset($params_array['CUSUARIO_CORESPONSABLE3']);  
         unset($params_array['FCONTABLE']);
         unset($params_array['RENOVADA']);
         unset($params_array['ID_ANTERIOR']);
             //actualizar el usuario en la bbd
             $limite_update =  Gestionasignacion::where('ID_GESTION',$id)->update($params_array);
             
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////FIN SOLO EL COMENTARIO//////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
             
             //actualizar el usuario en la bbd

             $porcentaje_update =  Gestionestrategias::where('ID_GESTION',$id)->update(['PORCENTAJE'=>$porcentaje]);


             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'La asignacion no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }


///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//sacar toos los Responsables de la bdd
    public function getcomentarios($id){
        $integer =0;

$comentarios = Comentarios::where('ID_GESTION',$id)->max('NUMERO_COMENTARIO');

if($comentarios==null)
{
    $comentarios=0;
}
    $comentarios++;

$data = array(
          'status'=>'succes',
          'code'=>200, 
          'cuantos'=>$comentarios);

         return response()->json($data,$data['code']);

                            }




///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//sacar toos los Responsables de la bdd
    public function comentarios($id){
        $contador =0;
        $nombreauditor='';
        $apellidoauditor='';
        $nombreresponsable='';
        $apellidoresponsable='';
        $tipocontrol='';
        $estatus='';

$asignaciones = Gestionasignacion::where('ID_GESTION',$id)->get();
 foreach($asignaciones as $asignacione)
{

$auditores = Responsables::where('ID',$asignacione->CUSUARIO_AUDITORIA)->get();
$responsables = Responsables::where('ID',$asignacione->CUSUARIO_ASIGNACION)->get();
$tipocontroles = Gestionauditoria::where('ID_GESTION',$id)->get();
$estrategias = Gestionestrategias::where('ID_GESTION',$id)->get();
 foreach($tipocontroles as $tipocontrole)
{
    $tipocontrol=trim($tipocontrole->ID_CONTROL);    
}
 foreach($estrategias as $estrategia)
{
    $estatus=trim($estrategia->CESTATUSESTRATEGIA);    
}
 foreach($auditores as $auditore)
{
    $nombreauditor=trim($auditore->NOMBRES);
    $apellidoauditor=trim($auditore->APELLIDOS);
}
 
 foreach($responsables as $responsable)
{
    $nombreresponsable=trim($responsable->NOMBRES);
        $apellidoresponsable=trim($responsable->APELLIDOS);
}               
              $codigosgestion[$contador] = array(     
             'ID_GESTION'=>trim($asignacione->ID_GESTION),
             'FECHA'=>trim($asignacione->FCONTABLE),
             'OBSERVACION'=>trim($asignacione->DETALLE_ASIGNACION),
             'PORCENTAJE'=>'0',
             'ADJUNTO'=>trim($asignacione->ARCHIVO_ASIGNACION),
             'NOMBRE'=>($apellidoauditor." ".$nombreauditor),
             'CONTROL'=>trim($tipocontrol),
              'ESTATUS'=>trim($estatus)
        );
         $contador++;    
                }



$comentarios = Comentarios::where('ID_GESTION',$id)->get();

 foreach($comentarios as $comentario)
 {
              $codigosgestion[$contador] = array(     
             'ID_GESTION'=>trim($comentario->ID_GESTION),
             'FECHA'=>trim($comentario->FECHA),
             'OBSERVACION'=>trim($comentario->OBSERVACION),
             'PORCENTAJE'=>trim($comentario->PORCENTAJE),
             'ADJUNTO'=>trim($comentario->ARCHIVO_ENTREGA),
             'NOMBRE'=>($apellidoresponsable." ".$nombreresponsable),
             'CONTROL'=>trim($tipocontrol),
              'ESTATUS'=>trim($estatus)
        );
         $contador++;    
                }


$data = array(
          'status'=>'succes',
          'code'=>200, 
          'comentario'=>$codigosgestion);

         return response()->json($data,$data['code']);

                            }



///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS COMENTARIOS
    public function nuevoComentario(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        
     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'ID_GESTION'=>'required',//Comprobar si el usuario existe con unique
        'NUMERO_COMENTARIO'=>'required'

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El Comentario no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
             
        //Crear el Responsable
    $comentario=new Comentarios();
    $comentario->ID_GESTION= $params_array['ID_GESTION'];
    $comentario->NUMERO_COMENTARIO= $params_array['NUMERO_COMENTARIO'];
    $comentario->ARCHIVO_ENTREGA= $params_array['ARCHIVO_ENTREGA'];
    $comentario->OBSERVACION= strtoupper($params_array['OBSERVACION']);
    $comentario->PORCENTAJE= $params_array['PORCENTAJE'];
    $comentario->FECHA= $params_array['FECHA'];
    
//Guardar el Usuario
  $comentario->save();
    
  //enviar la respuesta
          $data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'El Comentario se ha creado correctamente'
        );
    }
        }else
        {
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }

        return response()->json($data,$data['code']);
    }



///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////


//SACAR EL TOTAL POR TIPO D E CONTROL
    public function getTotalporControl(){
        $integer =0; 
        $contador =0; 
        $estado='';
      $responsable='';

$gestiones = Gestionauditoria::select('ID_CONTROL', DB::raw('count(*) as total'))
    ->groupBy('ID_CONTROL')
    ->get();

 foreach($gestiones as $gestion)
                {

$nombre='';
     $nombres = Tiposcontrol::where(
                     [
                         ['ID_CONTROL',$gestion->ID_CONTROL]
                     ])->get();
 foreach($nombres as $nombre)
                {
                    $nombre=trim($nombre->NOMBRE);
                }


         $agrupados[$integer] = array(     
             'ID_CONTROL'=>trim($gestion->ID_CONTROL),
             'NOMBRE'=>trim($nombre),
              'TOTAL'=>($gestion->total)
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$agrupados);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }



///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////


//SACAR EL TOTAL POR TIPO D E CONTROL
    public function getTotalporFechas($f1,$f2,$qfecha){
        $integer =0; 
        $contador =0;
        $contador2 =0;  
        $estado='';
        $quefecha='';
      $responsable='';

      if($qfecha=='1')
      {
$quefecha='FINICIO';
      }
      else
      {
$quefecha='FFIN';
      }
//APLICAR BETWEEN HASTA AQUIE DEJAMOS
     $fechas = Gestionestrategias::whereBetween($quefecha, [$f1, $f2])->get();

 foreach($fechas as $fecha)
                {
              $entrefechas[$contador2] = array(     
             'ID_GESTION'=>trim($fecha->ID_GESTION)
        );
         $contador2++;    
                }




//HASTA AQUI QUEDAMOS YA TENEOS LAS DOS FECHAS AQUI..

$gestiones = Gestionauditoria::select('ID_CONTROL', DB::raw('count(*) as total'))->whereIn('ID_GESTION',$entrefechas) 
    ->groupBy('ID_CONTROL')
    ->get();

 foreach($gestiones as $gestion)
                {

$nombre='';
     $nombres = Tiposcontrol::where(
                     [
                         ['ID_CONTROL',$gestion->ID_CONTROL]
                     ])->get();
 foreach($nombres as $nombre)
                {
                    $nombre=trim($nombre->NOMBRE);
                }


         $agrupados[$integer] = array(     
             'ID_CONTROL'=>trim($gestion->ID_CONTROL),
             'NOMBRE'=>trim($nombre),
              'TOTAL'=>($gestion->total)
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$agrupados);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }

///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////


//SACAR EL TOTAL POR TIPO D E CONTROL
    public function getTotalporEstatus($id){
        $integer =0; 
        $contador =0; 

      $responsable='';


     $gestiones = Gestionauditoria::where(
                     [
                         ['ID_CONTROL',$id]
                     ])->get();



 foreach($gestiones as $gestion)
                {


$estado='';
$estrategia='';
$finicio='';
$fin='';
     $estrategias = Gestionestrategias::where(
                     [
                         ['ID_GESTION',$gestion->ID_GESTION]
                     ])->get();

 foreach($estrategias as $estrategi)
                {
                    $estado=trim($estrategi->CESTATUSESTRATEGIA);
                    $estrategia=trim($estrategi->ESTRATEGIA);
                    $finicio=$estrategi->FINICIO;
                    $fin=$estrategi->FFIN;
                }


$nombreestado='';
     $estatus = Estatus::where(
                     [
                         ['CESTATUSESTRATEGIA',$estado]
                     ])->get();
 foreach($estatus as $estatu)
                {
                    $nombreestado=trim($estatu->NOMBRE);
                }


         $agrupados[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
             'ESTRATEGIA'=>trim($estrategia),
             'CODIGO'=>trim($estado),
             'NOMBRE'=>trim($nombreestado),
              'FINICIO'=>($finicio),
              'FFIN'=>($fin)
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$agrupados);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }

///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////


//SACAR EL TOTAL POR TIPO D E CONTROL
    public function getTotalporEstFecha($id,$f1,$f2,$qes){
        $integer =0; 
        $contador =0; 
        $contador2 =0; 
      $responsable='';
        $quefecha='';


      if($qes=='1')
      {
$quefecha='FINICIO';
      }
      else
      {
$quefecha='FFIN';
      }
//APLICAR BETWEEN HASTA AQUIE DEJAMOS
     $fechas = Gestionestrategias::whereBetween($quefecha, [$f1, $f2])->get();

 foreach($fechas as $fecha)
                {
              $entrefechas[$contador2] = array(     
             'ID_GESTION'=>trim($fecha->ID_GESTION)
        );
         $contador2++;    
                }


     $gestiones = Gestionauditoria::where(
                     [
                         ['ID_CONTROL',$id]
                     ])->whereIn('ID_GESTION',$entrefechas) ->get();



 foreach($gestiones as $gestion)
                {


$estado='';
$estrategia='';
$finicio='';
$fin='';
     $estrategias = Gestionestrategias::where(
                     [
                         ['ID_GESTION',$gestion->ID_GESTION]
                     ])->get();

 foreach($estrategias as $estrategi)
                {
                    $estado=trim($estrategi->CESTATUSESTRATEGIA);
                    $estrategia=trim($estrategi->ESTRATEGIA);
                    $finicio=$estrategi->FINICIO;
                    $fin=$estrategi->FFIN;
                    
                }


$nombreestado='';
     $estatus = Estatus::where(
                     [
                         ['CESTATUSESTRATEGIA',$estado]
                     ])->get();
 foreach($estatus as $estatu)
                {
                    $nombreestado=trim($estatu->NOMBRE);
                }


         $agrupados[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
             'ESTRATEGIA'=>trim($estrategia),
             'CODIGO'=>trim($estado),
             'NOMBRE'=>trim($nombreestado),
              'FINICIO'=>($finicio),
              'FFIN'=>($fin)
              
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$agrupados);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }

}
