<?php

namespace App\Http\Controllers;
use Illuminate\Support\Str;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Models\Emails;
use App\Models\User;
use App\Models\Responsables;
class CorreoController extends Controller
{

    public function enviarCorreo(Request $request)
    {

$json = $request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
         $params_array = array_map('trim', $params_array);
        

        $mensajeenviar='';
        $destinatario = $params_array['DESTINO'];
        $asunto = $params_array['ASUNTO'];
        $tipo = $params_array['TIPO'];
        $campo = $params_array['CAMPO'];

        try {

////VERIFICAR SI EL MENSAJE ES PARA LOS AUDITORES
if($destinatario=='AUDITORIA')
{


//TRAER TODOS LOS USUARIOS
$destinatariossdos = User::where('role', 'AUDITOR')->get();
 foreach($destinatariossdos as $destinatariossdo)
                {
//TRAER TODAS LAS PERSONAS
$personass2 = Responsables::where('EMAIL', $destinatariossdo->Email)->get();
foreach($personass2 as $personas2)
                {
//ENVIAR LOS CORREOS A LOS AUDITORES

$mensajes = Emails::select($campo)->where('CODIGO', $tipo)->get();
 foreach($mensajes as $mensaje)
{
$mensajeenviar=trim($mensaje->$campo);
}
$emailsssss=$personas2->EMAIL;
Mail::raw($mensajeenviar, function ($message) use ($emailsssss, $asunto) {
                $message->to($emailsssss)->subject($asunto);

            });
return response()->json(['mensaje' => 'Correo enviado con éxito']);
//ENVIAR LOS CORREOS A LOS AUDITORES    

                }
                }
////VERIFICAR SI EL MENSAJE ES PARA LOS AUDITORES
}else
{
//////////////////////////////////////////////////

//////////////////////////TRAER EL TIPO DE CORREO

  //   $mensajes = Emails::where('CODIGO', $tipo)->select($campo)->get();

$mensajes = Emails::select($campo)->where('CODIGO', $tipo)->get();
 foreach($mensajes as $mensaje)
{   
$mensajeenviar=trim($mensaje->$campo);
}

//////////////////////////////////

            Mail::raw($mensajeenviar, function ($message) use ($destinatario, $asunto) {
                $message->to($destinatario)->subject($asunto);
            });

            return response()->json(['mensaje' => 'Correo enviado con éxito']);
        
}

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }




    ///////////////////////////////////////////////
    /////////////////////////////////////////////////7
    ////////////////////////////RECUPERAR CONTRASEÑA/////////////


        public function enviarCorreoR(Request $request)
    {

$json = $request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
         $params_array = array_map('trim', $params_array);
        

        $mensajeenviar='';
        $existe='';
        $destinatario = $params_array['DESTINO'];
        $asunto = 'RECUPERACION DE CONTRASEÑA';


        try {

             $responsables = User::where(
                     [ 
                         ['Email',$destinatario]
                     ])->get();

 foreach($responsables as $responsable)
                {
$existe=$responsable->Email;
                }

if($existe=='' || $existe==null)
{
      return response()->json(['mensaje' => 'NOEXISTE']);
}
else
{

$password = Str::random(12);
$pwd= hash('sha256',$password);        
$mensajeenviar='SU CONTRASEÑA ES:'.$password;
//ACTUALIZAR CONTRASEÑA
        $update =  User::where('Email',$destinatario)->update(['Password'=>$pwd]);
//ACTUALIZAR CONTRASEÑA


            Mail::raw($mensajeenviar, function ($message) use ($existe, $asunto) {
                $message->to($existe)->subject($asunto);
            });

            return response()->json(['mensaje' => 'Correo enviado con éxito']);
        
}

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
