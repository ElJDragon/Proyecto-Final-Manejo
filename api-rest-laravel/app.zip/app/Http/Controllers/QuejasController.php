<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Personas;
use App\Models\ReclamosCanales;
use App\Models\ReclamosLocalidad;
use App\Models\ReclamosDetalle;
use App\Models\ReclamosConcepto;
use App\Models\ReclamosEstructura;
use App\Models\ReclamosResolucion;

use Illuminate\Support\Facades\DB;
use DateTime;
use App\Models\Gestionauditoria;
use App\Models\Gestionestrategias;
use App\Models\Gestionhallazgo;
use App\Models\Gestionrecomendaciones;
use App\Models\Gestionasignacion;
use App\Models\Responsables;
use App\Models\Departamentos;
use App\Models\Periodos;
use App\Models\Tiposcontrol;
use App\Models\Estatus;
use App\Models\Parametros;
use App\Models\Emails;
use App\Models\Alertas;
use App\Models\Comentarios;
use App\Models\Secuenciales;
use App\Helpers\JwtAuth;

class QuejasController extends Controller
{
    

    //OBETER PERSONA POR EL ID O CEDULA
    public function getPersonaP($socio,$tipo){
        $integer =0;
        $parametro=trim($socio);

        if (trim($tipo)=='1') {
$personas = Personas::where(
                     [ 
                         ['SOCIOS',$parametro]
                     ])->get(); 
        }else
        {
$personas = Personas::where(
                     [ 
                         ['IDENTIFICACION',$parametro]
                     ])->get(); 
        }
 foreach($personas as $persona)
                {
         $enviarpersona[$integer] = array(     
             'SOCIOS'=>trim($persona->SOCIOS),
              'IDENTIFICACION'=>trim($persona->IDENTIFICACION),
              'NOMBRE'=>trim($persona->NOMBRE)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'personas'=>$enviarpersona);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }


//////////////////////////////7
////////////////////////////////////

                               //OBETER RESOLUCION
    public function getResoluciones(){
        $integer =0;


$resoluciones = ReclamosResolucion::get(); 

 foreach($resoluciones as $resolucione)
                {
         $enviarresoluciones[$integer] = array(     
             'CODIGO'=>trim($resolucione->CODIGO),
              'DETALLE'=>trim($resolucione->DETALLE)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'resoluciones'=>$enviarresoluciones);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }



//////////////////////////////7
////////////////////////////////////

                               //OBETER canales
    public function getCanales(){
        $integer =0;


$canales = ReclamosCanales::orderBy('CODIGO')->get(); 

 foreach($canales as $canale)
                {
         $enviarcanales[$integer] = array(     
             'CODIGO'=>trim($canale->CODIGO),
              'NOMBRE'=>trim($canale->NOMBRE)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'canales'=>$enviarcanales);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }



//////////////////////////////7
////////////////////////////////////

                               //OBETER LOCALIDADES
    public function getLocalidades(){
        $integer =0;


$localidades = ReclamosLocalidad::get(); 

 foreach($localidades as $localidade)
                {
         $enviarlocalidades[$integer] = array(     
             'CODIGO'=>trim($localidade->CODIGO),
              'NOMBRE'=>trim($localidade->NOMBRE)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'localidades'=>$enviarlocalidades);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }

                            //////////////////////////////7
////////////////////////////////////

                               //OBETER CONCEPTOS
    public function getConcepto(){
        $integer =0;


$conceptos = ReclamosConcepto::get(); 

 foreach($conceptos as $concepto)
                {
         $enviarconceptos[$integer] = array(     
             'CODIGO'=>trim($concepto->CODIGO),
              'NOMBRE'=>trim($concepto->NOMBRE)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'conceptos'=>$enviarconceptos);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }

                            //////////////////////////////7
////////////////////////////////////

                               //OBETER DETALLE CONCEPTOS
    public function getDetalle($concepto){
        $integer =0;


$detalles = ReclamosDetalle::where(
                     [ 
                         ['CONCEPTO',trim($concepto)]
                     ])->get(); 

 foreach($detalles as $detalle)
                {
         $enviardetalle[$integer] = array(     
             'CODIGO'=>trim($detalle->CODIGO),
              'NOMBRE'=>trim($detalle->NOMBRE)
        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'detalle'=>$enviardetalle);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }


         return response()->json($data,$data['code']);

                            }


///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVA RECOMENDACION
    public function nuevoreclamo(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        
     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        //'ID_GESTION'=>'required',
        'ID_CONTROL'=>'required',

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'La asignacion no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {

        /////////////////
        ////TRAER SECUENCIA
        ////////////////

         $numsecuencia=0;
         $codsecuencia='';   
         $secuenciales = Secuenciales::where('CODIGO',$params_array['ID_CONTROL'])->max('SECUENCIA');
        $numsecuencia=$secuenciales+1;
      $codsecuencia=$params_array['ID_CONTROL'].$numsecuencia;    


      ////ACTUALIZAR LA SECUENCIA
      $usuario = Secuenciales::find($params_array['ID_CONTROL']);
      $usuario->update(['SECUENCIA' => $numsecuencia]);    


        /////////////////
        ////TRAER SECUENCIA
        ////////////////




            $asignacion=new Gestionauditoria();
           $asignacion->ID_GESTION= $codsecuencia;     
        //Crear el GESTIONAUDITORIA
    $asignacion->ID_CONTROL=strtoupper($params_array['ID_CONTROL']);
    $asignacion->INFORME=strtoupper($params_array['NOMBRE']);
    $asignacion->IDENTIFICACION= strtoupper($params_array['IDENTIFICACION']);
$asignacion->RAZONSOCIAL= strtoupper($params_array['RAZONSOCIAL']);
$asignacion->FEMISION= date("d/m/Y", strtotime($params_array['FEMISION']));
  $asignacion->save();


    
$recomendaciones=new Gestionrecomendaciones();
           $recomendaciones->ID_GESTION= $codsecuencia;     
$recomendaciones->NUMERO_RECOMENDACION= strtoupper($params_array['NUMERO_RECOMENDACION']);
$recomendaciones->RECOMENDACION= strtoupper($params_array['RECOMENDACION']);
  $recomendaciones->save();



$hallazgo=new Gestionhallazgo();
$hallazgo->ID_GESTION= $codsecuencia;     
$hallazgo->NUMERO_HALLAZGO= strtoupper($params_array['NUMERO_RECOMENDACION']);
$hallazgo->HALLAZGO= strtoupper($params_array['RECOMENDACION']);
  $hallazgo->save();


$estrategia=new Gestionestrategias();
           $estrategia->ID_GESTION= $codsecuencia;     
$estrategia->NUMERO_ESTRATEGIA= strtoupper($params_array['NUMERO_ESTRATEGIA']);
$estrategia->ESTRATEGIA= strtoupper($params_array['ESTRATEGIA']);
$estrategia->FINICIO= ($params_array['FINICIO']);
$estrategia->FFIN= date("d/m/Y", strtotime($params_array['FFIN']));
$estrategia->PORCENTAJE= ($params_array['PORCENTAJE']);
$estrategia->CESTATUSESTRATEGIA= ($params_array['CESTATUSESTRATEGIA']);
  $estrategia->save();



//LLENAMOS LA TABLA DE RECLAMOS
$reclamos=new ReclamosEstructura();
$reclamos->CODIGO= $codsecuencia;     
$reclamos->IDENTIFICACION= strtoupper($params_array['RUC']);
$reclamos->NOMBRE= strtoupper($params_array['NOMBRE']);
$reclamos->FECHA= date("d/m/Y", strtotime($params_array['FECHA']));
$reclamos->CCANAL= strtoupper($params_array['CCANAL']);
$reclamos->CLOCALIDAD= strtoupper($params_array['CLOCALIDAD']);
$reclamos->CCONCEPTO= strtoupper($params_array['CCONCEPTO']);
$reclamos->CESTATUS= strtoupper($params_array['CESTATUS']);
  $reclamos->save();




  //enviar la respuesta
          $data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'La asignación se ha creado correctamente'
        );
    }
        }else
        {
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }

        return response()->json($data,$data['code']);
    }


///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS RESPONSABLES
    public function nuevaasigReclamo(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        


     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'ID_GESTION'=>'required'//Comprobar si el usuario existe con unique

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'La asignacion no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
             


        //TRAER EL RESPONSALE DEL USUARIO
     $responsablesss = Responsables::where(
                     [
                         ['USUARIO',$params_array['CUSUARIO_AUDITORIA']]
                     ])->get();


 foreach($responsablesss as $responsabless)
                {
                    $nombreauditoria=$responsabless->ID;
                }




        //Crear el Responsable
    $asignacion=new Gestionasignacion();
    $asignacion->ID_GESTION= strtoupper($params_array['ID_GESTION']);
    $asignacion->NUMERO_ASIGNACION=strtoupper($params_array['NUMERO_ASIGNACION']);
    $asignacion->CUSUARIO_AUDITORIA= $nombreauditoria;
    $asignacion->CUSUARIO_ASIGNACION= $params_array['CUSUARIO_ASIGNACION'];
    $asignacion->ARCHIVO_ASIGNACION= $params_array['ARCHIVO_ASIGNACION'];
    $asignacion->DETALLE_ASIGNACION= $params_array['DETALLE_ASIGNACION'];
   $asignacion->FCONTABLE= $params_array['FCONTABLE'];
   $asignacion->RENOVADA= $params_array['RENOVADA'];

    
//Guardar el Usuario
  $asignacion->save();
    
//CAMBIAR EL ESTADO A EN PROCESO

  $porcentaje_update =  Gestionestrategias::where('ID_GESTION',$params_array['ID_GESTION'])->update(['CESTATUSESTRATEGIA'=>'002']);

  //enviar la respuesta
          $data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'La asignación se ha creado correctamente'
        );
    }
        }else
        {
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }

        return response()->json($data,$data['code']);
    }



///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////

//SACAR TODOS LOS OTROS PROCESOS SIN LAS CUMPLIDAS
    public function gestionreclamos(){
        $integer =0; 
        $contador =0; 
        $estado='';
      $responsable='';

       $estatus='QYR01';
$nocanceladas = Gestionestrategias::orderBy('ID_GESTION')->get();

 foreach($nocanceladas as $nocancelada)
                {
              $codigosgestion[$contador] = array(     
             'ID_GESTION'=>trim($nocancelada->ID_GESTION)
        );
         $contador++;    
                }

     $gestiones = Gestionauditoria::whereIn('ID_GESTION',$codigosgestion)->whereIn('ID_CONTROL',[$estatus])->get();


    
 foreach($gestiones as $gestion)
                {

$nombreresponsable='';
$apellidoresponsable='';
$codigointerno='';
$detallerecomendacion='';



//TRAER LA RECOEMNDACION
     $recomendacioness = Gestionrecomendaciones::where(
                     [
                         ['ID_GESTION',$gestion->ID_GESTION]
                     ])->get();

 foreach($recomendacioness as $recomendacione)
                {
$detallerecomendacion=trim($recomendacione->RECOMENDACION);
                }


//ESTADO
$estatus = Estatus::where('CESTATUSESTRATEGIA',$gestion->fgestionestrategia->CESTATUSESTRATEGIA)->get();
 foreach($estatus as $estatu)
                {
$estado=trim($estatu->NOMBRE);
                }

//socio

$reclamos=new ReclamosEstructura();

$socios = ReclamosEstructura::where('CODIGO',$gestion->ID_GESTION)->get();
 foreach($socios as $socio)
                {
$nombresocio=trim($socio->NOMBRE);
                }

//RESPONSABLE
$responsableids = Gestionasignacion::where('ID_GESTION',trim($gestion->ID_GESTION))->get();
 foreach($responsableids as $responsableid)
                {

                $codigointerno=$responsableid->NUMERO_ASIGNACION;
//TRAER EL NOMBRE DEL RESPONSABLE
     $responsables = Responsables::where(
                     [
                         ['ID',$responsableid->CUSUARIO_ASIGNACION]
                     ])->get();
 foreach($responsables as $responsable)
                {
                    $nombreresponsable=trim($responsable->NOMBRES);
                    $apellidoresponsable=trim($responsable->APELLIDOS);
                }
     $nombreresponsable=$nombreresponsable . " " . $apellidoresponsable;
                }



         $gestioness[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
              'INFORME'=>trim($gestion->INFORME),
              'INTERNO'=>trim($codigointerno),
              'RESPONSABLE'=>$nombreresponsable,
              'ESTRATEGIA'=>trim($gestion->fgestionestrategia->ESTRATEGIA),
              'RECOMENDACION'=>trim($detallerecomendacion),
              'FINICIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FINICIO)),
              'FFIN'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FFIN)),
              'PORCENTAJE'=>trim($gestion->fgestionestrategia->PORCENTAJE),
              'ESTADO'=>trim($estado),
              'SOCIO'=>trim($nombresocio)
              
              //TRAER EL PERIODO
             
             //'IDENTIFICACION'=>trim($gestion->fgestionhallazgo->HALLAZGO),

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$gestioness);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }


/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//////////////////SCAR RECOMENDACIONES CON PARAMETROS//////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
                            //SACAR TODOS LAS RECOMENDACIONES 
    public function getreclamosparam($tipocontrol,$codigo,$informe,$codinterno,$cedula,$estatus,$condicion1,$finicio1,$ffin1,$condicion2,$finicio2,$ffin2,$canceladas){
        $parametrotipocontrol=strtoupper($tipocontrol);
        $parametrocodigo=strtoupper($codigo);
        $parametroinforme=strtoupper($informe);
        $parametrointerno=strtoupper($codinterno);
        $parametrocedula=strtoupper($cedula);
        $parametroestatus=strtoupper($estatus);
        $contador=0;
        $contadorfi=0;
        $contadorff=0;
        $contador1=0;
        $integer =0; 
        $estado='';
        $responsable='';



//////////////////////////////////////////////////////////     
////////////////////////////////////////estado///////////
//////////////////////////////////////////////////////////
               $estatus='005';
if($canceladas=='NOR')
{
$nocanceladas = Gestionestrategias::whereNotIn('CESTATUSESTRATEGIA',[$estatus])->orderBy('ID_GESTION')->get();
}
if($canceladas=='CAN')
{
$nocanceladas = Gestionestrategias::whereIn('CESTATUSESTRATEGIA',[$estatus])->orderBy('ID_GESTION')->get();
}
 foreach($nocanceladas as $nocancelada)
                {
              $codigosgestionc[$contador] = array(     
             'ID_GESTION'=>trim($nocancelada->ID_GESTION)
        );
         $contador++;    
                }
//////////////////////////////////////////////////////////     
////////////////////////////////////////estado///////////
//////////////////////////////////////////////////////////


 //////////////////////////////////////////////////////////     
////////////////////////////////////////FINICIO///////////
//////////////////////////////////////////////////////////
$codigosfechainicio[]='';

if($condicion1==1)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','=',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==2)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','>',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==3)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','<',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==4)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','>=',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==5)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','<=',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==6)
{


$fechas=Gestionestrategias::whereBetween('FINICIO',[$finicio1, $ffin1])->orderBy('ID_GESTION')->get();
}
if($condicion1>0)
{
 foreach($fechas as $fecha)
                {
              $codigosfechainicio[$contadorfi] = array(     
             'ID_GESTION'=>trim($fecha->ID_GESTION)
        );
         $contadorfi++;    
                }


if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{

$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}

}

//////////////////////////////////////////////////////////     
////////////////////////////////////////FINICIO///////////
//////////////////////////////////////////////////////////



 //////////////////////////////////////////////////////////     
////////////////////////////////////////FFIN///////////
//////////////////////////////////////////////////////////

$codigosfechafin[]='';

if($condicion2==7)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','=',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==8)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','>',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==9)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','<',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==10)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','>=',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==11)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','<=',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==12)
{

$fechaFs=Gestionestrategias::whereBetween('FFIN',[$finicio2, $ffin2])->orderBy('ID_GESTION')->get();
}

if($condicion2>0)
{
 foreach($fechaFs as $fechaF)
                {
              $codigosfechafin[$contadorff] = array(     
             'ID_GESTION'=>trim($fechaF->ID_GESTION)
        );
         $contadorff++;    
                }


if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{

$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}

}

//////////////////////////////////////////////////////////     
////////////////////////////////////////FFIN///////////
//////////////////////////////////////////////////////////



if($codigosfechafin[0]=='' && $codigosfechainicio[0]!='')
{
$codigosfechafin=$codigosfechainicio;
}
if($codigosfechafin[0]!='' && $codigosfechainicio[0]=='')
{
$codigosfechainicio=$codigosfechafin;
}

//////////////////////////////////////////////////////////     
////////////////////////////////////////ESTATUS///////////
//////////////////////////////////////////////////////////
//SOLO ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

                if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
}
//SOLO CODIGO Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

                          if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INFORME Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

               if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

// CODIGO INFORME INTERNO Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      //['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }

if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INFORME INTERNO CEDULA Y ESTATUS ese
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }

 
if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();

                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INFORME INTERNO CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INTERNO CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();

                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INTERNO Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      //['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INTERNO CEDULA Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

// AQUI ESTOY TRABAJANDO
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus!=0)
{
$contador=0;
$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      //['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

// CODIGO CEDULA Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula], 
                      //['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INFORME CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula], 
                      //['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INFORME INTERNO Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                     // ['CUSUARIO_ASIGNACION',$parametrocedula], 
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
//SOLO INFORME Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
//SOLO INTERNO Y ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      //['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
//SOLO CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus!=0)
{
    $estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }


    $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
 //////////////////////////////////////////////////////////     
////////////////////////////////////////ESTATUS//////////////////
//////////////////////////////////////////////////////////









//////////////////////////////////////////////////////////
//SOLO CEDULA
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//CODIGO Y CEDULA
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0  && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}



//////////////////////////////////////////////////////////
//INFORME Y CEDULA
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//CODIGO INFORME Y CEDULA
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//INTERNO Y CEDULA
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//CODIGO INTERNO Y CEDULA
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
  if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

//////////////////////////////////////////////////////////
//INFORME INTERNO Y CEDULA
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                       // ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                       // ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

//////////////////////////////////////////////////////////
//CODIGO INFORME INTERNO Y CEDULA
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}



//////////////////////////////////////////////////////////
//SOLO INTERNO
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

//SOLO EL CODIGO
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{
if($condicion1>0 || $condicion2>6)
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
       }
}

//SOLO EL INFORME
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
       }
}

//CODIGO E INFORME
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{
if($condicion1>0 || $condicion2>6)
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
       }
}



//////////////////////////////////////////////////////////
//CODIGO E INTERNO
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
}



//////////////////////////////////////////////////////////
//INFORME E INTERNO
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}



//////////////////////////////////////////////////////////
//CODIGO INFORME E INTERNO
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


 foreach($gestiones as $gestion)
                {

$nombreresponsable='';
$apellidoresponsable='';
$codigointerno='';

//ESTADO
$estatus = Estatus::where('CESTATUSESTRATEGIA',$gestion->fgestionestrategia->CESTATUSESTRATEGIA)->get();
 foreach($estatus as $estatu)
                {
$estado=trim($estatu->NOMBRE);
                }


//RESPONSABLE
$responsableids = Gestionasignacion::where('ID_GESTION',trim($gestion->ID_GESTION))->get();
 foreach($responsableids as $responsableid)
                {
$codigointerno=$responsableid->NUMERO_ASIGNACION;
//TRAER EL NOMBRE DEL RESPONSABLE
     $responsables = Responsables::where(
                     [
                         ['ID',$responsableid->CUSUARIO_ASIGNACION]
                     ])->get();
 foreach($responsables as $responsable)
                {
                    $nombreresponsable=trim($responsable->NOMBRES);
                    $apellidoresponsable=trim($responsable->APELLIDOS);
                }
     $nombreresponsable=$nombreresponsable . " " . $apellidoresponsable;
                }



//consultr recomendaciones


//TRAER LA RECOEMNDACION
$detallerecomendacion='';
     $recomendacioness = Gestionrecomendaciones::where(
                     [
                         ['ID_GESTION',$gestion->ID_GESTION]
                     ])->get();
 foreach($recomendacioness as $recomendacione)
                {
$detallerecomendacion=trim($recomendacione->RECOMENDACION);
                }





         $gestioness[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
              'INFORME'=>trim($gestion->INFORME),
              'INTERNO'=>trim($codigointerno),
              'RESPONSABLE'=>$nombreresponsable,
              'ESTRATEGIA'=>trim($gestion->fgestionestrategia->ESTRATEGIA),
              'RECOMENDACION'=>trim($detallerecomendacion),
              'FINICIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FINICIO)),
              'FFIN'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FFIN)),
              'PORCENTAJE'=>trim($gestion->fgestionestrategia->PORCENTAJE),
              'ESTADO'=>trim($estado),
              //TRAER EL PERIODO
             
             //'IDENTIFICACION'=>trim($gestion->fgestionhallazgo->HALLAZGO),

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$gestioness);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }

//CON ESTE METODO SOLO VAMOS A GRABAR EL COMENTARIO EN LA TABLA TESTRATEGIAASIGNACION
public function updateReclamo($id,$porcentaje,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        $params_arrayreclamo = json_decode($json,true);//esto em devuelve un array
        
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////GUARDAR SOLO EL COMENTARIO//////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
         if(!empty($params_array))
         {



if($params_array['RESOLUCION']!='')
{
    $entor='si';
            //reclamos
$reclamos_update = ReclamosEstructura::where('CODIGO', $id)->update([
    'CRESOLUCION' => $params_array['RESOLUCION'],
    'MONTO' => $params_array['MONTO'],
    'INTERES' => $params_array['INTERES'],
    'TOTAL_RESTITUIDO' => $params_array['TOTAL']
]);


}

                     //QUITAR LO QUE NO QUIERO ACTUALIZAR 
         unset($params_array['ID_GESTION']);
         unset($params_array['NUMERO_ASIGNACION']);
         unset($params_array['ID_PERIODO']);         
         unset($params_array['DIA']);
         unset($params_array['FASIGNACION']);
         unset($params_array['CUSUARIO_AUDITORIA']);
         unset($params_array['CUSUARIO_ASIGNACION']);
         unset($params_array['CUSUARIO_CORESPONSABLE']);
         unset($params_array['ARCHIVO_ASIGNACION']);
         unset($params_array['ARCHIVO_ENTREGA']);
         unset($params_array['DETALLE_ASIGNACION']);
         unset($params_array['CUSUARIO_CORESPONSABLE2']);
         unset($params_array['CUSUARIO_CORESPONSABLE3']);  
         unset($params_array['FCONTABLE']);
         unset($params_array['RENOVADA']);
         unset($params_array['ID_ANTERIOR']);

         unset($params_array['RESOLUCION']);
         unset($params_array['MONTO']);
         unset($params_array['INTERES']);
         unset($params_array['TOTAL']);
             //actualizar el usuario en la bbd
             $limite_update =  Gestionasignacion::where('ID_GESTION',$id)->update($params_array);
             
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////FIN SOLO EL COMENTARIO//////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
             
             //actualizar el usuario en la bbd

             $porcentaje_update =  Gestionestrategias::where('ID_GESTION',$id)->update(['PORCENTAJE'=>$porcentaje]);



             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'La asignacion no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }

}
