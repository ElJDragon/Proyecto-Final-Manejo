<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Gestionauditoria;
use App\Models\Gestionestrategias;
use App\Models\Gestionhallazgo;
use App\Models\Gestionrecomendaciones;
use App\Models\Gestionasignacion;
use App\Models\Responsables;
use App\Models\Departamentos;

use App\Models\Periodos;

use App\Models\Estatus;

use App\Helpers\JwtAuth;

class LoteController extends Controller
{





///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
public function subirLotePersona(Request $request){
         //ACTUALIZAR EL USUARIO
             //recoger los datos por post

        $json =$request->input('json',null);
         $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array





         if(!empty($params_array))
         {


  foreach ($params_array as $key => $value) {

        //Crear el Responsable
    $gestion=new Responsables();
   
      if (array_key_exists('CODIGODEPARTAMENTO', $value)) {
    $gestion->COD_DEPARTAMENTO= strtoupper($value['CODIGODEPARTAMENTO']);
        }

    if (array_key_exists('NOMBRES', $value)) {
    $gestion->NOMBRES= strtoupper($value['NOMBRES']);
        }

            if (array_key_exists('APELLIDOS', $value)) {
    $gestion->APELLIDOS= strtoupper($value['APELLIDOS']);
        }
            if (array_key_exists('EMAIL', $value)) {
    $gestion->EMAIL= strtoupper($value['EMAIL']);
        }
            if (array_key_exists('TELEFONO', $value)) {
    $gestion->TELEFONO= strtoupper($value['TELEFONO']);
        }
   
    $gestion->save();






}

         //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El archivo no se ha cargado correctamente');
         }
         return response()->json($data,$data['code']);
     } 



///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
public function subirLoteDepartamentos(Request $request){
         //ACTUALIZAR EL USUARIO
             //recoger los datos por post

        $json =$request->input('json',null);
         $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array





         if(!empty($params_array))
         {


  foreach ($params_array as $key => $value) {

        //Crear el Responsable
    $gestion=new Departamentos();
   
      if (array_key_exists('CODIGODEPARTAMENTO', $value)) {
    $gestion->COD_DEPARTAMENTO= strtoupper($value['CODIGODEPARTAMENTO']);
        }

    if (array_key_exists('NOMBRE', $value)) {
    $gestion->NOMBRE= strtoupper($value['NOMBRE']);
        }

   
    $gestion->save();

}

         //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El archivo no se ha cargado correctamente');
         }
         return response()->json($data,$data['code']);
     } 


}
