<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Telefonos;
use App\Models\Tmensajes;
use App\Models\Emails;
use App\Models\User;
use App\Models\Responsables;

class WhatsAppController extends Controller
{
  
  public function enviarMensaje(Request $request)
    {

      $json = $request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
         $params_array = array_map('trim', $params_array);
        
        $mensajeenviar='';
        $destinatario = $params_array['DESTINO'];
        $asunto = $params_array['ASUNTO'];
        $tipo = $params_array['TIPO'];
        $campo = $params_array['CAMPO'];


/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//VERIFICAR SI EL SMS ES PARA AUDITORIA////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
if($destinatario=='AUDITORIA')
{
//TRAER TODOS LOS USUARIOS
$destinatariossdos = User::where('role', 'AUDITOR')->get();
 foreach($destinatariossdos as $destinatariossdo)
                {
//TRAER TODAS LAS PERSONAS
$personass2 = Responsables::where('EMAIL', $destinatariossdo->Email)->get();
foreach($personass2 as $personas2)
                {
//ENVIAR LOS SMS A LOS AUDITORES
/////////////////////////////////////////
$params='';
$enviara='+593'.$personas2->TELEFONO;
$mensajes = Emails::select($campo)->where('CODIGO', $tipo)->get();
 foreach($mensajes as $mensaje)
                {
$params=array(
'token' => env('TOKEN'),
'to' => $enviara,
'body' => trim($mensaje->$campo.$asunto)
);
}
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => env('URL'),
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => http_build_query($params),
  CURLOPT_HTTPHEADER => array(
    "content-type: application/x-www-form-urlencoded"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "Error #:" . $err;
} else {
  echo $response;
}

                }
                }
}
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//VERIFICAR SI EL SMS ES PARA AUDITORIA////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
else
{  

$enviara='+593'.$destinatario;
$mensajes = Emails::select($campo)->where('CODIGO', $tipo)->get();
 foreach($mensajes as $mensaje)
                {

                  
$params=array(
'token' => env('TOKEN'),
'to' => $enviara,
'body' => trim($mensaje->$campo)
);
}
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => env('URL'),
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => http_build_query($params),
  CURLOPT_HTTPHEADER => array(
    "content-type: application/x-www-form-urlencoded"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "Error #:" . $err;
} else {
  echo $response;
}
}

}



///////////////////////////////////////////////////////////////////////////////////7777
/////////////////////////////////ENVIO DE IMAGENES MASIOS///////////////////////////7
////////////////////////////////////////////////////////////////////////////////7

  public function enviarImagen(Request $request)
    {
///////////////////////////ENCABEZADO
      $json = $request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
         $params_array = array_map('trim', $params_array);
        
        $codigoimg='';
        $mensajeenviar='';
        $destinatario = $params_array['DESTINO'];
        $asunto = $params_array['ASUNTO'];
        $tipo = $params_array['TIPO'];
        $campo = $params_array['CAMPO'];

        if($campo=='ASIGNACION')
        {$codigoimg='1';}
      if($campo=='APROBACION')
        {$codigoimg='2';}
      if($campo=='NEGACION')
        {$codigoimg='3';}
      if($campo=='NOTIFICACION')
        {$codigoimg='4';}


$enviara='+593'.$destinatario;

//SI HAY MAS DE UNA IMAGEN INSERTAR UN WHERE
     $mensajes = Tmensajes::where('CODIGO',$codigoimg)->get();
 foreach($mensajes as $mensaje)
                {
$params=array(
'token' => env('TOKEN'),
'to' => $enviara,
'image' => $mensaje->IMAGEN,
'caption' => 'CRECEMOS JUNTOS'
);


$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => env('URLIMG'),
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => http_build_query($params),
  CURLOPT_HTTPHEADER => array(
    "content-type: application/x-www-form-urlencoded"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
}
}
}

