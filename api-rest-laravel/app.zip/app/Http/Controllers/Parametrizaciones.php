<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Gestionauditoria;
use App\Models\Gestionestrategias;
use App\Models\Gestionhallazgo;
use App\Models\Gestionrecomendaciones;
use App\Models\Gestionasignacion;
use App\Models\Responsables;
use App\Models\Departamentos;
use App\Models\Periodos;
use App\Models\Tiposcontrol;
use App\Models\Estatus;
use App\Models\Parametros;
use App\Models\Emails;
use App\Models\Alertas;
use App\Models\Comentarios;
use App\Models\Secuenciales;
use App\Helpers\JwtAuth;

class Parametrizaciones extends Controller
{


//SACAR LA INFORMACION DE LA PERSONA
    public function getcorreoenviar($tipo){
     $integer=0;
$parametros= Emails::where('CODIGO',$tipo)->get();
  
 foreach($parametros as $parametro)
                {
         $agrupados[$integer] = array(     
'CODIGO'=>trim($parametro->CODIGO),
'ASIGNACION'=>trim($parametro->ASIGNACION),
'APROBACION'=>trim($parametro->APROBACION),
'NEGACION'=>trim($parametro->NEGACION),
'NOTIFICACION'=>trim($parametro->NOTIFICACION),
'AUDITORIA'=>trim($parametro->AUDITORIA)

        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'persona'=>$agrupados);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }


//SACAR LA INFORMACION DE LA PERSONA
    public function getpersonas($cedula){
     $integer=0;
$parametros= Responsables::where('ID',$cedula)->get();
  
 foreach($parametros as $parametro)
                {
         $agrupados[$integer] = array(     
'ID'=>trim($parametro->ID),
'NOMBRES'=>trim($parametro->NOMBRES),
'APELLIDOS'=>trim($parametro->APELLIDOS),
'EMAIL'=>trim($parametro->EMAIL),
'TELEFONO'=>trim($parametro->TELEFONO)

        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'persona'=>$agrupados);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }



//SACAR EL TOTAL POR TIPO D E CONTROL
    public function getParametros(){
     $integer=0;
     $parametros = Parametros::All();

 foreach($parametros as $parametro)
                {
         $agrupados[$integer] = array(     
             'CODIGO'=>trim($parametro->CODIGO),
'PREGUNTAS'=>trim($parametro->PREGUNTAS),
'INTENTOS'=>trim($parametro->INTENTOS),
'CALIFICACION'=>trim($parametro->CALIFICACION),
'LIMITE'=>trim($parametro->LIMITE)


        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'parametros'=>$agrupados);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }


////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////

                            //SACAR EL TOTAL POR TIPO D E CONTROL
    public function getEmails($id){
     $integer=0;
  
     $parametros = Emails::where(
                     [
                         ['CODIGO',$id]
                     ])->get();




 foreach($parametros as $parametro)
                {
         $agrupados[$integer] = array(     
             'CODIGO'=>trim($parametro->CODIGO),
'ASIGNACION'=>trim($parametro->ASIGNACION),
'APROBACION'=>$parametro->APROBACION,
'NEGACION'=>$parametro->NEGACION,
'NOTIFICACION'=>$parametro->NOTIFICACION,
'AUDITORIA'=>$parametro->AUDITORIA
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'parametros'=>$agrupados);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }






public function updateEmail($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
         if(!empty($params_array))
         {
 
             //actualizar el usuario en la bbd
             $limite_update =  Emails::where('CODIGO',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El Email no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }
  


  public function updateParametro($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
         if(!empty($params_array))
         {
 
             //actualizar el usuario en la bbd
             $limite_update =  Parametros::where('CODIGO',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El Email no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }

///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVA RECOMENDACION
    public function nuevarecomendacion(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        
     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        //'ID_GESTION'=>'required',
        'ID_CONTROL'=>'required',

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'La asignacion no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {

        /////////////////
        ////TRAER SECUENCIA
        ////////////////
if($params_array['ID_CONTROL']!='REC01')
        {
         $numsecuencia=0;
         $codsecuencia='';   
         $secuenciales = Secuenciales::where('CODIGO',$params_array['ID_CONTROL'])->max('SECUENCIA');
        $numsecuencia=$secuenciales+1;
      $codsecuencia=$params_array['ID_CONTROL'].$numsecuencia;    


      ////ACTUALIZAR LA SECUENCIA
      $usuario = Secuenciales::find($params_array['ID_CONTROL']);
      $usuario->update(['SECUENCIA' => $numsecuencia]);    
        }

        /////////////////
        ////TRAER SECUENCIA
        ////////////////


            $asignacion=new Gestionauditoria();

        if($params_array['ID_CONTROL']!='REC01')
        {
           $asignacion->ID_GESTION= $codsecuencia;     
        }else
        {
            $asignacion->ID_GESTION= strtoupper($params_array['ID_GESTION']);
        }

        //Crear el GESTIONAUDITORIA

    
    $asignacion->ID_CONTROL=strtoupper($params_array['ID_CONTROL']);
    $asignacion->IDENTIFICACION= strtoupper($params_array['IDENTIFICACION']);
$asignacion->RAZONSOCIAL= strtoupper($params_array['RAZONSOCIAL']);
$asignacion->INFORME= strtoupper($params_array['INFORME']);
$asignacion->FEMISION= date("d/m/Y", strtotime($params_array['FEMISION']));
$asignacion->FENVIOINFORME=date("d/m/Y", strtotime($params_array['FENVIOINFORME']));
$asignacion->FLIMITE= date("d/m/Y", strtotime($params_array['FLIMITE']));
$asignacion->NOMBREEXAMEN= strtoupper($params_array['NOMBREEXAMEN']);
//Guardar el Usuario
  $asignacion->save();


$hallazgo=new Gestionhallazgo();
      if($params_array['ID_CONTROL']!='REC01')
        {
           $hallazgo->ID_GESTION= $codsecuencia;     
        }else
        {
            $hallazgo->ID_GESTION= strtoupper($params_array['ID_GESTION']);
        }
$hallazgo->NUMERO_HALLAZGO= strtoupper($params_array['NUMERO_HALLAZGO']);
$hallazgo->HALLAZGO= strtoupper($params_array['HALLAZGO']);
  $hallazgo->save();


    
$recomendaciones=new Gestionrecomendaciones();
      if($params_array['ID_CONTROL']!='REC01')
        {
           $recomendaciones->ID_GESTION= $codsecuencia;     
        }else
        {
            $recomendaciones->ID_GESTION= strtoupper($params_array['ID_GESTION']);
        }
$recomendaciones->NUMERO_RECOMENDACION= strtoupper($params_array['NUMERO_RECOMENDACION']);
$recomendaciones->RECOMENDACION= strtoupper($params_array['RECOMENDACION']);
  $recomendaciones->save();

$estrategia=new Gestionestrategias();
      if($params_array['ID_CONTROL']!='REC01')
        {
           $estrategia->ID_GESTION= $codsecuencia;     
        }else
        {
            $estrategia->ID_GESTION= strtoupper($params_array['ID_GESTION']);
        }
$estrategia->NUMERO_ESTRATEGIA= strtoupper($params_array['NUMERO_ESTRATEGIA']);
$estrategia->ESTRATEGIA= strtoupper($params_array['ESTRATEGIA']);
if($params_array['ID_CONTROL']=='REC01')
{
$estrategia->FINICIO= date("d/m/Y", strtotime($params_array['FINICIO']));}
else
{
    $estrategia->FINICIO= ($params_array['FINICIO']);
}

$estrategia->FFIN= date("d/m/Y", strtotime($params_array['FFIN']));
$estrategia->PORCENTAJE= ($params_array['PORCENTAJE']);
$estrategia->CESTATUSESTRATEGIA= ($params_array['CESTATUSESTRATEGIA']);
  $estrategia->save();
    
  //enviar la respuesta
          $data = array(
          'status'=>'succes',
          'code'=>200, 
          'message'=>'La asignación se ha creado correctamente'
        );
    }
        }else
        {
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }

        return response()->json($data,$data['code']);
    }



    //SACAR LAS ALERTAS VIGENTES
    public function getalertas(){
     $integer=0;
$fechaActual = date("d-m-Y");
          $alertas = Alertas::where(
                     [
                         ['FECHAFIN','>',$fechaActual]
                     ])->get();




 foreach($alertas as $parametro)
                {
         $agrupados[$integer] = array(     
'CODIGO'=>trim($parametro->CODIGO),
'ALERTA'=>trim($parametro->ALERTA),
'FECHAINICIO'=>$parametro->FECHAINICIO,
'FECHAFIN'=>$parametro->FECHAFIN,
'ID_GESTION'=>trim($parametro->ID_GESTION)

        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'alertas'=>$agrupados);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }
}
