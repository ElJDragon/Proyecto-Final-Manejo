<?php

namespace App\Http\Controllers;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Gestionauditoria;
use App\Models\Gestionestrategias;
use App\Models\Gestionhallazgo;
use App\Models\Gestionrecomendaciones;
use App\Models\Gestionasignacion;
use App\Models\Responsables;
use App\Models\User;
use App\Models\Periodos;

use App\Models\Estatus;

use App\Helpers\JwtAuth;

class AsignacionesAuditoria extends Controller
{
    

//////////////////////////////////////////////////////////////////
///////////////////ASIGNACIONES X USUARIO///////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
  public function getAsignacioneporUsuario($id,$usr){
        $integer =0; 
        $contador =0; 
        $estado='';
      $responsable='';
      $codpersona='';
      
$usuarios = Responsables::where('USUARIO',$usr)->get();
 foreach($usuarios as $usuario)
                {
                   $codpersona=$usuario->ID;
                }

//AGREGAR EL SUARIO DE ASIGNACION

$asignaciones = Gestionasignacion::where('CUSUARIO_ASIGNACION',$codpersona)->get();
//$asignaciones = Gestionasignacion::All();
 foreach($asignaciones as $asignacione)
                {
              $codigosgestion[$contador] = array(     
             'ID_GESTION'=>trim($asignacione->ID_GESTION)
        );
         $contador++;    
                }


     $gestiones = Gestionauditoria::where(
                     [
                         ['ID_CONTROL',$id]
                     ])->whereIn('ID_GESTION',$codigosgestion)->get();


    
 foreach($gestiones as $gestion)
                {
$dias = 0;
$nombreresponsable='';
$apellidoresponsable='';
$codigointerno='';
//OBTENER LA DIFERENCIA DE DIAS

//----------------------------------------------

$fechaFin = $gestion->fgestionestrategia->FFIN;
$fechaActual = new DateTime();
$fechaa= new DateTime($fechaFin);
// Calcula la diferencia en segundos
$diferenciaEnSegundos = $fechaa->getTimestamp() - $fechaActual->getTimestamp();
// Convierte la diferencia en días
$diferenciaEnDias = floor($diferenciaEnSegundos / (60 * 60 * 24));

//----------------------------------------------

//TRAER LA RECOEMNDACION
$detallerecomendacion='';
     $recomendacioness = Gestionrecomendaciones::where(
                     [
                         ['ID_GESTION',$gestion->ID_GESTION]
                     ])->get();
 foreach($recomendacioness as $recomendacione)
                {
$detallerecomendacion=trim($recomendacione->RECOMENDACION);
                }




//ESTADO
$estatus = Estatus::where('CESTATUSESTRATEGIA',$gestion->fgestionestrategia->CESTATUSESTRATEGIA)->get();
 foreach($estatus as $estatu)
                {
$estado=trim($estatu->NOMBRE);
                }


//RESPONSABLE
$responsableids = Gestionasignacion::where('ID_GESTION',trim($gestion->ID_GESTION))->get();
 foreach($responsableids as $responsableid)
                {

                $codigointerno=$responsableid->NUMERO_ASIGNACION;
//TRAER EL NOMBRE DEL RESPONSABLE
     $responsables = Responsables::where(
                     [
                         ['ID',$responsableid->CUSUARIO_ASIGNACION]
                     ])->get();
 foreach($responsables as $responsable)
                {
                    $nombreresponsable=trim($responsable->NOMBRES);
                    $apellidoresponsable=trim($responsable->APELLIDOS);
                }
     $nombreresponsable=$nombreresponsable . " " . $apellidoresponsable;
                }



         $gestioness[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
              'INFORME'=>trim($gestion->INFORME),
              'INTERNO'=>trim($codigointerno),
              'CODRESPONSABLE'=>trim($responsableid->CUSUARIO_ASIGNACION),
              'RESPONSABLE'=>$nombreresponsable,
              'ESTRATEGIA'=>trim($gestion->fgestionestrategia->ESTRATEGIA),
                'RECOMENDACION'=>trim($detallerecomendacion),
              
              'FINICIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FINICIO)),
              'FFIN'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FFIN)),
              'PORCENTAJE'=>trim($gestion->fgestionestrategia->PORCENTAJE),
              'ESTADO'=>trim($estado),
                'DIAS'=>$diferenciaEnDias,
              
              //TRAER EL PERIODO
             
             //'IDENTIFICACION'=>trim($gestion->fgestionhallazgo->HALLAZGO),

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$gestioness);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }


    public function getAsignacioneRecomendaciones($id){
        $integer =0; 
        $contador =0; 
        $contadorr =0; 
        $estado='';
      $responsable='';
      $estatus='004';

//OJO OJO OJO OJO OJO OJO OJO OJO OJO OJO OJO OJO OJO OJO OJO 
      //OJO OJO OJO OJO OJO OJO OJO OJO OJO OJO OJO OJO 
//AGREGAR EL SUARIO DE ASIGNACION
//$asignaciones = Gestionasignacion::whereIn('ID_GESTION',$codigosgestion)->get();
$asignaciones = Gestionasignacion::All();
 foreach($asignaciones as $asignacione)
                {
              $codigosgestion[$contador] = array(     
             'ID_GESTION'=>trim($asignacione->ID_GESTION)
        );
         $contador++;    
                }

//no traer las entragadas
     $entragadas = Gestionestrategias::whereIn('ID_GESTION',$codigosgestion)->whereNotIn('CESTATUSESTRATEGIA',[$estatus])->get();
      foreach($entragadas as $entragada)
                {
              $codentregadas[$contadorr] = array(     
             'ID_GESTION'=>trim($entragada->ID_GESTION)
        );
         $contadorr++;    
                }






     $gestiones = Gestionauditoria::where(
                     [
                         ['ID_CONTROL',$id]
                     ])->whereIn('ID_GESTION',$codentregadas)->get();


    
 foreach($gestiones as $gestion)
                {
$dias = 0;
$nombreresponsable='';
$apellidoresponsable='';
$codigointerno='';
//OBTENER LA DIFERENCIA DE DIAS

//----------------------------------------------

$fechaFin = $gestion->fgestionestrategia->FFIN;
$fechaActual = new DateTime();
$fechaa= new DateTime($fechaFin);
// Calcula la diferencia en segundos
$diferenciaEnSegundos = $fechaa->getTimestamp() - $fechaActual->getTimestamp();
// Convierte la diferencia en días
$diferenciaEnDias = floor($diferenciaEnSegundos / (60 * 60 * 24));

//----------------------------------------------

//TRAER LA RECOEMNDACION
$detallerecomendacion='';
     $recomendacioness = Gestionrecomendaciones::where(
                     [
                         ['ID_GESTION',$gestion->ID_GESTION]
                     ])->get();
 foreach($recomendacioness as $recomendacione)
                {
$detallerecomendacion=trim($recomendacione->RECOMENDACION);
                }




//ESTADO
$estatus = Estatus::where('CESTATUSESTRATEGIA',$gestion->fgestionestrategia->CESTATUSESTRATEGIA)->get();
 foreach($estatus as $estatu)
                {
$estado=trim($estatu->NOMBRE);
                }


//RESPONSABLE
$responsableids = Gestionasignacion::where('ID_GESTION',trim($gestion->ID_GESTION))->get();
 foreach($responsableids as $responsableid)
                {

                $codigointerno=$responsableid->NUMERO_ASIGNACION;
//TRAER EL NOMBRE DEL RESPONSABLE
     $responsables = Responsables::where(
                     [
                         ['ID',$responsableid->CUSUARIO_ASIGNACION]
                     ])->get();
 foreach($responsables as $responsable)
                {
                    $nombreresponsable=trim($responsable->NOMBRES);
                    $apellidoresponsable=trim($responsable->APELLIDOS);
                }
     $nombreresponsable=$nombreresponsable . " " . $apellidoresponsable;
                }



         $gestioness[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
              'INFORME'=>trim($gestion->INFORME),
              'INTERNO'=>trim($codigointerno),
              'CODRESPONSABLE'=>trim($responsableid->CUSUARIO_ASIGNACION),
              'RESPONSABLE'=>$nombreresponsable,
              'ESTRATEGIA'=>trim($gestion->fgestionestrategia->ESTRATEGIA),
                'RECOMENDACION'=>trim($detallerecomendacion),
              
              'FINICIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FINICIO)),
              'FFIN'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FFIN)),
              'PORCENTAJE'=>trim($gestion->fgestionestrategia->PORCENTAJE),
              'ESTADO'=>trim($estado),
                'DIAS'=>$diferenciaEnDias,
              
              //TRAER EL PERIODO
             
             //'IDENTIFICACION'=>trim($gestion->fgestionhallazgo->HALLAZGO),

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$gestioness);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }




                            /////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//////////////////SCAR RECOMENDACIONES CON PARAMETROS//////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
                            //SACAR TODOS LAS RECOMENDACIONES 
    public function getAsignacionesParam($usuario,$tipocontrol,$codigo,$informe,$codinterno,$cedula,$estatus,$condicion1,$finicio1,$ffin1,$condicion2,$finicio2,$ffin2){
        $parametrotipocontrol=strtoupper($tipocontrol);
        $parametrocodigo=strtoupper($codigo);
        $parametroinforme=strtoupper($informe);
        $parametrointerno=strtoupper($codinterno);
        $parametrocedula=strtoupper($cedula);
        $parametroestatus=strtoupper($estatus);
        $contador=0;
        $contadorfi=0;
        $contadorff=0;
        $contador1=0;
        $integer =0; 
        $estado='';
        $responsable='';



//////////////////////////////////////////////////////////     
////////////////////////////////////////estado///////////
//////////////////////////////////////////////////////////
      $codpersona='';
      
$usuarios = Responsables::where('USUARIO',$usuario)->get();
 foreach($usuarios as $usuario)
                {
                   $codpersona=$usuario->ID;
                }

//AGREGAR EL SUARIO DE ASIGNACION

$asignaciones = Gestionasignacion::where('CUSUARIO_ASIGNACION',$codpersona)->get();




//$asignaciones = Gestionasignacion::All();
 foreach($asignaciones as $asignacione)
                {
              $codigosgestionc[$contador] = array(     
             'ID_GESTION'=>trim($asignacione->ID_GESTION)
        );
         $contador++;    
                }

//////////////////////////////////////////////////////////     
////////////////////////////////////////estado///////////
//////////////////////////////////////////////////////////




 //////////////////////////////////////////////////////////     
////////////////////////////////////////FINICIO///////////
//////////////////////////////////////////////////////////
$codigosfechainicio[]='';

if($condicion1==1)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','=',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==2)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','>',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==3)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','<',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==4)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','>=',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==5)
{
$fechas=Gestionestrategias::where(
                     [ 
                      ['FINICIO','<=',$finicio1]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion1==6)
{


$fechas=Gestionestrategias::whereBetween('FINICIO',[$finicio1, $ffin1])->orderBy('ID_GESTION')->get();
}
if($condicion1>0)
{
 foreach($fechas as $fecha)
                {
              $codigosfechainicio[$contadorfi] = array(     
             'ID_GESTION'=>trim($fecha->ID_GESTION)
        );
         $contadorfi++;    
                }


if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{

$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}

}

//////////////////////////////////////////////////////////     
////////////////////////////////////////FINICIO///////////
//////////////////////////////////////////////////////////



 //////////////////////////////////////////////////////////     
////////////////////////////////////////FFIN///////////
//////////////////////////////////////////////////////////

$codigosfechafin[]='';

if($condicion2==7)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','=',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==8)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','>',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==9)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','<',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==10)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','>=',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==11)
{
$fechaFs=Gestionestrategias::where(
                     [ 
                      ['FFIN','<=',$finicio2]  
                     ])->orderBy('ID_GESTION')->get();
}
if($condicion2==12)
{

$fechaFs=Gestionestrategias::whereBetween('FFIN',[$finicio2, $ffin2])->orderBy('ID_GESTION')->get();
}

if($condicion2>0)
{
 foreach($fechaFs as $fechaF)
                {
              $codigosfechafin[$contadorff] = array(     
             'ID_GESTION'=>trim($fechaF->ID_GESTION)
        );
         $contadorff++;    
                }


if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{

$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}

}

//////////////////////////////////////////////////////////     
////////////////////////////////////////FFIN///////////
//////////////////////////////////////////////////////////



if($codigosfechafin[0]=='' && $codigosfechainicio[0]!='')
{
$codigosfechafin=$codigosfechainicio;
}
if($codigosfechafin[0]!='' && $codigosfechainicio[0]=='')
{
$codigosfechainicio=$codigosfechafin;
}

//////////////////////////////////////////////////////////     
////////////////////////////////////////ESTATUS///////////
//////////////////////////////////////////////////////////
//SOLO ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

                if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
}
//SOLO CODIGO Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

                          if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INFORME Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

               if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

// CODIGO INFORME INTERNO Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      //['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }

if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INFORME INTERNO CEDULA Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }

 
if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();

                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INFORME INTERNO CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INTERNO CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();

                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INTERNO Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      //['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO INTERNO CEDULA Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// CODIGO CEDULA Y ESTATUS
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula], 
                      //['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INFORME CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula], 
                      //['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
// INFORME INTERNO Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                     // ['CUSUARIO_ASIGNACION',$parametrocedula], 
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
//SOLO INFORME Y ESTATUS
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();

/*
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();*/

 foreach($estados as $estado)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
                    $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
//SOLO INTERNO Y ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus!=0)
{

$estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }

$internos = Gestionasignacion::where(
                     [ 
                      //['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
//SOLO CEDULA Y ESTATUS
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus!=0)
{
    $estados=Gestionestrategias::where(
                     [ 
                      ['CESTATUSESTRATEGIA',$parametroestatus]  
                     ])->orderBy('ID_GESTION')->get();
 foreach($estados as $estado)
                {
              $codigosstatus[$contador] = array(     
             'ID_GESTION'=>trim($estado->ID_GESTION)
        );
         $contador++;    
                }


    $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->whereIn('ID_GESTION',$codigosstatus)->orderBy('ID_GESTION')->get();


 foreach($internos as $interno)
                {
              $codigosinternos[$contador1] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador1++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}
 //////////////////////////////////////////////////////////     
////////////////////////////////////////ESTATUS//////////////////
//////////////////////////////////////////////////////////









//////////////////////////////////////////////////////////
//SOLO CEDULA
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                    }
                    else
                    {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//CODIGO Y CEDULA
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula!=0  && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}



//////////////////////////////////////////////////////////
//INFORME Y CEDULA
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        //['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//CODIGO INFORME Y CEDULA
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula]  
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//INTERNO Y CEDULA
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                        //['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//CODIGO INTERNO Y CEDULA
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
  if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        //['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

//////////////////////////////////////////////////////////
//INFORME INTERNO Y CEDULA
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                       // ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                       // ['ID_GESTION','like','%'.$parametrocodigo.'%']
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}

//////////////////////////////////////////////////////////
//CODIGO INFORME INTERNO Y CEDULA
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula!=0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                      ['CUSUARIO_ASIGNACION',$parametrocedula],  
                      ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('ID_GESTION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}



//////////////////////////////////////////////////////////
//SOLO INTERNO
if($parametrocodigo==0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol]
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

//SOLO EL CODIGO
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{
if($condicion1>0 || $condicion2>6)
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['ID_GESTION','like','%'.$parametrocodigo.'%']
                     ])->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
       }
}

//SOLO EL INFORME
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
       }
}

//CODIGO E INFORME
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno==0 && $parametrocedula==0 && $parametroestatus==0)
{
if($condicion1>0 || $condicion2>6)
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
           $gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                         ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
       }
}



//////////////////////////////////////////////////////////
//CODIGO E INTERNO
if($parametrocodigo!=0 && $parametroinforme==0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
}



//////////////////////////////////////////////////////////
//INFORME E INTERNO
if($parametrocodigo==0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}



//////////////////////////////////////////////////////////
//CODIGO INFORME E INTERNO
if($parametrocodigo!=0 && $parametroinforme!=0 && $parametrointerno!=0 && $parametrocedula==0 && $parametroestatus==0)
{
           $internos = Gestionasignacion::where(
                     [ 
                         ['NUMERO_ASIGNACION','like','%'.$parametrointerno.'%']
                     ])->orderBy('NUMERO_ASIGNACION')->get();

 foreach($internos as $interno)
                {
              $codigosinternos[$contador] = array(     
             'ID_GESTION'=>trim($interno->ID_GESTION)
        );
         $contador++;    
                }
if($condicion1>0 || $condicion2>6)
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosfechainicio)->whereIn('ID_GESTION',$codigosfechafin)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
                }
                else
                {
$gestiones = Gestionauditoria::where(
                     [ 
                        ['ID_CONTROL',$parametrotipocontrol],
                        ['ID_GESTION','like','%'.$parametrocodigo.'%'],
                        ['INFORME','like','%'.$parametroinforme.'%']
                     ])->whereIn('ID_GESTION',$codigosinternos)->whereIn('ID_GESTION',$codigosgestionc)->orderBy('ID_GESTION')->get();
}
}


 foreach($gestiones as $gestion)
                {

$nombreresponsable='';
$apellidoresponsable='';
$codigointerno='';

//ESTADO
$estatus = Estatus::where('CESTATUSESTRATEGIA',$gestion->fgestionestrategia->CESTATUSESTRATEGIA)->get();
 foreach($estatus as $estatu)
                {
$estado=trim($estatu->NOMBRE);
                }


//RESPONSABLE
$responsableids = Gestionasignacion::where('ID_GESTION',trim($gestion->ID_GESTION))->get();
 foreach($responsableids as $responsableid)
                {
$codigointerno=$responsableid->NUMERO_ASIGNACION;
//TRAER EL NOMBRE DEL RESPONSABLE
     $responsables = Responsables::where(
                     [
                         ['ID',$responsableid->CUSUARIO_ASIGNACION]
                     ])->get();
 foreach($responsables as $responsable)
                {
                    $nombreresponsable=trim($responsable->NOMBRES);
                    $apellidoresponsable=trim($responsable->APELLIDOS);
                }
     $nombreresponsable=$nombreresponsable . " " . $apellidoresponsable;
                }


//----------------------------------------------

$fechaFin = $gestion->fgestionestrategia->FFIN;
$fechaActual = new DateTime();
$fechaa= new DateTime($fechaFin);
// Calcula la diferencia en segundos
$diferenciaEnSegundos = $fechaa->getTimestamp() - $fechaActual->getTimestamp();
// Convierte la diferencia en días
$diferenciaEnDias = floor($diferenciaEnSegundos / (60 * 60 * 24));

//----------------------------------------------


         $gestioness[$integer] = array(     
             'ID_GESTION'=>trim($gestion->ID_GESTION),
              'INFORME'=>trim($gestion->INFORME),
              'INTERNO'=>trim($codigointerno),
              'RESPONSABLE'=>$nombreresponsable,
              'ESTRATEGIA'=>trim($gestion->fgestionestrategia->ESTRATEGIA),
              'FINICIO'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FINICIO)),
              'FFIN'=>date("d/m/Y", strtotime($gestion->fgestionestrategia->FFIN)),
              'PORCENTAJE'=>trim($gestion->fgestionestrategia->PORCENTAJE),
              'ESTADO'=>trim($estado),
              'DIAS'=>trim($diferenciaEnDias),
              //TRAER EL PERIODO
             
             //'IDENTIFICACION'=>trim($gestion->fgestionhallazgo->HALLAZGO),

        );
         $integer++;
                }

if($integer>0)
{
$data = array(
          'status'=>'error',
          'code'=>200, 
          'procesos'=>$gestioness);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros');
         }
         return response()->json($data,$data['code']);

                            }


}
