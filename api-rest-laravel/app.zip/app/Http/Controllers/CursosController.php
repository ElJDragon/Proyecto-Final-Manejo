<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Personas;
use App\Models\ReclamosCanales;
use App\Models\ReclamosLocalidad;
use App\Models\ReclamosDetalle;
use App\Models\ReclamosConcepto;
use App\Models\ReclamosEstructura;
use App\Models\ReclamosResolucion;

use Illuminate\Support\Facades\DB;
use DateTime;
use App\Models\Gestionauditoria;
use App\Models\Gestionestrategias;
use App\Models\Gestionhallazgo;
use App\Models\Gestionrecomendaciones;
use App\Models\Gestionasignacion;
use App\Models\Responsables;
use App\Models\Departamentos;
use App\Models\Periodos;
use App\Models\Tiposcontrol;
use App\Models\Estatus;
use App\Models\Parametros;
use App\Models\Emails;
use App\Models\Alertas;
use App\Models\Comentarios;
use App\Models\Cursoasignacion;
use App\Models\Estadocursos;
use App\Models\Preguntas;
use App\Models\Respuestas;
use App\Models\Evaluaciones;
use App\Models\Detalleeva;
use App\Models\Secuenciales;
use App\Models\Cursos;
use App\Models\Submodulos;
use App\Models\Adjuntos;
use App\Models\Cursodep;
use App\Models\Modulos;
use App\Helpers\JwtAuth;

class CursosController extends Controller
{
   ///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS RESPONSABLES
    public function nuevoCurso(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        


     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'NOMBRE'=>'required'//Comprobar si el usuario existe con unique

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El curso no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
             
        //Crear el Responsable
    $curso=new Cursos();
    $curso->NOMBRE= strtoupper($params_array['NOMBRE']);
    $curso->ESTAACTIVO= strtoupper($params_array['ESTAACTIVO']);
    $curso->ETAPA= strtoupper($params_array['ETAPA']);
    $curso->MODULOS= strtoupper($params_array['MODULOS']);
    $curso->COD_DEPARTAMENTO= strtoupper($params_array['COD_DEPARTAMENTO']);
    
    if($curso->save())
    {

        $id_generado = $curso->CODIGOCURSO; // `id` asume que es el nombre del campo ID

$data = array(
    'status' => 'success',
    'code' => 200, 
    'message' => 'El curso se ha creado correctamente con el ID: ' . $id_generado,
    'id' => $id_generado
);
    }
    else
    {
$data = array(
          'status'=>'error',
          'code'=>200, 
          'message'=>'Error al crear el curso'
        );
    }
    
    }
        }else
        {
    $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }
        return response()->json($data,$data['code']);
    }


 ///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS RESPONSABLES
    public function nuevoCapacitacion(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        


     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'NOMBRE'=>'required'//Comprobar si el usuario existe con unique

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El curso no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
             
        //Crear el Responsable
    $curso=new Cursos();
    $curso->NOMBRE= strtoupper($params_array['NOMBRE']);
    $curso->ESTAACTIVO= strtoupper($params_array['ESTAACTIVO']);
    $curso->ETAPA= strtoupper($params_array['ETAPA']);
    $curso->MODULOS= strtoupper($params_array['MODULOS']);
    $curso->COD_DEPARTAMENTO= strtoupper($params_array['COD_DEPARTAMENTO']);
    
    if($curso->save())
    {

    $id_generado = $curso->CODIGOCURSO;

 $modulo=new Modulos();
    $modulo->NOMBRE= 'MODULO BÁSICO';
    $modulo->DESCRIPCION= 'MODULO BÁSICO';
    $modulo->CODIGOCURSO= $curso->CODIGOCURSO;
    $modulo->ORDEN= 0;
    if($modulo->save())
    {

 $id_modulo = $modulo->CODIGO;

$data = array(
    'status' => 'success',
    'code' => 200, 
    'message' => 'El curso se ha creado correctamente con el ID: ' . $id_generado,
    'curso' => $id_generado,
    'modulo' => $id_modulo
);

}
    else
    {
$data = array(
          'status'=>'error',
          'code'=>200, 
          'message'=>'Error al crear el curso'
        );
    }
    }
    else
    {
$data = array(
          'status'=>'error',
          'code'=>200, 
          'message'=>'Error al crear el curso'
        );
    }
    
    }
        }else
        {
    $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }
        return response()->json($data,$data['code']);
    }

 ///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS RESPONSABLES
    public function CursoDep(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        


     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'CODIGOCURSO'=>'required'//Comprobar si el usuario existe con unique

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El curso no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {

$asignado = Cursodep::where([
    ['CODDEPARTAMENTO', trim($params_array['CODDEPARTAMENTO'])],
    ['CODIGOCURSO', trim($params_array['CODIGOCURSO'])],
])->get();

if ($asignado->count() > 0) {
//eliminar

    // Iterar sobre los registros encontrados
    foreach ($asignado as $registro) {
        // Eliminar cada registro encontrado
        $registro->delete();
    }

    // Devolver respuesta
    $data = [
        'status' => 'success',
        'code' => 200,
        'message' => 'Registros eliminados correctamente'
    ];


} else {
//ingresar


             
        //Crear el Responsable
    $ingreso=new Cursodep();
    $ingreso->CODIGOCURSO= strtoupper($params_array['CODIGOCURSO']);
    $ingreso->CODDEPARTAMENTO= strtoupper($params_array['CODDEPARTAMENTO']);

    if($ingreso->save())
    {

        $id_generado = $ingreso->CODIGO; // `id` asume que es el nombre del campo ID

$data = array(
    'status' => 'success',
    'code' => 200, 
    'message' => 'El curso se ha creado correctamente con el ID: ' . $id_generado,
    'id' => $id_generado
);
    }
    else
    {
$data = array(
          'status'=>'error',
          'code'=>200, 
          'message'=>'Error al crear el curso'
        );
    }



}


    
    }
        }else
        {
    $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }
        return response()->json($data,$data['code']);
    }

   ///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS RESPONSABLES
    public function nuevoEvaluacion(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        


     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'CODIGOCURSO'=>'required'//Comprobar si el usuario existe con unique

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El evaluacion no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {


$update = Evaluaciones::where([
    ['CODIGOCURSO', $params_array['CODIGOCURSO']],
    ['CODIGOMODULO', $params_array['CODIGOMODULO']],
    ['ACTIVA', '1'],
    ['USUARIO', $params_array['USUARIO']]
])->update(['ACTIVA' => '0']);



        //Crear el Responsable
    $evaluacion=new Evaluaciones();
    $evaluacion->CODIGOCURSO= strtoupper($params_array['CODIGOCURSO']);
    $evaluacion->CODIGOMODULO= strtoupper($params_array['CODIGOMODULO']);
    $evaluacion->USUARIO= strtoupper($params_array['USUARIO']);
    $evaluacion->ACTIVA= '1';

    
    if($evaluacion->save())
    {

        $id_generado = $evaluacion->CODIGO; // `id` asume que es el nombre del campo ID

$data = array(
    'status' => 'success',
    'code' => 200, 
    'message' => 'El curso se ha creado correctamente con el ID: ' . $id_generado,
    'id' => $id_generado
);
    }
    else
    {
$data = array(
          'status'=>'error',
          'code'=>200, 
          'message'=>'Error al crear el curso'
        );
    }
    
    }
        }else
        {
    $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }
        return response()->json($data,$data['code']);
    }



   ///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS RESPONSABLES
    public function nuevoDetalle(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        


     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'CODIGOEVA'=>'required'//Comprobar si el usuario existe con unique

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El evaluacion no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {

        //Crear el Responsable
    $detalle=new Detalleeva();
    $detalle->CODIGOEVA= strtoupper($params_array['CODIGOEVA']);
    $detalle->PREGUNTA= strtoupper($params_array['PREGUNTA']);
    $detalle->RESPUESTA= strtoupper($params_array['RESPUESTA']);
    $detalle->ESCORRECTA= strtoupper($params_array['ESCORRECTA']);

    
    if($detalle->save())
    {

        $id_generado = $detalle->CODIGO; // `id` asume que es el nombre del campo ID

$data = array(
    'status' => 'success',
    'code' => 200, 
    'message' => 'El curso se ha creado correctamente con el ID: ' . $id_generado,
    'id' => $id_generado
);
    }
    else
    {
$data = array(
          'status'=>'error',
          'code'=>200, 
          'message'=>'Error al crear el curso'
        );
    }
    
    }
        }else
        {
    $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }
        return response()->json($data,$data['code']);
    }



public function getmodulos($orden,$id){
        $integer =0;
        $parametro=trim($id);

$modulos = Modulos::where(
                     [ 
                         ['ORDEN',$orden],
                         ['CODIGOCURSO',$id]
                     ])->get(); 

 foreach($modulos as $modulo)
                {
         $enviarmodulo[$integer] = array(     
             'CODIGO'=>trim($modulo->CODIGO),
             'NOMBRE'=>trim($modulo->NOMBRE),
             'DESCRIPCION'=>trim($modulo->DESCRIPCION),
             'CODIGOCURSO'=>trim($modulo->CODIGOCURSO),
             'ORDEN'=>trim($modulo->ORDEN),
             'NOMBRECURSO'=>trim($modulo->fcursos->NOMBRE),
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'modulo'=>$enviarmodulo,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }



public function modulosuno($curso,$modulo){
        $integer =0;


$modulos = Modulos::where(
                     [ 
                         ['CODIGO',$modulo],
                         ['CODIGOCURSO',$curso]
                     ])->get(); 

 foreach($modulos as $modulo)
                {
         $enviarmodulo[$integer] = array(     
             'CODIGO'=>trim($modulo->CODIGO),
             'NOMBRE'=>trim($modulo->NOMBRE),
             'DESCRIPCION'=>trim($modulo->DESCRIPCION),
             'CODIGOCURSO'=>trim($modulo->CODIGOCURSO),
             'ORDEN'=>trim($modulo->ORDEN),
             'NOMBRECURSO'=>trim($modulo->fcursos->NOMBRE),
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'modulo'=>$enviarmodulo,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }


public function modulosactual($curso,$usuario){
        $integer =0;


$modulos = Cursoasignacion::where(
                     [ 
                         ['USUARIO',$usuario],
                         ['CURSO',$curso]
                     ])->get(); 

 foreach($modulos as $modulo)
                {
         $enviarmodulo[$integer] = array(     
             'ACTUAL'=>trim($modulo->MODULO)
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'modulo'=>$enviarmodulo,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }

public function getpreguntas($curos,$modulo){
        $integer =0;
        $parametro=trim($curos);
        $parametro2=trim($modulo);

$preguntas = Preguntas::where(
                     [ 
                         ['CODIGOCURSO',$parametro],
                         ['CODIGOMODULO',$parametro2],
                         ['ESTAACTIVA','1']
                     ])->get(); 


 foreach($preguntas as $pregunta)
                {
         $enviarpreguntas[$integer] = array( 
             'CODIGO'=>trim($pregunta->CODIGO),
             'CODIGOCURSO'=>trim($pregunta->CODIGOCURSO),
             'CODIGOMODULO'=>trim($pregunta->CODIGOMODULO),
             'PREGUNTA'=>trim($pregunta->PREGUNTA),
             'FILA'=>$integer+1
        );
         $integer++;
                }                   
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'preguntas'=>$enviarpreguntas,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }


public function getrespuestas($curos,$modulo,$pregunta){
        $integer =0;
        $parametro=trim($curos);
        $parametro2=trim($modulo);

$preguntas = Preguntas::where(
                     [ 
                         ['CODIGOCURSO',$parametro],
                         ['CODIGOMODULO',$parametro2],
                         ['CODIGO',$pregunta]
                     ])->get(); 


 foreach($preguntas as $pregunta)
                {
$codigopregunta= trim($pregunta->CODIGO);
$pregunta= trim($pregunta->PREGUNTA);
$respuestas = Respuestas::where(
                     [ 
                         ['CODIGOPREGUNTA',$codigopregunta]
                     ])->get(); 
 foreach($respuestas as $respuesta)
                {
         $enviarpreguntas[$integer] = array( 
             'CODIGOCURSO'=>trim($parametro),
             'CODIGOMODULO'=>trim($parametro2),
             'CODIGOPREGUNTA'=>trim($codigopregunta),
             'PREGUNTA'=>trim($pregunta),
             'CODIGORESPUESTA'=>trim($respuesta->CODIGO),
             'RESPUESTA'=>trim($respuesta->RESPUESTA),
             'ESCORRECTA'=>trim($respuesta->ESCORRECTA)
        );
         $integer++;
                }


                }           
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'respuestas'=>$enviarpreguntas,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }


public function getrespuestasE($curos,$modulo,$usuario){
        $integer =0;
        $contador =0;
        $parametro=trim($curos);
        $parametro2=trim($modulo);
        $parametro3=trim($usuario);
//CONSULTAR PRIMERO SI YA RESPONDIO LA 
//PREGUNTA

$evaluaciones = Evaluaciones::where([
    ['CODIGOCURSO', $parametro],
    ['CODIGOMODULO', $parametro2],
    ['ACTIVA', '1'],
    ['USUARIO', $parametro3]
])->get();
 foreach($evaluaciones as $evaluacion)
                {
                $codigoevaluacion=$evaluacion->CODIGO;
                }

$preguntas = Detalleeva::where([
    ['CODIGOEVA',$codigoevaluacion]
])->get();
 foreach($preguntas as $pregunta)
                {
                $codigorespuestas[$contador] = array(     
             'PREGUNTA'=>trim($pregunta->PREGUNTA)
                                                );
                $contador++;   
                }


if (!empty($codigorespuestas)) {
    $nuevaspregunta = Preguntas::where([
        ['CODIGOCURSO', $parametro],
        ['CODIGOMODULO', $parametro2],
        ['ESTAACTIVA', '1'],
    ])->whereNotIn('CODIGO', $codigorespuestas) // Elimina los corchetes adicionales
      ->inRandomOrder()
      ->first();
} else {
    $nuevaspregunta = Preguntas::where([
        ['CODIGOCURSO', $parametro],
        ['CODIGOMODULO', $parametro2],
        ['ESTAACTIVA', '1']
    ])->inRandomOrder()
      ->first(); // Obtiene un registro al azar
}

if ($nuevaspregunta) { // Verifica si se encontró una pregunta
    $preguntaramdon = $nuevaspregunta->CODIGO;
    $nombrepregunta = $nuevaspregunta->PREGUNTA;
}


$respuestas = Respuestas::where([
    ['CODIGOPREGUNTA', $preguntaramdon]
])->get();


 foreach($respuestas as $respuesta)
                {
         $enviarrespuestas[$integer] = array( 
             'CODIGOPREGUNTA'=>trim($preguntaramdon),
             'PREGUNTA'=>trim($nombrepregunta),
             'CODIGO'=>trim($respuesta->CODIGO),
             'CODIGOPREGUNTA'=>trim($respuesta->CODIGOPREGUNTA),
             'RESPUESTA'=>trim($respuesta->RESPUESTA),
             'ESCORRECTA'=>trim($respuesta->ESCORRECTA)
        );
         $integer++;
                }


                        
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'respuestas'=>$enviarrespuestas,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }



public function getcalificacion($curos,$modulo,$usuario){
        $integer =0;
        $contador =0;
        $parametro=trim($curos);
        $parametro2=trim($modulo);
        $parametro3=trim($usuario);
//CONSULTAR PRIMERO SI YA RESPONDIO LA 
//PREGUNTA

$evaluaciones = Evaluaciones::where([
    ['CODIGOCURSO', $parametro],
    ['CODIGOMODULO', $parametro2],
    ['ACTIVA', '1'],
    ['USUARIO', $parametro3]
])->get();


 foreach($evaluaciones as $evaluacion)
                {
                $codigoevaluacion=$evaluacion->CODIGO;
                }


$preguntas = Detalleeva::where([
    ['CODIGOEVA',$codigoevaluacion]
])->get();

$totalEscorrecta = 0;

 foreach($preguntas as $pregunta)
                {
 $totalEscorrecta += $pregunta->ESCORRECTA;
    
    $contador++;   
                }




if (!empty($totalEscorrecta)) {

         $enviarrespuestas[$integer] = array( 
             'CALIFICACION'=>$totalEscorrecta
        );


         $data = array(
          'status'=>'success',
          'code'=>200, 
          'respuestas'=>$enviarrespuestas,
          'id'=>1);

} 

else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }


public function getintroduccion($curso,$modulo,$introduccion){
        $integer =0;
        $parametro1=trim($curso);
        $parametro2=trim($modulo);
        $parametro3=trim($introduccion);

$adjuntos = Adjuntos::where(
                     [ 
                         ['CODIGOCURSO',$parametro1],
                         ['CODIGOMODULO',$parametro2],
                         ['SUBMODULO',$parametro3]
                     ])->get(); 

 foreach($adjuntos as $adjunto)
                {


         $enviaradjunto[$integer] = array(     
             'CODIGO'=>trim($adjunto->CODIGO),
             'CODIGOCURSO'=>trim($adjunto->CODIGOCURSO),
             'CODIGOMODULO'=>trim($adjunto->CODIGOMODULO),
             'SUBMODULO'=>trim($adjunto->SUBMODULO),
             'INTRODUCCION'=>trim($adjunto->INTRODUCCION),
             'ADJUNTO'=>trim($adjunto->ADJUNTO),
             'TITULO'=>trim($adjunto->TITULO),
             'EXTENSION'=>trim($adjunto->EXTENSION)
               
             
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'introduccion'=>$enviaradjunto,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }


public function getmodulosp($codigo){
        $integer =0;
        $parametro=trim($codigo);

$modulos = Modulos::where(
                     [ 
                         ['CODIGOCURSO',$parametro]
                     ])->orderBy('ORDEN')->get();

 foreach($modulos as $modulo)
                {
         $enviarmodulo[$integer] = array(     
             'CODIGO'=>trim($modulo->CODIGO),
             'NOMBRE'=>trim($modulo->NOMBRE),
             'DESCRIPCION'=>trim($modulo->DESCRIPCION),
             'CODIGOCURSO'=>trim($modulo->CODIGOCURSO),
             'NOMBRECURSO'=>trim($modulo->fcursos->NOMBRE),
             'ORDEN'=>trim($modulo->ORDEN)
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'modulo'=>$enviarmodulo,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }


public function gettotalcursos($codigo){
        $integer =0;
        $parametro=trim($codigo);

$cursos = Cursoasignacion::where(
                     [ 
                         ['USUARIO',$parametro]
                     ])->get();

 foreach($cursos as $curso)
                {
         $integer++;
                }

$enviartotal['total'] = $integer;


if($integer>0)
{

$data = [
    'status' => 'success',
    'code' => 200,
    'total' => $enviartotal['total'], // Aquí obtendrás el valor 1, no un array anidado
    'id' => 1
];

}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }


//CREACION DE NUEVOS RESPONSABLES
    public function nuevoModulo(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'NOMBRE'=>'required'//Comprobar si el usuario existe con unique

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El curso no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
             
        //Crear el Responsable
    $modulo=new Modulos();
    $modulo->NOMBRE= strtoupper($params_array['NOMBRE']);
    $modulo->DESCRIPCION= strtoupper($params_array['DESCRIPCION']);
    $modulo->CODIGOCURSO= strtoupper($params_array['CODIGOCURSO']);
    $modulo->ORDEN= strtoupper($params_array['ORDEN']);
    if($modulo->save())
    {

        $id_generado = $modulo->CODIGO; // `id` asume que es el nombre del campo ID

$data = array(
    'status' => 'success',
    'code' => 200, 
    'message' => 'El curso se ha creado correctamente con el ID: ' . $id_generado,
    'id' => $id_generado
);
    }
    else
    {
$data = array(
          'status'=>'error',
          'code'=>200, 
          'message'=>'Error al crear el curso'
        );
    }
    
    }
        }else
        {
    $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }
        return response()->json($data,$data['code']);
    }


//CREACION DE NUEVOS RESPONSABLES
    public function nuevaPregunta(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'CODIGOCURSO'=>'required'//Comprobar si el usuario existe con unique

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'La pregunta no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
    
        //Crear el Responsable
    $preguntas=new Preguntas();
    $preguntas->CODIGOCURSO= strtoupper($params_array['CODIGOCURSO']);
    $preguntas->CODIGOMODULO= strtoupper($params_array['CODIGOMODULO']);
    $preguntas->PREGUNTA= strtoupper($params_array['PREGUNTA']);
    $preguntas->ESTAACTIVA= '1';
    if($preguntas->save())
    {

if($params_array['RESPUESTA1'] != '')
{
    $respuestas=new Respuestas();
    $respuestas->CODIGOPREGUNTA= $preguntas->CODIGO;
    $respuestas->RESPUESTA= strtoupper($params_array['RESPUESTA1']);
    $respuestas->ESCORRECTA= strtoupper($params_array['ESCORRECTA1']);
    $respuestas->save();
}
if($params_array['RESPUESTA2'] != '')
{
    $respuestas=new Respuestas();
    $respuestas->CODIGOPREGUNTA= $preguntas->CODIGO;
    $respuestas->RESPUESTA= strtoupper($params_array['RESPUESTA2']);
    $respuestas->ESCORRECTA= strtoupper($params_array['ESCORRECTA2']);
    $respuestas->save();
}
if($params_array['RESPUESTA3'] != '')
{
    $respuestas=new Respuestas();
    $respuestas->CODIGOPREGUNTA= $preguntas->CODIGO;
    $respuestas->RESPUESTA= strtoupper($params_array['RESPUESTA3']);
    $respuestas->ESCORRECTA= strtoupper($params_array['ESCORRECTA3']);
    $respuestas->save();
}
if($params_array['RESPUESTA4'] != '')
{
    $respuestas=new Respuestas();
    $respuestas->CODIGOPREGUNTA= $preguntas->CODIGO;
    $respuestas->RESPUESTA= strtoupper($params_array['RESPUESTA4']);
    $respuestas->ESCORRECTA= strtoupper($params_array['ESCORRECTA4']);
    $respuestas->save();
}
if($params_array['RESPUESTA5'] != '')
{
    $respuestas=new Respuestas();
    $respuestas->CODIGOPREGUNTA= $preguntas->CODIGO;
    $respuestas->RESPUESTA= strtoupper($params_array['RESPUESTA5']);
    $respuestas->ESCORRECTA= strtoupper($params_array['ESCORRECTA5']);
    $respuestas->save();
}


$data = array(
    'status' => 'success',
    'code' => 200, 
    'message' => 'La pregunta se ha creado correctamente con el ID: ' . $preguntas->CODIGO,
    'id' => $preguntas->CODIGO
);
    }
    else
    {
$data = array(
          'status'=>'error',
          'code'=>200, 
          'message'=>'Error al crear el curso'
        );
    }
    
    }
        }else
        {
    $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }
        return response()->json($data,$data['code']);
    }



//CREACION DE NUEVOS RESPONSABLES
    public function nuevoAdjunto(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'CODIGOCURSO'=>'required'//Comprobar si el usuario existe con unique
    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El adjunto no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
             
        //Crear el Responsable
    $adjunto=new Adjuntos();
    $adjunto->CODIGOCURSO= strtoupper($params_array['CODIGOCURSO']);
    $adjunto->CODIGOMODULO= strtoupper($params_array['CODIGOMODULO']);
    $adjunto->SUBMODULO= strtoupper($params_array['SUBMODULO']);
    $adjunto->INTRODUCCION= strtoupper($params_array['INTRODUCCION']);
    //$adjunto->ADJUNTO= strtoupper($params_array['ADJUNTO']);
    $adjunto->TITULO= strtoupper($params_array['TITULO']);
     $adjunto->EXTENSION= strtoupper($params_array['EXTENSION']);
    
    if($adjunto->save())
    {

        $id_generado = $adjunto->CODIGO; // `id` asume que es el nombre del campo ID

//ACTUALIZAR EL CODIGO 

$update = Adjuntos::where([
                         ['CODIGO',$id_generado],
])->update(['ADJUNTO' => $id_generado]);


$data = array(
    'status' => 'success',
    'code' => 200, 
    'message' => 'El adjunto se ha creado correctamente con el ID: ' . $id_generado,
    'id' => $id_generado
);
    }
    else
    {
$data = array(
          'status'=>'error',
          'code'=>200, 
          'message'=>'Error al crear el adjuno'
        );
    }
    
    }
        }else
        {
    $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }
        return response()->json($data,$data['code']);
    }


public function getcursos($id){
        $integer =0;
$cursos = Cursos::where(
                     [ 
                         ['ESTAACTIVO',1],
                         ['COD_DEPARTAMENTO',$id]
                     ])->get(); 

$total = $cursos->count();

 foreach($cursos as $curso)
                {
$estado ='';
$asignados = Cursoasignacion::where([ 
    ['CURSO', $curso->CODIGOCURSO]
])->get();
if ($asignados->count() > 0) {
 foreach($asignados as $asignado)
                {
    $estado =trim($asignado->festado->NOMBRE);
                }

} else {
   $estado ='NO INICIADO';
}

         $enviarcursos[$integer] = array(     
             'CODIGOCURSO'=>trim($curso->CODIGOCURSO),
             'NOMBRE'=>trim($curso->NOMBRE),
             'ESTADO'=>trim($estado),
             'ESTAACTIVO' => $curso->ESTAACTIVO == 1 ? 'ACTIVO' : 'INACTIVO',
'COD_DEPARTAMENTO'=>trim($curso->COD_DEPARTAMENTO),
             'DEPARTAMENTO'=>trim($curso->fdepartamentos->NOMBRE),
             'TOTAL'=>$total


        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'cursos'=>$enviarcursos,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }



public function getcursoscu($id){
        $integer =0;
$cursos = Cursos::where(
                     [ 
                         ['ESTAACTIVO',1],
                         ['COD_DEPARTAMENTO',$id],
                         ['MODULOS','>',0]
                     ])->get(); 

$total = $cursos->count();

 foreach($cursos as $curso)
                {
$estado ='';
$asignados = Cursoasignacion::where([ 
    ['CURSO', $curso->CODIGOCURSO]
])->get();
if ($asignados->count() > 0) {
 foreach($asignados as $asignado)
                {
    $estado =trim($asignado->festado->NOMBRE);
                }

} else {
   $estado ='NO INICIADO';
}

         $enviarcursos[$integer] = array(     
             'CODIGOCURSO'=>trim($curso->CODIGOCURSO),
             'NOMBRE'=>trim($curso->NOMBRE),
             'ESTADO'=>trim($estado),
             'ESTAACTIVO' => $curso->ESTAACTIVO == 1 ? 'ACTIVO' : 'INACTIVO',
'COD_DEPARTAMENTO'=>trim($curso->COD_DEPARTAMENTO),
             'DEPARTAMENTO'=>trim($curso->fdepartamentos->NOMBRE),
             'TOTAL'=>$total


        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'cursos'=>$enviarcursos,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }


public function getcursosca($id){
        $integer =0;
$cursos = Cursos::where(
                     [ 
                         ['ESTAACTIVO',1],
                         ['COD_DEPARTAMENTO',$id],
                         ['MODULOS',0]
                     ])->get(); 

$total = $cursos->count();

 foreach($cursos as $curso)
                {
$estado ='';
$asignados = Cursoasignacion::where([ 
    ['CURSO', $curso->CODIGOCURSO]
])->get();
if ($asignados->count() > 0) {
 foreach($asignados as $asignado)
                {
    $estado =trim($asignado->festado->NOMBRE);
                }

} else {
   $estado ='NO INICIADO';
}

         $enviarcursos[$integer] = array(     
             'CODIGOCURSO'=>trim($curso->CODIGOCURSO),
             'NOMBRE'=>trim($curso->NOMBRE),
             'ESTADO'=>trim($estado),
             'ESTAACTIVO' => $curso->ESTAACTIVO == 1 ? 'ACTIVO' : 'INACTIVO',
'COD_DEPARTAMENTO'=>trim($curso->COD_DEPARTAMENTO),
             'DEPARTAMENTO'=>trim($curso->fdepartamentos->NOMBRE),
             'TOTAL'=>$total


        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'cursos'=>$enviarcursos,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }
public function cursosotrsodep($id,$usuario) {
    $integer = 0;
    $contador = 0;
    $depasignados = [];

    $asignacion = Cursodep::where('CODDEPARTAMENTO', $id)->get(); 

    foreach ($asignacion as $asig) {
        $depasignados[] = trim($asig->CODIGOCURSO);
    }

    if (!empty($depasignados)) {


   /*     $cursos = Cursos::where('ESTAACTIVO', 1)
            ->where(function ($query) use ($id, $depasignados) {
                $query->where('COD_DEPARTAMENTO', $id)
                      ->orWhereIn('CODIGOCURSO', $depasignados);
            })
            ->get();
*/

            $cursos = Cursos::where('ESTAACTIVO', 1)
            ->where('MODULOS', '>', 0)  // Nueva condición para MODULOS > 0
            ->where(function ($query) use ($id, $depasignados) {
                $query->where('COD_DEPARTAMENTO', $id)
                      ->orWhereIn('CODIGOCURSO', $depasignados);
            })
            ->get();


    } else {
        $cursos = Cursos::where('ESTAACTIVO', 1)
            ->where('COD_DEPARTAMENTO', $id)
            ->get();

            $cursos = Cursos::where(
                     [ 
                         ['ESTAACTIVO',1],
                         ['COD_DEPARTAMENTO',$id],
                          ['MODULOS', '>', 0]
                     ])->get(); 


    }

    $total = $cursos->count();
    $enviarcursos = [];

    foreach ($cursos as $curso) {
        $estado = 'NO INICIADO';
        //$asignados = Cursoasignacion::where('CURSO', $curso->CODIGOCURSO)->get();
        $asignados = Cursoasignacion::where('CURSO', $curso->CODIGOCURSO)
                            ->where('USUARIO', $usuario)
                            ->get();


        if ($asignados->count() > 0) {
            foreach ($asignados as $asignado) {
                $estado = trim($asignado->festado->NOMBRE);
            }
        }

        $enviarcursos[] = [
            'CODIGOCURSO' => trim($curso->CODIGOCURSO),
            'NOMBRE' => trim($curso->NOMBRE),
            'ESTADO' => trim($estado),
            'ESTAACTIVO' => $curso->ESTAACTIVO == 1 ? 'ACTIVO' : 'INACTIVO',
            'COD_DEPARTAMENTO' => trim($curso->COD_DEPARTAMENTO),
            'DEPARTAMENTO' => trim($curso->fdepartamentos->NOMBRE),
            'TOTAL' => $total
        ];

        $integer++;
    }

    $data = $integer > 0 ? [
        'status' => 'success',
        'code' => 200, 
        'cursos' => $enviarcursos,
        'id' => 1
    ] : [
        'status' => 'error',
        'code' => 404, 
        'message' => 'No existen registros',
        'id' => 0
    ];

    return response()->json($data, $data['code']);
}



public function capotrosdep($id) {
    $integer = 0;
    $contador = 0;
    $depasignados = [];

    $asignacion = Cursodep::where('CODDEPARTAMENTO', $id)->get(); 

    foreach ($asignacion as $asig) {
        $depasignados[] = trim($asig->CODIGOCURSO);
    }

    if (!empty($depasignados)) {

            $cursos = Cursos::where('ESTAACTIVO', 1)
            ->where('MODULOS',  0)  // Nueva condición para MODULOS > 0
            ->where(function ($query) use ($id, $depasignados) {
                $query->where('COD_DEPARTAMENTO', $id)
                      ->orWhereIn('CODIGOCURSO', $depasignados);
            })
            ->get();


    } else {
        $cursos = Cursos::where('ESTAACTIVO', 1)
            ->where('COD_DEPARTAMENTO', $id)
            ->get();

            $cursos = Cursos::where(
                     [ 
                         ['ESTAACTIVO',1],
                         ['COD_DEPARTAMENTO',$id],
                          ['MODULOS', 0]
                     ])->get(); 


    }

    $total = $cursos->count();
    $enviarcursos = [];

    foreach ($cursos as $curso) {

        $asignados = Modulos::where('CODIGOCURSO', $curso->CODIGOCURSO)->get();

        if ($asignados->count() > 0) {
            foreach ($asignados as $asignado) {
                $modulo = trim($asignado->CODIGO);
            }
        }

        $enviarcursos[] = [
            'CODIGOCURSO' => trim($curso->CODIGOCURSO),
            'NOMBRE' => trim($curso->NOMBRE),
            'MODULO' => trim($modulo),
            'ESTAACTIVO' => $curso->ESTAACTIVO == 1 ? 'ACTIVO' : 'INACTIVO',
            'COD_DEPARTAMENTO' => trim($curso->COD_DEPARTAMENTO),
            'DEPARTAMENTO' => trim($curso->fdepartamentos->NOMBRE),
            'TOTAL' => $total
        ];

        $integer++;
    }

    $data = $integer > 0 ? [
        'status' => 'success',
        'code' => 200, 
        'cursos' => $enviarcursos,
        'id' => 1
    ] : [
        'status' => 'error',
        'code' => 404, 
        'message' => 'No existen registros',
        'id' => 0
    ];

    return response()->json($data, $data['code']);
}



public function codigoasignado($curso,$modulo,$usuario){
        $integer =0;



$evaluaciones = Evaluaciones::where([
    ['CODIGOCURSO', $curso],
    ['CODIGOMODULO', $modulo],
    ['ACTIVA', '1'],
    ['USUARIO', $usuario]
])->get();


 foreach($evaluaciones as $evaluacione)
                {
         $enviarcodigo[$integer] = array(     
             'CODIGO'=>trim($evaluacione->CODIGO),
             'CODIGOCURSO'=>trim($evaluacione->CODIGOCURSO),
             'CODIGOMODULO'=>trim($evaluacione->CODIGOMODULO),
             'USUARIO'=>trim($evaluacione->USUARIO),
             'CALIFICACION'=>trim($evaluacione->CALIFICACION),
             'ACTIVA'=>trim($evaluacione->ACTIVA)
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'evaluaciones'=>$enviarcodigo,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }


public function getcursosasignado($curso, $usuario){
        $integer =0;
$asignados = Cursoasignacion::where(
                     [ 
                         ['CURSO',$curso],
                         ['USUARIO',$usuario]
                     ])->get(); 



 foreach($asignados as $asignado)
                {

         $enviarasignados[$integer] = array(     
             'CODIGO'=>trim($asignado->CODIGO),
             'USUARIO'=>trim($asignado->USUARIO),
             'CURSO'=>trim($asignado->CURSO),
             'ESTADO'=>trim($asignado->ESTADO),
              'MODULO'=>trim($asignado->MODULO)
 


        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'asignados'=>$enviarasignados,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }


public function getcursosestado($estado, $departamento, $usuario) {
    $integer = 0;
    $contador = 0;
    $cursosasignados = []; // Inicializa el array

    if ($estado == 'E001') {
        $asignacion = Cursoasignacion::where([
            ['USUARIO', $usuario]
        ])->get();

        foreach ($asignacion as $asig) {
            $cursosasignados[] = trim($asig->CURSO); // Solo el valor, sin clave
        }

        if (!empty($cursosasignados)) {
            $cursos = Cursos::where([
                ['ESTAACTIVO', 1],
                ['MODULOS','>', 0],
                ['COD_DEPARTAMENTO', $departamento]
            ])->whereNotIn('CODIGOCURSO', $cursosasignados)->get();

            // var_dump('si'); die(); // Elimina esto si no es necesario
        } else {
            $cursos = Cursos::where([
                ['ESTAACTIVO', 1],
                ['MODULOS','>', 0],
                ['COD_DEPARTAMENTO', $departamento]
            ])->get();
        }
    } else {
        $asignacion = Cursoasignacion::where([
            ['USUARIO', $usuario],
            ['ESTADO', $estado]
        ])->get();

        foreach ($asignacion as $asig) {
            $cursosasignados[] = trim($asig->CURSO); // Solo el valor, sin clave
        }

        $cursos = Cursos::where([
            ['ESTAACTIVO', 1],
            ['MODULOS','>', 0],
            ['COD_DEPARTAMENTO', $departamento]
        ])->whereIn('CODIGOCURSO', $cursosasignados)->get();
    }

    $enviarcursos = []; // Inicializa el array

    foreach ($cursos as $curso) {
        $estado = '';
        $asignados = Cursoasignacion::where([
            ['CURSO', $curso->CODIGOCURSO]
        ])->get();

        if ($asignados->count() > 0) {
            foreach ($asignados as $asignado) {
                $estado = trim($asignado->festado->NOMBRE); // Asegúrate de que `festado` es una relación válida
            }
        } else {
            $estado = 'NO INICIADO';
        }

        $enviarcursos[] = [
            'CODIGOCURSO' => trim($curso->CODIGOCURSO),
            'NOMBRE' => trim($curso->NOMBRE),
            'ESTADO' => trim($estado),
            'ESTAACTIVO' => $curso->ESTAACTIVO == 1 ? 'ACTIVO' : 'INACTIVO',
            'COD_DEPARTAMENTO' => trim($curso->COD_DEPARTAMENTO),
            'DEPARTAMENTO' => trim($curso->fdepartamentos->NOMBRE) // Asegúrate de que `fdepartamentos` es una relación válida
        ];
        $integer++;
    }

    if ($integer > 0) {
        $data = [
            'status' => 'success',
            'code' => 200,
            'cursos' => $enviarcursos,
            'id' => 1
        ];
    } else {
        $data = [
            'status' => 'error',
            'code' => 404,
            'message' => 'No existen registros',
            'id' => 0
        ];
    }

    return response()->json($data, $data['code']);
}


public function getcapestado($estado, $departamento, $usuario) {
    $integer = 0;
    $contador = 0;
    $cursosasignados = []; // Inicializa el array

    if ($estado == 'E001') {
        $asignacion = Cursoasignacion::where([
            ['USUARIO', $usuario]
        ])->get();

        foreach ($asignacion as $asig) {
            $cursosasignados[] = trim($asig->CURSO); // Solo el valor, sin clave
        }

        if (!empty($cursosasignados)) {

            $cursos = Cursos::where([
                ['ESTAACTIVO', 1],
                ['MODULOS', 0],
                ['COD_DEPARTAMENTO', $departamento]
            ])->whereNotIn('CODIGOCURSO', $cursosasignados)->get();


           

            
            // var_dump('si'); die(); // Elimina esto si no es necesario
        } else {
            $cursos = Cursos::where([
                ['ESTAACTIVO', 1],
                ['MODULOS', 0],
                ['COD_DEPARTAMENTO', $departamento]
            ])->get();
        }
    } else {
        $asignacion = Cursoasignacion::where([
            ['USUARIO', $usuario],
            ['ESTADO', $estado]
        ])->get();

        foreach ($asignacion as $asig) {
            $cursosasignados[] = trim($asig->CURSO); // Solo el valor, sin clave
        }

        $cursos = Cursos::where([
            ['ESTAACTIVO', 1],
            ['MODULOS', 0],
            ['COD_DEPARTAMENTO', $departamento]
        ])->whereIn('CODIGOCURSO', $cursosasignados)->get();
    }

    $enviarcursos = []; // Inicializa el array

    foreach ($cursos as $curso) {
        $estado = '';
        $asignados = Cursoasignacion::where([
            ['CURSO', $curso->CODIGOCURSO]
        ])->get();

        if ($asignados->count() > 0) {
            foreach ($asignados as $asignado) {
                $estado = trim($asignado->festado->NOMBRE); // Asegúrate de que `festado` es una relación válida
            }
        } else {
            $estado = 'NO INICIADO';
        }

        $enviarcursos[] = [
            'CODIGOCURSO' => trim($curso->CODIGOCURSO),
            'NOMBRE' => trim($curso->NOMBRE),
            'ESTADO' => trim($estado),
            'ESTAACTIVO' => $curso->ESTAACTIVO == 1 ? 'ACTIVO' : 'INACTIVO',
            'COD_DEPARTAMENTO' => trim($curso->COD_DEPARTAMENTO),
            'DEPARTAMENTO' => trim($curso->fdepartamentos->NOMBRE) // Asegúrate de que `fdepartamentos` es una relación válida
        ];
        $integer++;
    }

    if ($integer > 0) {
        $data = [
            'status' => 'success',
            'code' => 200,
            'cursos' => $enviarcursos,
            'id' => 1
        ];
    } else {
        $data = [
            'status' => 'error',
            'code' => 404,
            'message' => 'No existen registros',
            'id' => 0
        ];
    }

    return response()->json($data, $data['code']);
}

public function getcursosadmin(){
        $integer =0;
$cursos = Cursos::where([
            ['MODULOS','>', 0]
        ])->get();


$total = $cursos->count();


 foreach($cursos as $curso)
                {
        $enviarcursos[$integer] = array(     
    'CODIGOCURSO' => trim($curso->CODIGOCURSO),
    'NOMBRE' => trim($curso->NOMBRE),
    'ESTAACTIVO' => $curso->ESTAACTIVO == 1 ? 'ACTIVO' : 'INACTIVO',
'COD_DEPARTAMENTO'=>trim($curso->COD_DEPARTAMENTO),
'DEPARTAMENTO'=>trim($curso->fdepartamentos->NOMBRE),
'TOTAL'=>$total

);

         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'cursos'=>$enviarcursos,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }


public function getcapaciadmin(){
        $integer =0;
$cursos = Cursos::where([
            ['MODULOS', 0]
        ])->get();


$total = $cursos->count();


 foreach($cursos as $curso)
                {

$modulos = Modulos::where([
            ['CODIGOCURSO',$curso->CODIGOCURSO]
        ])->get();
 foreach($modulos as $modulo)
                {
$moduloactual=$modulo->CODIGO;
                }


        $enviarcursos[$integer] = array(     
    'CODIGOCURSO' => trim($curso->CODIGOCURSO),
    'NOMBRE' => trim($curso->NOMBRE),
    'ESTAACTIVO' => $curso->ESTAACTIVO == 1 ? 'ACTIVO' : 'INACTIVO',
'COD_DEPARTAMENTO'=>trim($curso->COD_DEPARTAMENTO),
'DEPARTAMENTO'=>trim($curso->fdepartamentos->NOMBRE),
'TOTAL'=>$total,
'CODIGOMODULO'=>$moduloactual


);

         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'cursos'=>$enviarcursos,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }



public function getestadocurso(){
        $integer =0;

$estados = Estadocursos::all();



 foreach($estados as $estado)
                {
        $enviarestado[$integer] = array(     
    'CODIGO' => trim($estado->CODIGO),
    'NOMBRE' => trim($estado->NOMBRE)

);

         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'estados'=>$enviarestado,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);
                            }

  ///////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
//CREACION DE NUEVOS RESPONSABLES
    public function asignarCurso(Request $request){
        $json = $request->input('json',null);
        $params = json_decode($json);//esto em devuelve un objeto
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        //limpiar los datos siempre y cuando el array no sea vacio
        if(!empty($params) && !empty($params_array)){

        //Limpiar el array de espacios
        $params_array = array_map('trim', $params_array);
        


     
        //Validar los datos
        $validate = \Validator::make($params_array, [
        'USUARIO'=>'required'//Comprobar si el usuario existe con unique

    ]);
    if($validate->fails()){
           $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'La asignacion no se ha creado',
          'error'=>$validate->errors()
        );
    }else
    {
             
        //Crear el Responsable
    $curso=new Cursoasignacion();
    $curso->USUARIO= strtoupper($params_array['USUARIO']);
    $curso->CURSO= strtoupper($params_array['CURSO']);
    $curso->ESTADO= strtoupper($params_array['ESTADO']);
    $curso->MODULO= strtoupper($params_array['MODULO']);
    if($curso->save())
    {

        $id_generado = $curso->CODIGO; // `id` asume que es el nombre del campo ID

$data = array(
    'status' => 'success',
    'code' => 200, 
    'message' => 'El curso ha sido asignado correctamente con el ID: ' . $id_generado,
    'id' => $id_generado
);
    }
    else
    {
$data = array(
          'status'=>'error',
          'code'=>200, 
          'message'=>'Error al asignar el curso'
        );
    }
    
    }
        }else
        {
    $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'Los datos enviados no son correctos'
        );  
        }
        return response()->json($data,$data['code']);
    }




public function getsubmodulos(){
        $integer =0;
        

$submodulos = Submodulos::all();

 foreach($submodulos as $submodulo)
                {
         $enviarsubmodulo[$integer] = array(     
             'CODIGO'=>trim($submodulo->CODIGO),
             'NOMBRE'=>trim($submodulo->NOMBRE)
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'submodulo'=>$enviarsubmodulo,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);

}



public function getsubmodulos2(){
        $integer =0;
        

$excludedIds = ['SM002', 'SM003']; // IDs que quieres excluir
$submodulos = Submodulos::whereNotIn('CODIGO', $excludedIds)->get();



 foreach($submodulos as $submodulo)
                {
         $enviarsubmodulo[$integer] = array(     
             'CODIGO'=>trim($submodulo->CODIGO),
             'NOMBRE'=>trim($submodulo->NOMBRE)
        );
         $integer++;
                }
if($integer>0)
{
$data = array(
          'status'=>'success',
          'code'=>200, 
          'submodulo'=>$enviarsubmodulo,
          'id'=>1);
}else
{
$data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'No existen registros',
          'id'=>0
      );
         }
         return response()->json($data,$data['code']);

}


public function updatecurso($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
         if(!empty($params_array))
         {
             unset($params_array['NOMBRE']);
             unset($params_array['ETAPA']);
             unset($params_array['MODULOS']);
             unset($params_array['COD_DEPARTAMENTO']);
             //actualizar el usuario en la bbd
             $limite_update =  Cursos::where('CODIGOCURSO',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El curso no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }



public function aprobar(Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
        if(!empty($params_array))
         {

$cursos = Cursos::where(
                     [ 
                         ['CODIGOCURSO',$params_array['CURSO']]
                     ])->get();
 foreach($cursos as $curso)
                {
    $numeromodulos =trim($curso->MODULOS);
                }



$asignacion = Cursoasignacion::where(
                     [ 
                         ['USUARIO',$params_array['USUARIO']],
                         ['ESTADO','E002'],
                         ['CURSO',$params_array['CURSO']]
                     ])->get();


if ($asignacion->count() > 0) {
 foreach($asignacion as $asig)
                {
    $codigo =trim($asig->CODIGO);
    $moduloactual =trim($asig->MODULO);
                }

if($numeromodulos>($moduloactual+1))
{


$update = Cursoasignacion::where([
    ['USUARIO',$params_array['USUARIO']],
                         ['ESTADO','E002'],
                         ['CURSO',$params_array['CURSO']]
])->update(['MODULO' => $moduloactual+1]);

$data = array(
          'status'=>'proceso',
          'code'=>200, 
          'change'=>$params_array);

}
else
{
    //LE CAMBIO DE ESTADO A COMPLETO
 $update = Cursoasignacion::where([
    ['USUARIO',$params_array['USUARIO']],
                         ['ESTADO','E002'],
                         ['CURSO',$params_array['CURSO']]
])->update(['ESTADO' => 'E004']);  

 $data = array(
          'status'=>'completo',
          'code'=>200, 
          'change'=>$params_array);

}


} else {
 $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El curso no ha sido actualizado');
}


         
     }
     else
     {
 $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El curso no ha sido actualizado');
     }

     return response()->json($data,$data['code']);
 }

     public function updatenombre($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
         if(!empty($params_array))
         {
             unset($params_array['ESTAACTIVO']);
             unset($params_array['ETAPA']);
             unset($params_array['MODULOS']);
             unset($params_array['COD_DEPARTAMENTO']);
             //actualizar el usuario en la bbd
             $limite_update =  Cursos::where('CODIGOCURSO',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El curso no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }

     public function updateintro($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
      


if ($id == 'NO') {


    //INGRESAR

        //Crear el Responsable
    $introduccion=new Adjuntos();
    $introduccion->CODIGOCURSO= strtoupper($params_array['CODIGOCURSO']);
    $introduccion->CODIGOMODULO= strtoupper($params_array['CODIGOMODULO']);
    $introduccion->SUBMODULO= strtoupper($params_array['SUBMODULO']);
    $introduccion->INTRODUCCION= strtoupper($params_array['INTRODUCCION']);    
    if($introduccion->save())
    {

        $id_generado = $introduccion->CODIGO; // `id` asume que es el nombre del campo ID

$data = array(
    'status' => 'success',
    'code' => 200, 
    'message' => 'El curso se ha creado correctamente con el ID: ' . $id_generado,
    'id' => $id_generado
);
    }


}
else
{



        //ACTUALIZAR
         if(!empty($params_array))
         {
             unset($params_array['CODIGOCURSO']);
             unset($params_array['CODIGOMODULO']);
             unset($params_array['SUBMODULO']);
             unset($params_array['ADJUNTO']);
             unset($params_array['TITULO']);
             unset($params_array['EXTENSION']);
             //actualizar el usuario en la bbd
             $limite_update =  Adjuntos::where('CODIGO',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'La introduccion no ha sido actualizado');
         }

}

         return response()->json($data,$data['code']);
     }

     public function updatedep($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
         if(!empty($params_array))
         {
            unset($params_array['NOMBRE']);
             unset($params_array['ESTAACTIVO']);
             unset($params_array['ETAPA']);
             unset($params_array['MODULOS']);
             
             //actualizar el usuario en la bbd
             $limite_update =  Cursos::where('CODIGOCURSO',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El curso no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }




     public function inactivaPregunta($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
         if(!empty($params_array))
         {
            unset($params_array['CODIGOCURSO']);
             unset($params_array['CODIGOMODULO']);
             unset($params_array['PREGUNTA']);

             
             //actualizar el usuario en la bbd
             $limite_update =  Preguntas::where('CODIGO',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El curso no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }
     ///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////

          public function eliminarpregunta($id,Request $request){

         //ACTUALIZAR EL Responsable
             //recoger los datos por post
         $json =$request->input('json',null);
        $params_array = json_decode($json,true);//esto em devuelve un array
        
        
         if(!empty($params_array))
         {
            unset($params_array['NOMBRE']);
             unset($params_array['ESTAACTIVO']);
             unset($params_array['ETAPA']);
             unset($params_array['MODULOS']);
             
             //actualizar el usuario en la bbd
             $limite_update =  Cursos::where('CODIGOCURSO',$id)->update($params_array);
             
             //devolver array con el resultado
             $data = array(
          'status'=>'success',
          'code'=>200, 
          'change'=>$params_array);
         }else
         {
            $data = array(
          'status'=>'error',
          'code'=>404, 
          'message'=>'El curso no ha sido actualizado');
         }
         return response()->json($data,$data['code']);
     }

 public function eliminar($id,Request $request)
    {
     //comseguir el post
     $responsables= Adjuntos::find($id);
     
     
     if(!empty($responsables))
        {
     //borrarlo
     $responsables->delete();
     //devolver
     
     $data = array(
          'status'=>'success',
          'code'=>200, 
          'message'=>$responsables
        );
        }else
        {
            $data = array(
           'status'=>'success',
          'code'=>200, 
          'message'=>'No Existe el registro'
             );
        }
     return response()->json($data,$data['code']);
 }


}